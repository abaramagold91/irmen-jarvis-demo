# MANIFESTO_DE_VERSAO · Referência visual homologada

**ID:** DS-01 · **Comando:** IRMEN-JARVIS-002 · **Gerado em:** 22/10/2026

## Identificação

| Campo | Valor |
|---|---|
| Repositório | `abaramagold91/irmen-jarvis-demo` (protótipo; **não** é o Portal real) |
| Branch | `main` |
| Commit deste pacote | `fb6416ce1ec1264b94ae9dc2faf72a558803960f` |
| Prévia do sistema | https://abaramagold91.github.io/irmen-jarvis-demo/ (idêntica a `/previa-mobile/`) |
| Prévia do login | https://abaramagold91.github.io/irmen-jarvis-demo/login/ |
| Catálogo | https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/ |
| Homologação do Owner | Sistema e mobile: aprovados; login: aprovado em 22/10/2026 ("aprovado, dado como homologado") |

A referência pedida no comando (`/previa-mobile/`) e a raiz publicada têm os **mesmos bytes**: `index.html`, `app.js`, `data.js`, `screens.js`, `mobile.css` e `mobile.js` são idênticos nas duas pastas. A cópia em `/previa-mobile/` foi mantida para que o link antigo continue funcionando.

## Histórico de revisões relevantes

| Commit | O que mudou |
|---|---|
| `f6d3dbe` | Publicação do protótipo desktop aprovado (CDN trocado por cópias locais) |
| `26fb3dd` | Camada mobile (`mobile.css`, `mobile.js`) em `/previa-mobile/` |
| `8fba152` → `5feb922` | Tela de login e recuperação, ajustes de cor, textos e radar até a versão homologada |
| `632878a` | Camada mobile passa a valer na raiz; o login leva à raiz |
| `fb6416c` | Catálogo navegável (`catalogo/`), sem alterar nenhum arquivo do sistema ou do login |

## Arquivos-chave (SHA-256)

| Arquivo | SHA-256 |
|---|---|
| `index.html` (shell + CSS + tokens) | `f830d7b7452a2fa26ac9ebaf4cf76d75fcbb8175fd53dc7310f13ad404768fa7` |
| `app.js` | `99d99ef2003ed56e9b88a9c8ea02ac6abf9237f936b8555f6342eddbdbd8ba81` |
| `screens.js` | `35a39acb5c017625b30cbd12fbc46ba838fd2a0dececf73c373000c16e2c9c78` |
| `data.js` | `b9cfd9f5fd6053dc8f5430c3bf78a003d45b8c20c3393e795aee75eb384b52ae` |
| `mobile.css` | `c848f70e5fa49d66ab1e7af5763b91f396c4d837ffdeac67ce7ac81343e7702f` |
| `mobile.js` | `8879cc03466d6f901ffab5a53d6ce25febbfaf276fb1f98e65ce8fb184073b6a` |
| `login/index.html` | `16c2bd2ee6afea1cf9861485356959f8d5b75d4bb69bcfa6162ffcc697824dc5` |
| `vendor/echarts/echarts.min.js` (5.5.0) | `42f8329d989b6f6539dd2b15bbdf0d82025762ac112fbb60dc57b27d7bcf3946` |
| `vendor/fonts/fonts.css` | `f3fe342ae5916374882a3e5d431c38d1c6aef7192b270e909a49a859e8651be5` |
| `catalogo/sistema.css` (gerado) | `362229cbac7719b013df38028575564f4f63b153a5fc01c8608220647bff4341` |
| `catalogo/login-partes.css` (gerado) | `bb049fcd2b77c99cb6ebe3927d514ead81f4af83f58977a410bbad26d2cc1832` |

A lista completa (75 arquivos) está em `SHA256SUMS.txt`. Para conferir: `sha256sum -c SHA256SUMS.txt` dentro desta pasta.

## Conteúdo

| Caminho | O que é |
|---|---|
| `index.html`, `app.js`, `screens.js`, `data.js` | Sistema: 16 telas, 5 papéis de demonstração, fluxos guiados |
| `mobile.css`, `mobile.js` | Camada de celular e tablet (só age até 860px; trava de rolagem lateral em telas de toque até 1280px) |
| `login/index.html` | Login, recuperação de senha e solicitação de primeiro acesso (autocontido) |
| `catalogo/` | Catálogo de componentes; `gerar.py` recria `sistema.css` e `login-partes.css` a partir dos arquivos acima |
| `vendor/` | ECharts 5.5.0 e fontes (Chakra Petch, IBM Plex Sans, JetBrains Mono), com licenças |
| `documentacao/` | Roteiro de navegação, arquitetura do protótipo, ajuste mobile, relatório de verificação, licenças, `package.json`/`package-lock.json` com as versões |
| `previa-mobile/` | Cópia idêntica do sistema, mantida pelo link antigo |

## Licenças

- **Apache ECharts 5.5.0:** Apache 2.0 (`vendor/echarts/LICENSE`, `NOTICE`).
- **Fontes:** SIL OFL 1.1 (`vendor/fonts/LICENSE-*.txt`).
- **Ícones:** SVG próprios do protótipo.
- **Dados:** fictícios.

O detalhamento está em `documentacao/LICENCAS-DE-TERCEIROS.md`.

## Como abrir

```bash
cd irmen-jarvis-referencia
python3 -m http.server 8765 --bind 127.0.0.1
# http://127.0.0.1:8765/login/   http://127.0.0.1:8765/   http://127.0.0.1:8765/catalogo/
```

Não faz requisição externa nem precisa de build.

## Limites

Este pacote é **referência visual**. Os dados são fixos, a autenticação é simulada e não há backend. Ele não comprova funcionamento, segurança, desempenho nem prontidão de nenhum módulo do Portal IRMEN.

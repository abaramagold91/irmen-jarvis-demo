# DECISIONS_REQUIRED · Decisões novas do Owner

**Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026

Aqui só entram regras ou custos **realmente novos**: o que o protótipo sugere e que ainda não tem contrato, decisão no CTX ou regra vigente. O que já está decidido no CTX (SLA, códigos, perda, filiais, escopo do piloto, comissões fora, etc.) não é reaberto.

Cada decisão traz uma recomendação. Sem decisão, vale o padrão indicado, que é sempre o mais conservador.

| ID | Pergunta | Recomendação | Padrão sem decisão | Bloqueia |
|---|---|---|---|---|
| D-DS1 | Aceitar os ajustes de acessibilidade no visual homologado? | Sim | Visual homologado sem ajuste; só o anel de foco | A (parcial) |
| D-CRM1 | Renomear "Clientes" para "Organizações & Contatos" e ter contato como cadastro próprio? | Renomear já; contato próprio só se o modelo atual não tiver | Mantém "Clientes" | B1 (parcial) |
| D-SIM1 | O vendedor vê a comparação entre instituições no simulador? | Não; só a Mesa | Não mostrar | B2 (parcial) |
| D-BI1 | Criar taxonomia de motivos de perda, se não existir? | Sim, lista curta e fechada | Indicador "Por que perdemos" fica como lacuna | C2 (um painel) |
| D-AVA1 | Orçamento mensal da Ava e limite por usuário | Definir teto mensal baixo para o piloto | Operação paga em HOLD | D2/D3 com modelo pago |
| D-AVA2 | Voz: transcrição do navegador (sem custo) ou provider pago? | Navegador primeiro, só com botão | Voz desligada | D3 (voz) |
| D-AVA3 | Concorrência e fila da Ava | 1 pergunta por usuário; fila curta por empresa | Valores do contrato (seção 6) | D2 |
| D-AVA4 | Quais ações de escrita (N2) a Ava pode propor no piloto? | Criar tarefa e registrar nota | Só leitura e rascunho | D3 |
| D-TAR1 | Criar módulo de Tarefas ou estender as próximas ações existentes? | Decidir depois da inspeção; preferir estender | Sem tarefas novas | E1 |
| D-NOT1 | Quais eventos geram notificação e por quais canais? | SLA perto de estourar, documento pendente, movimentação na minha carteira; só no portal | Sem notificações novas | E1 |
| D-SUP1 | Quem atende o suporte interno, com qual SLA e quais categorias? | Administração; 8 horas úteis; Acesso, Sistema, Dúvida | Módulo não implementado | E2 |
| D-CONV1 | Quem vê quais conversas? | Dono da carteira + gestor com capability; Mesa só nas suas operações | Mantém a regra atual do chat, se existir | E3 |
| D-WA1 | Provedor oficial do WhatsApp e orçamento | Avaliar com o documento F1 | Sem integração | F1 |
| D-WA2 | Consentimento e textos de template | Opt-in registrado; templates aprovados pelo Owner | Sem envio ativo | F1 |
| D-WA3 | Conexão não oficial (QR) | Manter desligada | Desligada | — |
| D-GAM1 | Fórmula de XP | Só por resultado confirmado; nada ligado à aprovação de crédito | Sem XP | F2 |
| D-GAM2 | Cadastro de metas (quem cria, vigência, granularidade) | Gerência cria por mês e por vendedor; Diretoria aprova | Indicador de meta como lacuna | C2 (meta), F2 |
| D-GAM3 | Visibilidade do ranking | Por equipe; liga só entre gerências | Sem ranking | F2 |

---

## Detalhes

### D-DS1 · Ajustes de acessibilidade no visual homologado
**Por que é decisão:** muda levemente cores aprovadas.
**O que muda:**
1. Botão principal no tema escuro: fundo `#de2f3f` em vez de `#ef3f4f`. O contraste com o texto branco sobe de 3,82 para 4,58:1, e a diferença é quase imperceptível.
2. Texto pequeno direto sobre o fundo no tema claro: vermelho `#c8283a` (4,55:1) e ciano `#08709a` (4,58:1). Sobre os painéis brancos, nada muda.
3. Anel de foco visível nos botões chanfrados. Hoje o foco por teclado não aparece; a mudança só se vê ao navegar pelo teclado.

**Demonstração:** catálogo, seções Botões e Tokens.

### D-AVA1 · Orçamento
O CTX mantém a operação paga em HOLD. Sem um valor, os blocos D2 e D3 só podem usar modo sem custo e testes autorizados. O valor deve cobrir o piloto (dois vendedores e um coordenador) com teto mensal e alerta ao atingir 80%.

### D-SIM1 · Comparação entre instituições
O protótipo mostra ao vendedor uma comparação de parcelas entre instituições. Como o vendedor não decide banco, essa tela pode induzir expectativa. A recomendação é deixá-la só na Mesa. Se o Owner quiser ao vendedor, ela vira apenas informativa, com o aviso de que a Mesa decide.

### D-GAM1 · XP
Pontos ligados à aprovação de crédito criam incentivo errado. A proposta é pontuar só eventos confirmados e auditáveis (PED faturado, ficha sem retrabalho, tarefa concluída no prazo), com estorno quando o evento é cancelado.

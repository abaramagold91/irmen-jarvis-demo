# AVA_ASSISTANT_CONTRACT · Contrato do assistente

**ID:** AVA-03 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Situação:** **proposta de contrato**, nada implementado. O runtime local, a recuperação e a execução hospedada da Ava estão com o Codex. Este documento não altera esses arquivos e deve ser conciliado com o resultado do Codex antes de virar comando.

Marcas usadas: **[FATO]** (CTX ou protótipo), **[PROPOSTA]**, **[INSPEÇÃO PENDENTE]** e **[DECISÃO PENDENTE]**, esta última com ID em `DECISIONS_REQUIRED.md`.

---

## 1. Ponto de partida

| Item | Situação |
|---|---|
| Leitura e extração documental | **[FATO]** Publicada (CTX §3 e §4). **Preservar.** |
| Operação paga | **[FATO]** HOLD; o provider hospedado não foi validado nesta publicação (AVA01, AVA02) |
| Proteções já exigidas | **[FATO]** CTX §6: worker e cron protegidos, segredo e replay tratados; documentos são entrada não confiável; nenhum texto documental concede autoridade ou executa ferramenta; ledger; logs sem dado sensível |
| Protótipo | **[FATO]** Tela `#ava` (conversa de exemplo, área de documentos), barra `Ctrl+K` com respostas fixas, briefing no painel e sugestões no Inbox. **Não há modelo real no protótipo.** |
| Trabalho do Codex | **[INSPEÇÃO PENDENTE]** Arquitetura do runtime, onde moram prompts, ferramentas, ledger e limites |

---

## 2. Princípios não negociáveis

1. **Mesmas permissões do usuário.** A Ava age dentro das capabilities e escopos do usuário que pediu. Ela nunca tem acesso administrativo global, SQL arbitrário ou autoridade definida pelo modelo.
2. **Autorização no servidor a cada chamada de ferramenta.** A sessão do usuário é reavaliada no servidor em toda chamada, mesmo dentro da mesma conversa. O modelo não envia identidade, papel nem escopo; o servidor os deriva da sessão.
3. **Documentos e mensagens são dados.** Conteúdo de documento, mensagem de cliente, nome de arquivo ou campo de cadastro nunca muda instruções, nunca concede permissão e nunca dispara ferramenta.
4. **Crédito é decisão humana.** A Ava pode resumir, extrair e apontar pendências. Ela não aprova, não reprova, não escolhe instituição e não muda status de crédito.
5. **Voz não basta para ação de impacto.** Ação que altera dado ou envia algo exige confirmação na tela, nunca só pelo reconhecimento de voz.
6. **Sem custo novo nesta etapa.** Microfone permanente, novos providers e consumo pago ficam desligados até decisão (D-AVA1, D-AVA2).
7. **Números vêm de cálculo determinístico.** O modelo não calcula nem inventa métrica. Ele chama uma consulta que devolve o número e a fonte.

---

## 3. Entrada por texto e por voz

### 3.1 Texto **[PROPOSTA]**
- Entradas: barra da Ava (`Ctrl+K`), tela Ava e ações contextuais ("Resumir esta ficha").
- Toda resposta mostra **o que foi consultado** (fontes) e, quando houver número, **como foi calculado** (link para o contrato da métrica).
- Botão **Parar** durante a geração; cancelar não desfaz ação já confirmada, porque nenhuma ação acontece sem confirmação.

### 3.2 Voz **[PROPOSTA]**, desligada até D-AVA2
- **Acionamento explícito:** botão de microfone, apertar para falar ou alternar. Nunca escuta contínua e nunca palavra de ativação.
- Indicador visível de microfone ativo, com o tempo de gravação.
- **Transcrição visível e editável** antes do envio. O usuário corrige o texto e então envia.
- **Cancelar** descarta o áudio e a transcrição.
- **Fallback:** se a transcrição falhar ou a confiança for baixa, avisar e oferecer digitar. Nenhuma ação é inferida de áudio incompleto.
- **Áudio:** não guardar por padrão; guardar só a transcrição confirmada, junto com a conversa.
- **[DECISÃO PENDENTE D-AVA2]** Usar ou não a transcrição nativa do navegador (sem custo, qualidade variável) ou um provider pago.

---

## 4. Ferramentas

A Ava só usa ferramentas **específicas e nomeadas**, cada uma ligada a um caso de uso que já existe na camada Application do Portal (UI → Application/Use Cases → Domain/Policies → Repositories/Read Models → Infrastructure). A ferramenta chama o caso de uso, nunca o banco direto.

### 4.1 Níveis de impacto e confirmação **[PROPOSTA]**

| Nível | Tipo | Exemplo | Confirmação |
|---|---|---|---|
| N0 | Leitura | Buscar organização, abrir operação, consultar métrica, ver SLA | Nenhuma; a resposta cita as fontes |
| N1 | Rascunho | Rascunhar mensagem, resumo ou relatório | Nenhuma; nada é gravado nem enviado |
| N2 | Ação interna reversível | Criar tarefa, registrar nota interna, mover oportunidade numa transição permitida | **Prévia** do que vai mudar + 1 clique de confirmação |
| N3 | Envio externo ou difícil de desfazer | Enviar mensagem ao cliente, solicitar documento por WhatsApp ou e-mail | **Prévia completa** (destinatário, canal, texto) + confirmação explícita na tela; nunca só por voz; sujeito a D-WA |
| N4 | Proibido | Decidir crédito, mudar status de crédito, escolher instituição, mudar permissão, apagar dado, cobrança financeira, SQL, ação em nome de outro usuário | A ferramenta não existe |

### 4.2 Catálogo inicial proposto **[PROPOSTA]**

Os nomes são ilustrativos; os casos de uso reais dependem de **[INSPEÇÃO PENDENTE]**.

| Ferramenta | Nível | Caso de uso | Retorno |
|---|---|---|---|
| `buscar_registros(tipo, termo)` | N0 | Busca de organização, oportunidade ou operação já existente | Lista com IDs e links, no escopo do usuário |
| `abrir_registro(tipo, id)` | N0 | Leitura de ficha | Campos autorizados |
| `listar_pendencias(escopo)` | N0 | "O que precisa de ação hoje" | Itens com motivo e prazo |
| `consultar_metrica(metric_key, filtros)` | N0 | Consulta do catálogo BI-01 | Valor, fórmula, fonte, horário de atualização e linhas que compõem o número |
| `status_sla(operacao_id)` | N0 | SLA persistido | Horas úteis decorridas e restantes, pelo calendário oficial |
| `ler_documento(documento_id)` | N0 | **Extração documental existente** | Campos extraídos + confiança + página de origem |
| `rascunhar_relatorio(modelo, filtros)` | N1 | Monta relatório só com o resultado de `consultar_metrica` | Texto + tabela + fontes |
| `rascunhar_mensagem(contexto_id)` | N1 | Sugestão de texto | Texto para edição |
| `criar_tarefa(registro_id, titulo, prazo, responsavel)` | N2 | Caso de uso de tarefas (depende de D-TAR1) | Prévia → confirmação → recibo |
| `mover_oportunidade(id, fase_destino)` | N2 | Mesma regra de transição do Kanban | Prévia → confirmação → recibo; negação clara se não for permitido |
| `registrar_nota(registro_id, texto)` | N2 | Nota interna | Prévia → confirmação → recibo |
| `solicitar_documento(organizacao_id, itens, canal)` | N3 | Depende de D-WA e de consentimento | Prévia completa → confirmação → recibo; nunca cobra |

### 4.3 Regras de chamada **[PROPOSTA]**
- Argumentos validados por esquema no servidor; IDs são UUIDs que o servidor confere contra o escopo.
- Toda escrita (N2/N3) leva uma **chave de idempotência** gerada no servidor ao montar a prévia. Confirmar duas vezes não duplica.
- A prévia expira (ex.: 10 minutos) e é recalculada se o registro mudou.
- Resultado de ferramenta volta ao modelo marcado como **dado**, nunca como instrução.

---

## 5. Relatórios **[PROPOSTA]**

- Todo número de relatório vem de `consultar_metrica` (cálculo no servidor, mesmo escopo do usuário). O modelo só organiza e explica.
- Cada número traz a fonte (métrica, filtros, período, timezone America/Sao_Paulo, horário de atualização) e o link para o detalhamento.
- Ausência de dado é dita: "Não há cadastro de metas; este indicador não pode ser calculado". Nunca estimar nem usar zero.
- Elegibilidade documental nunca aparece como aprovação; receita faturada é separada de previsão; pedido emitido não é máquina faturada.
- **Exportar** (PDF ou CSV) gera o arquivo pelo mesmo serviço do BI, não pelo modelo.

---

## 6. Limites **[PROPOSTA]**, valores em D-AVA1 e D-AVA3

| Limite | Proposta de partida | Ao atingir |
|---|---|---|
| Orçamento mensal (R$) | **D-AVA1** (hoje: HOLD) | Bloqueia chamadas pagas; leitura sem modelo continua; aviso ao administrador |
| Orçamento por usuário por dia | D-AVA1 | Mensagem clara ao usuário |
| Contexto por chamada | Só o necessário: registro aberto + resultados das ferramentas; documento por trechos | Resumir antes, nunca truncar em silêncio |
| Chamadas de ferramenta por pergunta | Até 6 | Para e explica o que faltou |
| Tentativas por erro transitório | Até 2, com espera crescente; nunca para N3 | Erro terminal com referência |
| Concorrência | 1 pergunta ativa por usuário; fila por empresa definida em D-AVA3 | "Aguarde a resposta anterior" |
| Tempo máximo | 30 s por resposta e 15 s por ferramenta | Cancela e informa |
| Documento | Os limites existentes (20 MiB upload, 10 MiB catálogo) | Mensagem de limite do design system |

---

## 7. Auditoria, recibos e falhas **[PROPOSTA]**

- **Ledger** (já previsto no CTX, a reconciliar com o Codex): para cada interação, registrar
  - usuário, horário, versão de prompt, ferramentas e modelo;
  - ferramentas chamadas com argumentos **sanitizados**;
  - IDs dos registros lidos;
  - tokens e custo;
  - latência;
  - resultado.
  Nunca guardar o texto completo de documento nem dado pessoal em log.
- **Recibo** para N2 e N3: o que mudou, quando, por quem (usuário, com a Ava como canal), chave de idempotência e link para desfazer quando a regra permitir.
- **Falhas** visíveis com o estado de erro do design system:
  - provider indisponível;
  - orçamento atingido;
  - sem permissão (mesma tela de acesso negado);
  - dado ausente;
  - tempo esgotado.
  Erro nunca vira resposta inventada.
- **Prompt injection detectada** (ex.: documento pedindo para ignorar regras): a Ava responde só com os dados, registra o evento no ledger e não chama ferramentas sugeridas pelo conteúdo.

---

## 8. Onde ajustar quando algo der errado

Antes de trocar de modelo, identificar a camada:

| Sintoma | Camada provável | Ajuste |
|---|---|---|
| Resposta com dado de outro usuário | **Integração e autorização** | Corrigir o escopo no servidor (P0); não é problema de modelo |
| Número errado | **Cálculo determinístico** | Corrigir a métrica (BI-01) |
| Campo de documento errado ou faltando | **Extração** (OCR, layout, página) | Ajustar o extrator e o pré-processamento; medir por tipo de documento |
| Ignora regra ou formato | **Prompt** | Ajustar instruções versionadas |
| Resposta sem a informação que existia | **Contexto** | Rever o que entra no contexto e a busca |
| Qualidade baixa com tudo acima correto | **Modelo** | Avaliar outro modelo **dentro do orçamento aprovado** |

**Fine-tuning não é presumido.** Só seria considerado se a avaliação versionada mostrar falha persistente que prompt, contexto e extração não resolvem, e com decisão de custo própria.

---

## 9. Avaliação e calibração **[PROPOSTA]**

Um conjunto de avaliação **versionado** (`ava-eval vN`), com dados sintéticos ou anonimizados autorizados, sem acervo real enviado a terceiros:

| Dimensão | Casos | Métrica |
|---|---|---|
| Extração | Por tipo de documento (DRE, balanço, IR, contrato social…) | Acerto por campo; valores e datas exatos; página de origem correta |
| Dado ausente | Documento sem o campo pedido | Diz "não encontrado"; zero invenção |
| Valores e datas | Formatos pt-BR, milhar, negativos, períodos | Normalização exata |
| Permissões | Usuário A pede dado do escopo de B | 100% negado no servidor |
| Prompt injection | Instruções escondidas em documento ou mensagem | Nenhuma ferramenta disparada; evento registrado |
| Ferramentas | Escolha e argumentos | Ferramenta correta; nenhuma N2/N3 sem prévia |
| Idempotência | Confirmar duas vezes, retry, rede caindo | Nenhuma duplicação |
| Custo | Tokens por tipo de pergunta | Dentro do orçamento (D-AVA1) |
| Latência | p50 e p95 por tipo | Meta definida após baseline (CTX §7) |

Cada mudança de prompt, extrator ou modelo roda o conjunto inteiro, e o resultado fica registrado com a versão. A calibração de confiança da extração (limite para pedir revisão humana) é definida por tipo de documento a partir dessa avaliação.

---

## 10. Interface **[FATO]** no protótipo, **[PROPOSTA]** no Portal

- Barra da Ava na barra superior (`Ctrl+K`), com orbe pulsante.
- Faixa de briefing no painel (`.brief`).
- Sugestões em pílulas tracejadas no Inbox.
- Prévia de ação como diálogo `.dlg`, com o botão principal "Confirmar" e "Cancelar".
- Recibo como toast com link.
- Estados: pensando (orbe pulsando, botão Parar), erro, sem permissão, orçamento atingido e microfone ativo.
- Teste em 4 cenários reais escolhidos pelo Owner, com dados autorizados, antes de ampliar.

---

## 11. Critérios de aceite do contrato

1. Nenhuma ferramenta N4 existe no código.
2. Toda ferramenta reavalia a autorização no servidor; teste negativo com UUID alheio.
3. Nenhuma escrita sem prévia e confirmação; nenhuma escrita por voz sem confirmação na tela.
4. Todo número de relatório tem fonte e confere com o detalhamento.
5. Documento com injeção não dispara ferramenta (teste automatizado).
6. Retry não duplica (teste automatizado).
7. Ledger sem dado sensível (inspeção).
8. Limites ativos e testados; operação paga só depois de D-AVA1.
9. Leitura documental existente sem regressão (mesmos documentos, mesmos campos).

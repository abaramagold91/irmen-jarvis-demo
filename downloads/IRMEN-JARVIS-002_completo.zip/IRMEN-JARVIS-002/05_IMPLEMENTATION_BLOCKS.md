# IMPLEMENTATION_BLOCKS · Blocos de implementação

**Comando de origem:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Relação com o quadro:** DS-01 (referência e especificação) → DS-02 (aplicação por telas) · BI-01 (catálogo de métricas, dashboard e BI) · AVA-03 (assistente) · NOV-01 (módulos novos)

> Estes blocos são **especificação**. Nada aqui foi implementado no Portal real. A entrega desta especificação não declara implementação concluída.

## Regras comuns a todos os blocos

Cada comando abaixo é autocontido, mas todos herdam estas regras.

1. **Baseline primeiro.**
   - Antes de escrever código, conferir a baseline vigente. A referência atual é `abaramagold91/portal-irmen-v2`, branch `codex/f7-014-controlled-release`, commit `92c88f9dfee0a180eb91cc83192a64dbe11e3456`, e **pode ter mudado com a F7-015**.
   - Não partir de `main` presumindo que está atual.
   - Registrar no relatório o commit de partida.
2. **Um executor por bloco.**
   - Claude implementa o bloco delimitado numa branch própria. O Codex integra, testa e publica.
   - Ninguém edita os mesmos arquivos em paralelo. Os arquivos de runtime, recuperação e execução hospedada da Ava são do Codex.
3. **Arquitetura.**
   - UI → Application/Use Cases → Domain/Policies → Repositories/Read Models → Infrastructure.
   - A interface não acessa o banco direto.
   - A autorização é decidida no backend.
4. **Preservar:**
   - RLS, capabilities, UUIDs, vínculos, histórico e identificadores;
   - código do vendedor automático e permanente;
   - SLA e calendário persistidos;
   - elegibilidade, aprovação e desembolso distintos;
   - perda antes da OP pelo vendedor e depois da OP por solicitação à Mesa;
   - PED nas etapas autorizadas;
   - Filiais só em Configurações.
5. **Não fazer:**
   - multitenancy ou `workspace_id` generalizado;
   - acesso por equipe ou cargo inferido;
   - vendedor decidindo banco ou status de crédito;
   - dados de demonstração em produção;
   - comissões, estoque ou PDI;
   - reset, clean, prune ou purge;
   - apagar histórico.
6. **Banco.** Migração só quando o bloco realmente precisar e depois de comparar com o schema existente. Reforma de banco ou eventos **não** é pré-requisito para aplicar o visual.
7. **Referência visual:**
   - `DESIGN_SYSTEM_SPEC.md`;
   - `tokens/tokens.css`;
   - catálogo https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/;
   - protótipo https://abaramagold91.github.io/irmen-jarvis-demo/ (pacote `irmen-jarvis-referencia-fb6416c.zip`).
8. **Testes mínimos de toda tela:**
   - funcional;
   - negativo de permissão (no servidor);
   - visual nos dois temas em 1440, 1280, 820 e 390px;
   - sem rolagem lateral em 390px;
   - teclado e foco visível;
   - redução de movimento;
   - sem erro no console.
9. **Fechamento** com um dos registros do CTX: CORRIGIDO E VALIDADO, VERIFICADO SEM DEFEITO, REFUTADO COM EVIDÊNCIA, DECISÃO DE NEGÓCIO PENDENTE, ACEITE HUMANO PENDENTE ou BLOQUEIO TÉCNICO COMPROVADO.

## Ordem e dependências

| Ordem | Bloco | ID | Executor | Depende de |
|---|---|---|---|---|
| 1 | A · Tokens, componentes, shell e primeira tela (Funil) | DS-02.A | Claude | Baseline conferida; D-DS1 só para os ajustes de contraste |
| 2 | B1 · Organizações, contatos e documentos | DS-02.B1 | Claude | A |
| 3 | B2 · Operações, simulador, pedidos e PDF | DS-02.B2 | Claude | A |
| 4 | B3 · Mesa de Crédito | DS-02.B3 | Claude | A |
| 5 | B4 · Usuários, permissões, configurações e filiais | DS-02.B4 | Claude | A |
| 6 | B5 · Login, recuperação e solicitação de acesso | DS-02.B5 | Claude | A |
| 7 | C1 · Catálogo de métricas | BI-01.C1 | Claude (documento + read models propostos) | Inspeção da fundação BI |
| 8 | C2 · Dashboard por perfil e BI | BI-01.C2 | Claude | A, C1 |
| 9 | D1 · Reconciliação do contrato da Ava com o runtime | AVA-03.D1 | **Codex** | Trabalho hospedado do Codex concluído |
| 10 | D2 · Interface da Ava e ferramentas de leitura | AVA-03.D2 | Claude | A, C1, D1 |
| 11 | D3 · Ações governadas e voz | AVA-03.D3 | Claude | D2, D-AVA1…4 |
| 12 | E1 · Tarefas e notificações | NOV-01.E1 | Claude | A, D-TAR1, D-NOT1 |
| 13 | E2 · Suporte interno | NOV-01.E2 | Claude | A, D-SUP1 |
| 14 | E3 · Conversas | NOV-01.E3 | Claude | A, D-CONV1 |
| 15 | F1 · WhatsApp oficial (plano) | NOV-01.F1 | Claude (documento) | D-WA1…3 |
| 16 | F2 · Metas, XP e desafios | NOV-01.F2 | Claude | C1, D-GAM1…3 |

Os blocos B1 a B5 podem correr em sequência curta ou em paralelo **só** se tocarem arquivos diferentes (conferir na inspeção do A).

---

## Bloco A · DS-02.A · Tokens, componentes, shell e primeira tela integrada

```
DESTINO: CLAUDE (implementação delimitada) → CODEX (integração, testes, publicação)
COMANDO: IRMEN-DS-02-A-TOKENS-COMPONENTS-SHELL-FIRST-SCREEN
```

**Objetivo.** Levar os tokens e os componentes do design system homologado para o código do Portal e aplicá-los no shell autenticado e na tela Funil & Kanban, sem mudar regra de negócio.

**Dependências.**
- Baseline conferida.
- Referência DS-01.
- Os ajustes de contraste (D-DS1) entram atrás de uma variável; sem aceite, ficam os valores homologados.

**Localizar no código real (antes de escrever).**
1. Stack de estilo (CSS Modules, Tailwind, outro) e onde ficam variáveis e tema.
2. Componentes compartilhados existentes (botão, input, tabela, modal, badge, toast) e o design-lab da porta 3002 citado no CTX.
3. Layout autenticado, menu e como os itens são filtrados hoje.
4. Biblioteca de ícones e de gráficos, se houver.
5. A tela do funil: rota, componentes, caso de uso de transição e histórico.
6. Lista de rotas reais (FUN01) para garantir que nenhuma some do menu.

Entregar a lista acima como primeira seção do relatório, com caminhos e linhas.

**Interface e estados.**
- Tokens dos dois temas (`tokens/tokens.css`), aplicados pelo atributo de tema na raiz.
- Preferência de tema persistida sem flash: script mínimo antes da pintura, ou cookie lido no servidor.
- Componentes:
  - Button (padrão, primário com chanfro e laser, arc, ghost, sm; carregando; desabilitado; foco com anel chanfrado);
  - IconButton;
  - Segmented;
  - Pill e Badge;
  - Chip;
  - KpiTile;
  - DataTable (com cartões abaixo de 640px);
  - Field (padrão do login: ícone, erro com `aria-invalid`, ajuda);
  - Alert;
  - Dialog (com foco preso e devolvido);
  - Toast (`aria-live`);
  - EmptyState, ErrorState, ForbiddenState, Skeleton;
  - Icon.
- Shell: barra lateral, barra superior, gaveta móvel e rede neural global única (pausa quando oculta; quadro estático com redução de movimento).
- Funil & Kanban:
  - faixa de fases, Kanban e tabela;
  - arrastar com a regra real;
  - "Mover para…" por toque e teclado;
  - estados vazio, carregando, erro e acesso negado.

**Casos de uso, autorização, persistência, auditoria.**
- Nenhum caso de uso novo.
- O menu e a tela usam as capabilities devolvidas pelo servidor.
- A transição de fase continua no caso de uso existente, com o histórico existente.

**Migrações.** Nenhuma.

**Testes.**
- Funcionais: mover cartão permitido; mover negado mostra o aviso; histórico gravado; tabela e Kanban mostram os mesmos dados.
- Negativos: usuário sem capability não vê o item de menu, e a rota direta devolve acesso negado com o servidor negando os dados; UUID alheio na transição é negado.
- Visuais: comparação com o catálogo e o protótipo nos dois temas e quatro larguras.
- Mobile: carrossel de fases e colunas; sem rolagem lateral em 390px.
- Acessibilidade: foco visível em todos os controles, incluindo o botão chanfrado; ordem de tabulação; `aria-current` no menu; contraste conforme D-DS1.

**Desempenho, observabilidade, recuperação.**
- Medir antes e depois (LCP, INP, CLS) no desktop e no mobile.
- A rede neural não pode piorar o INP além da meta de 200ms no percentil 75.
- Sem logs novos de dado pessoal.
- Mudança só de interface, revertida pelo deploy anterior.

**Critérios de aceite.**
1. Todas as rotas atuais continuam acessíveis.
2. Funil com a mesma regra e o mesmo histórico.
3. Visual igual à referência nas larguras citadas.
4. Testes negativos de permissão passando no servidor.
5. Nenhum dado de demonstração.

**Limites.** Não redesenhar as outras telas neste bloco; elas usam o shell novo com o conteúdo antigo até o bloco B.

---

## Bloco B · DS-02.B · Telas existentes com preservação funcional

Cada sub-bloco tem a mesma estrutura. Para todos:
- **dependência:** bloco A integrado;
- **executor:** Claude;
- **migrações:** nenhuma, salvo indicação;
- **limite:** só visual e estados, sem mudar regra.

### B1 · Organizações, contatos e documentos
```
COMANDO: IRMEN-DS-02-B1-ORGANIZATIONS-CONTACTS-DOCUMENTS
```
- **Localizar:**
  - cadastro e detalhe de cliente;
  - modelo de contato;
  - vínculos com oportunidade e operação;
  - upload, download e ZIP;
  - limites configurados (20 MiB e 10 MiB).
- **Interface:**
  - lista com busca e filtro de pendência;
  - ficha 360º (cabeçalho, indicadores, contatos, checklist, negócios, linha do tempo), mostrando **só** o que tiver fonte;
  - upload com progresso e erro de tipo e de tamanho.
- **Regras:** dedupe por CNPJ como já existe; edição só autorizada; download só com acesso.
- **Testes:**
  - persistência após recarregar;
  - vínculos intactos;
  - upload acima do limite negado;
  - download por outro usuário sem acesso negado no servidor;
  - ZIP com o mesmo conteúdo.
- **Aceite:** FUN02 e DOC01 sem regressão; visual da referência.
- **Decisão:** D-CRM1 (nome do menu e contato como entidade). Sem decisão, mantém "Clientes".

### B2 · Operações, simulador, pedidos e PDF
```
COMANDO: IRMEN-DS-02-B2-OPERATIONS-SIMULATOR-ORDERS-PDF
```
- **Localizar:**
  - emissão de OPP, OP e PED e seus formatos reais;
  - regras do simulador e fonte das taxas;
  - snapshots;
  - gerador de PDF;
  - campos de emissor e beneficiário (FUN06).
- **Interface:**
  - jornada OPP → OP → PED;
  - tabela de operações;
  - assistente em etapas no visual novo (só as etapas que já existem);
  - PDF com a identidade nova.
- **Regras:**
  - o vendedor não escolhe banco;
  - taxa só da fonte canônica;
  - pedido emitido não é faturado;
  - códigos ilustrativos do protótipo **não** são regra.
- **Testes:**
  - mesmo cálculo antes e depois em 10 casos de referência (quantidade, entrada, prazo, arredondamento);
  - retry sem duplicar código;
  - PDF igual ao snapshot.
- **Aceite:** FUN04 e FUN05 sem regressão.
- **Decisão:** D-SIM1 (comparação entre instituições visível ao vendedor). Sem decisão, não mostrar.

### B3 · Mesa de Crédito
```
COMANDO: IRMEN-DS-02-B3-CREDIT-DESK
```
- **Localizar:**
  - fases e status reais;
  - cálculo do SLA e calendário persistido;
  - telas de decisão;
  - desembolsador.
- **Interface:**
  - esteira com contagem e SLA por fase;
  - fila ordenada por SLA;
  - ficha com pendências;
  - gráficos de instituição **só** com métrica de C1.
- **Regras:**
  - Aprovada e Desembolsada distintas;
  - no máximo um desembolsador;
  - decisão humana;
  - SLA de 20 horas úteis, 8h–18h, de segunda a sexta, America/Sao_Paulo, feriados nacionais.
- **Testes:**
  - SLA de 5 operações conferido à mão com o calendário;
  - vendedor sem acesso à fila (negado no servidor);
  - decisão registrada com autor.
- **Aceite:** esteira e SLA idênticos à regra; nenhum número sem fonte.

### B4 · Usuários, permissões, configurações e filiais
```
COMANDO: IRMEN-DS-02-B4-USERS-PERMISSIONS-SETTINGS
```
- **Localizar:**
  - fluxo de solicitação e convite, aprovação, bloqueio e recuperação;
  - papéis canônicos e capabilities;
  - configurações e unidades.
- **Interface:**
  - tabela de pessoas com estado (pendente, ativo, bloqueado);
  - matriz de capabilities em leitura, alterável só com capability;
  - configurações em abas;
  - Filiais só ali.
- **Regras:**
  - não bloquear o único coordenador;
  - toda mudança de papel e capability auditada;
  - código do vendedor gerado e imutável.
- **Testes:**
  - aprovar, bloquear e desbloquear pela interface;
  - usuário bloqueado com sessão antiga negado no backend (SEC03);
  - tentativa de mudar o próprio papel pelo cliente negada.
- **Aceite:** USR01 e SEC02 sem regressão.

### B5 · Login, recuperação e solicitação de acesso
```
COMANDO: IRMEN-DS-02-B5-LOGIN-RECOVERY-ACCESS-REQUEST
```
- **Localizar:**
  - página de login;
  - fluxo de recuperação (link ou código);
  - tela de solicitação de acesso existente;
  - política de senha;
  - mensagens de erro.
- **Interface:**
  - exatamente a homologada (`HOMOLOGACAO.md` §3);
  - "Solicitar primeiro acesso" leva à tela existente;
  - se a recuperação for por link, trocar a etapa de código pelo aviso "enviamos um link", no mesmo visual.
- **Regras:**
  - sem enumeração de contas;
  - limite de tentativas no servidor;
  - token sem replay e limpo da URL;
  - redirecionamento só para rotas internas.
- **Testes:**
  - login válido e inválido;
  - bloqueio por tentativas;
  - recuperação completa com usuário legítimo;
  - link reutilizado negado;
  - conta inexistente com a mesma resposta;
  - dois temas e cinco larguras.
- **Aceite:** SEC01 e SEC03 sem regressão; texto e visual iguais à homologação.

---

## Bloco C · BI-01 · Dashboard e BI canônicos

### C1 · Catálogo de métricas
```
COMANDO: IRMEN-BI-01-C1-METRIC-CATALOG
```
- **Objetivo:** para cada indicador mostrado no protótipo e nas 8 perguntas de gestão do CTX §8, escrever o **contrato de métrica** e dizer se a fonte existe.
- **Localizar:** fundação BI existente, views e consultas, eventos ou histórico de transições, cadastro de metas.
- **Entregar** uma tabela com:
  - `metric_key`;
  - nome simples;
  - pergunta;
  - fórmula;
  - grão;
  - entidade;
  - fonte (tabela ou view real com caminho);
  - datas e timezone;
  - estados incluídos e excluídos;
  - moeda;
  - filtros;
  - escopo (own, equipe ou empresa, conforme capability);
  - atualização;
  - detalhamento;
  - tratamento de ausência;
  - **situação: disponível / lacuna / decisão**.
- **Regras:**
  - não fabricar zero;
  - sem porcentagem com denominador indefinido;
  - receita faturada separada de previsão;
  - elegibilidade não é aprovação;
  - pedido não é faturamento.
- **Migrações:** nenhuma. Se uma métrica precisar de read model novo, **propor** com a comparação ao schema e esperar aprovação.
- **Aceite:** cada métrica com fonte real ou marcada como lacuna; validação manual de 3 métricas contra a lista de registros.

### C2 · Dashboard por perfil e BI
```
COMANDO: IRMEN-BI-01-C2-DASHBOARD-AND-BI
```
- **Dependências:** A e C1.
- **Interface:**
  - painel com "precisa de ação hoje", KPIs e evolução, por perfil;
  - BI com filtros, tooltips, legendas, totais e detalhamento até os registros;
  - "ver como tabela" em cada gráfico;
  - contrato da métrica visível;
  - estados carregando, erro e métrica indisponível.
- **Regras:**
  - mesmo escopo no agregado e no detalhe;
  - ranking amplo só com capability;
  - meta só se houver cadastro.
- **Testes:**
  - total do gráfico igual à soma do detalhamento (5 casos por painel);
  - vendedor vê só o próprio escopo nos dois;
  - filtros persistem na navegação;
  - desempenho com o volume real (paginação no detalhamento).
- **Aceite:** DASH01 e BI02 com os critérios do CTX; Owner aceita os painéis.

---

## Bloco D · AVA-03 · Ava contextual, relatórios, voz e ações governadas

O contrato completo está em `AVA_ASSISTANT_CONTRACT.md`.

### D1 · Reconciliação com o runtime (Codex)
```
DESTINO: CODEX
COMANDO: IRMEN-AVA-03-D1-CONTRACT-RECONCILIATION
```
- **Objetivo:** comparar o contrato AVA-03 com o runtime, a recuperação e a execução hospedada que o Codex concluiu. Apontar onde já atende, onde diverge e onde falta, sem mudar a leitura documental existente.
- **Entregar:**
  - mapa de arquivos (prompts, ferramentas, ledger, limites, worker e cron);
  - lista de ferramentas existentes;
  - como a autorização é checada em cada chamada;
  - limites atuais;
  - formato do ledger.
- **Aceite:** tabela "contrato × implementação" com o caminho e as linhas de cada item.

### D2 · Interface da Ava e ferramentas de leitura
```
COMANDO: IRMEN-AVA-03-D2-UI-AND-READ-TOOLS
```
- **Dependências:** A, C1 e D1.
- **Interface:**
  - barra `Ctrl+K`;
  - tela Ava;
  - briefing do painel;
  - fontes em cada resposta;
  - botão Parar;
  - estados (pensando, erro, sem permissão, orçamento atingido).
- **Ferramentas:** só N0 e N1 (`buscar_registros`, `abrir_registro`, `listar_pendencias`, `consultar_metrica`, `status_sla`, `ler_documento`, `rascunhar_relatorio`, `rascunhar_mensagem`), ligadas a casos de uso existentes.
- **Testes:**
  - UUID alheio negado;
  - documento com injeção não dispara ferramenta;
  - número do relatório igual ao do BI;
  - leitura documental sem regressão.
- **Limite:** operação paga só após D-AVA1. Antes disso, testar com o modo sem custo definido em D1.

### D3 · Ações governadas e voz
```
COMANDO: IRMEN-AVA-03-D3-GOVERNED-ACTIONS-AND-VOICE
```
- **Dependências:** D2 e as decisões D-AVA1 a D-AVA4 (D-AVA2 só para a parte de voz).
- **Ferramentas:** N2 (`criar_tarefa`, `mover_oportunidade`, `registrar_nota`) com prévia, confirmação, idempotência e recibo. N3 só depois de D-WA.
- **Voz:**
  - botão explícito;
  - transcrição editável;
  - cancelar;
  - fallback para texto;
  - nunca executa ação só por voz.
- **Testes:**
  - confirmar duas vezes não duplica;
  - prévia expirada é recalculada;
  - ação negada pela regra mostra o motivo;
  - voz sem confirmação na tela não altera nada.
- **Aceite:** os critérios 1 a 9 do contrato.

---

## Bloco E · NOV-01 · Tarefas e notificações, suporte e conversas

### E1 · Tarefas e notificações
```
COMANDO: IRMEN-NOV-01-E1-TASKS-NOTIFICATIONS
```
- **Dependências:** A, D-TAR1 e D-NOT1.
- **Localizar:** onde vivem hoje as próximas ações e se existe algum aviso ao usuário.
- **Interface:**
  - tarefas atrasadas, de hoje e próximas;
  - agenda semanal;
  - concluir, reatribuir e adiar;
  - sino com lista, marcar como lida e ir ao registro.
- **Casos de uso:** criar, concluir, reatribuir (com capability) e gerar notificação a partir dos eventos escolhidos em D-NOT1.
- **Migrações:** provável (tarefa e notificação), **só** depois de comparar com o schema e aprovar a proposta.
- **Testes:**
  - tarefa de outro vendedor invisível;
  - notificação não gerada para quem não tem acesso;
  - concluir duas vezes não duplica.
- **Aceite:** persistência, escopo e auditoria de reatribuição.

### E2 · Suporte interno
```
COMANDO: IRMEN-NOV-01-E2-INTERNAL-SUPPORT
```
- **Dependências:** A e D-SUP1.
- **Interface:** KPIs, tabela de chamados, abrir chamado, detalhe com histórico e base de conhecimento.
- **Regras:** o pedido de acesso é aprovado em Usuários & Permissões, nunca no chamado; o solicitante vê só os próprios chamados.
- **Migrações:** provável, após comparação e aprovação.
- **Aceite:** abrir, atribuir, responder e fechar com histórico; SLA conforme D-SUP1.

### E3 · Conversas
```
COMANDO: IRMEN-NOV-01-E3-CONVERSATIONS
```
- **Dependências:** A e D-CONV1.
- **Localizar:** o chat compartilhado existente (se houver).
- **Interface:**
  - lista;
  - conversa com estados de envio;
  - nota interna;
  - contexto do negócio;
  - sugestões da Ava como rascunho.
- **Regras:**
  - mensagem recebida é dado não confiável;
  - nota interna nunca sai;
  - sugestão não é enviada sem ação humana.
- **Aceite:** histórico persistido, escopo por D-CONV1 e falha de envio visível.

---

## Bloco F · NOV-01 · WhatsApp, metas, XP e desafios

### F1 · WhatsApp oficial (plano)
```
COMANDO: IRMEN-NOV-01-F1-WHATSAPP-OFFICIAL-PLAN
```
- **Objetivo:** documento de integração **oficial**, sem implementar envio, com:
  - provedor;
  - custo por conversa e por template;
  - consentimento e descadastro;
  - textos de template;
  - roteamento por fila;
  - armazenamento de mídia com os limites de documento;
  - segredos no cofre.
- **Regras:**
  - a conexão não oficial fica **desligada** por padrão;
  - pedir documento não autoriza cobrança;
  - nenhum envio real nesta etapa.
- **Aceite:** Owner decide D-WA1 a D-WA3 com base no documento.

### F2 · Metas, XP e desafios
```
COMANDO: IRMEN-NOV-01-F2-GOALS-XP-CHALLENGES
```
- **Dependências:** C1 (métricas de resultado) e D-GAM1 a D-GAM3.
- **Interface:** a do protótipo `#arena` (nível, metas, desafios, liga por gerência, ranking, conquistas).
- **Regras:**
  - XP só por resultado confirmado (ex.: faturamento validado);
  - nada por clique;
  - nada ligado à aprovação de crédito;
  - liga compara gerências, sem expor pessoas de outras equipes sem capability;
  - comissões fora.
- **Migrações:** provável (metas, desafios, ledger de pontos imutável), só após comparação e aprovação.
- **Testes:**
  - pontos recalculáveis a partir do ledger;
  - estorno quando o faturamento é cancelado;
  - nenhuma pontuação duplicada.
- **Aceite:** contrato aprovado pelo Owner antes de qualquer código.

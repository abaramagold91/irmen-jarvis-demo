# IRMEN-JARVIS-002 · Pacote completo

Entrega do comando IRMEN-JARVIS-002 (design system e plano de implementação).
Status: **ACEITE HUMANO PENDENTE**. Nada foi implementado no Portal real.

## Como usar
- Para colar num só lugar: `00_TUDO_EM_UM.md` traz todos os documentos em sequência.
- Para ler por partes: os arquivos de 01 a 07, na ordem abaixo.

| Arquivo | Conteúdo | ID |
|---|---|---|
| 01_MANIFESTO_DE_VERSAO.md | Referência fixada (commit fb6416c) e checksums | DS-01 |
| 02_DESIGN_SYSTEM_SPEC.md | Tokens, componentes, acessibilidade | DS-01 |
| 03_FUNCTIONAL_GAP_MATRIX.md | Protótipo × Portal, 23 itens | PLAN-01 |
| 04_AVA_ASSISTANT_CONTRACT.md | Contrato da Ava, níveis N0–N4 | AVA-03 |
| 05_IMPLEMENTATION_BLOCKS.md | Comandos autocontidos A–F | DS-02, BI-01, NOV-01 |
| 06_DECISIONS_REQUIRED.md | 18 decisões do Owner | — |
| 07_PROPOSTA_ATUALIZACAO_QUADRO.md | Proposta para o quadro (não alterado) | — |
| tokens/ | tokens.css e tokens.json | DS-01 |
| referencia/ | Protótipo completo homologado (fb6416c) | DS-01 |

Catálogo navegável: https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/

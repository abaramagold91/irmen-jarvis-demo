# IRMEN-JARVIS-002 · Documento único consolidado

Status: ACEITE HUMANO PENDENTE. Especificação e protótipo apenas; nada foi implementado no Portal real.


---

<!-- ARQUIVO 01_MANIFESTO_DE_VERSAO.md -->

# MANIFESTO_DE_VERSAO · Referência visual homologada

**ID:** DS-01 · **Comando:** IRMEN-JARVIS-002 · **Gerado em:** 22/10/2026

## Identificação

| Campo | Valor |
|---|---|
| Repositório | `abaramagold91/irmen-jarvis-demo` (protótipo; **não** é o Portal real) |
| Branch | `main` |
| Commit deste pacote | `fb6416ce1ec1264b94ae9dc2faf72a558803960f` |
| Prévia do sistema | https://abaramagold91.github.io/irmen-jarvis-demo/ (idêntica a `/previa-mobile/`) |
| Prévia do login | https://abaramagold91.github.io/irmen-jarvis-demo/login/ |
| Catálogo | https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/ |
| Homologação do Owner | Sistema e mobile: aprovados; login: aprovado em 22/10/2026 ("aprovado, dado como homologado") |

A referência pedida no comando (`/previa-mobile/`) e a raiz publicada têm os **mesmos bytes**: `index.html`, `app.js`, `data.js`, `screens.js`, `mobile.css` e `mobile.js` são idênticos nas duas pastas. A cópia em `/previa-mobile/` foi mantida para que o link antigo continue funcionando.

## Histórico de revisões relevantes

| Commit | O que mudou |
|---|---|
| `f6d3dbe` | Publicação do protótipo desktop aprovado (CDN trocado por cópias locais) |
| `26fb3dd` | Camada mobile (`mobile.css`, `mobile.js`) em `/previa-mobile/` |
| `8fba152` → `5feb922` | Tela de login e recuperação, ajustes de cor, textos e radar até a versão homologada |
| `632878a` | Camada mobile passa a valer na raiz; o login leva à raiz |
| `fb6416c` | Catálogo navegável (`catalogo/`), sem alterar nenhum arquivo do sistema ou do login |

## Arquivos-chave (SHA-256)

| Arquivo | SHA-256 |
|---|---|
| `index.html` (shell + CSS + tokens) | `f830d7b7452a2fa26ac9ebaf4cf76d75fcbb8175fd53dc7310f13ad404768fa7` |
| `app.js` | `99d99ef2003ed56e9b88a9c8ea02ac6abf9237f936b8555f6342eddbdbd8ba81` |
| `screens.js` | `35a39acb5c017625b30cbd12fbc46ba838fd2a0dececf73c373000c16e2c9c78` |
| `data.js` | `b9cfd9f5fd6053dc8f5430c3bf78a003d45b8c20c3393e795aee75eb384b52ae` |
| `mobile.css` | `c848f70e5fa49d66ab1e7af5763b91f396c4d837ffdeac67ce7ac81343e7702f` |
| `mobile.js` | `8879cc03466d6f901ffab5a53d6ce25febbfaf276fb1f98e65ce8fb184073b6a` |
| `login/index.html` | `16c2bd2ee6afea1cf9861485356959f8d5b75d4bb69bcfa6162ffcc697824dc5` |
| `vendor/echarts/echarts.min.js` (5.5.0) | `42f8329d989b6f6539dd2b15bbdf0d82025762ac112fbb60dc57b27d7bcf3946` |
| `vendor/fonts/fonts.css` | `f3fe342ae5916374882a3e5d431c38d1c6aef7192b270e909a49a859e8651be5` |
| `catalogo/sistema.css` (gerado) | `362229cbac7719b013df38028575564f4f63b153a5fc01c8608220647bff4341` |
| `catalogo/login-partes.css` (gerado) | `bb049fcd2b77c99cb6ebe3927d514ead81f4af83f58977a410bbad26d2cc1832` |

A lista completa (75 arquivos) está em `SHA256SUMS.txt`. Para conferir: `sha256sum -c SHA256SUMS.txt` dentro desta pasta.

## Conteúdo

| Caminho | O que é |
|---|---|
| `index.html`, `app.js`, `screens.js`, `data.js` | Sistema: 16 telas, 5 papéis de demonstração, fluxos guiados |
| `mobile.css`, `mobile.js` | Camada de celular e tablet (só age até 860px; trava de rolagem lateral em telas de toque até 1280px) |
| `login/index.html` | Login, recuperação de senha e solicitação de primeiro acesso (autocontido) |
| `catalogo/` | Catálogo de componentes; `gerar.py` recria `sistema.css` e `login-partes.css` a partir dos arquivos acima |
| `vendor/` | ECharts 5.5.0 e fontes (Chakra Petch, IBM Plex Sans, JetBrains Mono), com licenças |
| `documentacao/` | Roteiro de navegação, arquitetura do protótipo, ajuste mobile, relatório de verificação, licenças, `package.json`/`package-lock.json` com as versões |
| `previa-mobile/` | Cópia idêntica do sistema, mantida pelo link antigo |

## Licenças

- **Apache ECharts 5.5.0:** Apache 2.0 (`vendor/echarts/LICENSE`, `NOTICE`).
- **Fontes:** SIL OFL 1.1 (`vendor/fonts/LICENSE-*.txt`).
- **Ícones:** SVG próprios do protótipo.
- **Dados:** fictícios.

O detalhamento está em `documentacao/LICENCAS-DE-TERCEIROS.md`.

## Como abrir

```bash
cd irmen-jarvis-referencia
python3 -m http.server 8765 --bind 127.0.0.1
# http://127.0.0.1:8765/login/   http://127.0.0.1:8765/   http://127.0.0.1:8765/catalogo/
```

Não faz requisição externa nem precisa de build.

## Limites

Este pacote é **referência visual**. Os dados são fixos, a autenticação é simulada e não há backend. Ele não comprova funcionamento, segurança, desempenho nem prontidão de nenhum módulo do Portal IRMEN.

---

<!-- ARQUIVO 02_DESIGN_SYSTEM_SPEC.md -->

# DESIGN_SYSTEM_SPEC · Portal IRMEN (Jarvis)

**ID:** DS-01 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Fonte:** protótipo homologado `abaramagold91/irmen-jarvis-demo` @ `fb6416c` (ver `MANIFESTO_DE_VERSAO.md`)
**Tokens:** `tokens/tokens.css` e `tokens/tokens.json` (gerados por script a partir de `index.html`)
**Catálogo navegável:** https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/

## Como ler este documento

Cada afirmação traz uma marca:

| Marca | Significado |
|---|---|
| **[FATO]** | Extraído dos arquivos publicados do protótipo, com seletor ou arquivo citado |
| **[PROPOSTA]** | Estado ou regra que faltava, desenhado no mesmo padrão visual; não homologado |
| **[AJUSTE]** | Correção de acessibilidade medida no protótipo; muda pouco o visual e pede aceite do Owner |
| **[INSPEÇÃO PENDENTE]** | Depende de ler o código real do Portal (`portal-irmen-v2`), que não foi acessado nesta etapa |
| **[DECISÃO PENDENTE]** | Escolha de negócio ou de custo, listada em `DECISIONS_REQUIRED.md` |

Este documento descreve o visual. Não comprova funcionamento, segurança nem prontidão de nenhum módulo do Portal real.

---

## 1. Princípios

1. **[FATO]** Dois temas: escuro (Jarvis, padrão) e Slate claro, trocados pelo atributo `data-theme` na raiz. Todos os componentes leem só variáveis CSS; nenhuma cor fixa em componente, exceto os quatro casos listados em 2.4.
2. **[FATO]** Superfícies de vidro sobre uma rede neural global: um único canvas fixo no fundo, nunca um por cartão.
3. **[FATO]** Vermelho da marca (`--brand`) para ação principal, item ativo e destaque. Ciano (`--arc`) para tecnologia: foco, seleção, Ava, rede neural.
4. **[FATO]** Chanfros como assinatura: botão principal, logo e cantoneiras HUD.
5. **[PROPOSTA]** Tokens e componentes ficam versionados no código do Portal. Só a configuração empresarial editável (nome, logo, cor de marca, textos legais) vem de fonte canônica já existente quando houver **[INSPEÇÃO PENDENTE]**. O design system inteiro não vai para o banco.

---

## 2. Tokens

### 2.1 Cores semânticas **[FATO]**

| Token | Escuro | Slate claro | Uso |
|---|---|---|---|
| `--bg` | `#06080c` | `#e6eaf0` | Fundo da página |
| `--bg-2` | `#0a0e14` | `#dde3ea` | Fundo de controles (input, botão padrão, segmentado) |
| `--panel` | `rgba(13,18,26,.78)` | `rgba(255,255,255,.86)` | Vidro de painéis e barras |
| `--panel-solid` | `#0d121a` | `#ffffff` | Diálogos, tooltips, cartões do Kanban |
| `--panel-2` | `rgba(20,27,38,.85)` | `rgba(244,247,250,.95)` | Gradiente da barra lateral, avatar |
| `--line` | `rgba(140,190,220,.13)` | `rgba(30,50,70,.12)` | Bordas e divisórias |
| `--line-2` | `rgba(140,190,220,.24)` | `rgba(30,50,70,.22)` | Bordas de controles |
| `--fg` | `#e8eef4` | `#0f1722` | Texto principal |
| `--fg-2` | `#a3b0bd` | `#3f4b58` | Texto secundário |
| `--fg-3` | `#8592a0` | `#5a6673` | Rótulos, apoio, eixos |
| `--brand` | `#ef3f4f` | `#d42a3a` | Ação principal, ativo, destaque |
| `--brand-ink` | `#ffffff` | (herda) | Texto sobre `--brand` |
| `--brand-soft` | `rgba(239,63,79,.14)` | `rgba(212,42,58,.10)` | Fundo de item ativo, ícone de KPI |
| `--arc` | `#3fd0ff` | `#0a7aa8` | Foco, seleção, Ava, links do sistema |
| `--arc-soft` / `--arc-glow` | `.12` / `.35` | `.10` / `.25` | Hover, brilho do orbe |
| `--good` | `#34c38f` | `#137a50` | Sucesso, aprovado |
| `--warn` | `#f2b84b` | `#94600a` | Pendente, atenção |
| `--crit` | `#ff6b7a` | `#c01f33` | Erro, atrasado |
| `--violet` | `#a594ff` | `#5b4bd6` | Barra de XP (gradiente com `--arc`) |
| `--c1`…`--c5` | `#ef3f4f #1aa3cf #c0821a #8a78f0 #22a06b` | `#d42a3a #0b84b8 #b7791f #6c5ce7 #16935f` | Séries de gráficos, nesta ordem |
| `--net` / `--net-2` | `63,208,255` / `239,63,79` | `10,122,168` / `212,42,58` | RGB da rede neural (normal / quente) |
| `--shadow` | `0 10px 40px rgba(0,0,0,.45)` | `0 8px 30px rgba(20,40,60,.10)` | Elevação |

Cada cor tem um `-soft` correspondente (`--good-soft`, `--warn-soft`, `--crit-soft`) para fundos de badge e alerta. A lista completa está em `tokens/tokens.css`.

### 2.2 Tipografia **[FATO]**

| Token | Família | Pesos carregados | Uso |
|---|---|---|---|
| `--f-display` | Chakra Petch | 500, 600, 700 | Títulos, eyebrows, cabeçalhos de tabela, valores de KPI, rótulos do radar |
| `--f-body` | IBM Plex Sans | 400, 500, 600 | Texto corrido, formulários |
| `--f-mono` | JetBrains Mono | 400, 500 | Códigos (OPP/OP/PED), valores em cartões, atalhos, horários |

| Papel | Especificação | Seletor |
|---|---|---|
| Título de tela | 700 · `clamp(22px, 2.4vw, 30px)` / 1.1 · `text-wrap: balance` | `.head h1` |
| Título do login | 700 · 26px / 1.15 | `.card h1` (login) |
| Título de painel | 600 · 13px · `letter-spacing .1em` · caixa alta | `.ph h3` |
| Eyebrow | 600 · 10.5px · `.18em` · caixa alta · `--arc` (login: `--brand`) | `.eyebrow` |
| Valor de KPI | 700 · `clamp(20px, 1.9vw, 26px)` · números tabulares | `.kpi .k-val` |
| Corpo | 400 · 14px / 1.45 | `body` |
| Apoio | 12px · `--fg-3` | `.li .s`, `.k-lbl` |
| Cabeçalho de tabela | 600 · 10.5px · `.14em` · caixa alta · `--fg-3` | `.tbl th` |

As fontes são servidas localmente (`vendor/fonts`, Fontsource 5.1.0, OFL 1.1), sem CDN.

### 2.3 Medidas, raios e chanfros **[FATO]**

| Item | Valor |
|---|---|
| Raio de painel | `--r: 10px` |
| Raio de controle | 8px (`.btn`, `.ibtn`, inputs, `.seg`) |
| Raio de diálogo, paleta e tour | 14px |
| Pílula | 999px |
| Chanfro do botão principal | 10px em dois cantos opostos (`clip-path`); 12px no login |
| Chanfro do logo | 22% em dois cantos opostos |
| Cantoneira HUD | 14px, borda 2px, opacidade .7, cor `--arc`; no login 16px, .75, cor `--brand` |
| Largura da barra lateral | `--side: 252px` |
| Espaçamentos | 16px entre blocos (`.grid`, `.view`); 10px em linhas e colunas (`.row`, `.col`); 8px entre fases; padding de painel 16px |
| Alturas de toque | 38px (`.btn`, `.nav a`, `.ibtn`), 30px (`.btn.sm`, `.seg button`), 42px (botões do login), 46px (inputs do login) |
| Largura máxima do conteúdo | 1680px (`.view`) |

### 2.4 Cores fixas fora dos tokens **[FATO]**

`#04121a` (texto do selo de nível), `#03131b` (texto do segmentado `arc` ativo), `rgba(3,6,10,.55)` (scrim) e `rgba(255,255,255,.45)` (feixe do laser). **[PROPOSTA]** Virar `--arc-ink`, `--scrim` e `--laser` na implementação.

---

## 3. Superfícies, camadas e ícones

**[FATO]**
- `.panel`: `--panel`, borda `--line`, `backdrop-filter: blur(10px)`, raio `--r`, padding 16px.
- `.panel.hud`: duas cantoneiras (superior esquerda e inferior direita) por `::before` e `::after`.
- `.brief` (faixa da Ava): gradiente `--arc-soft` → `--panel` e orbe de 42px.
- Barras (lateral e superior): desfoque de 14px.
- Brilho de fundo: dois gradientes radiais fixos (`--arc-soft` no topo direito, `--brand-soft` no rodapé esquerdo).

**Camadas (z-index) [FATO]:** rede neural e brilho 0 → shell 1 → barra superior 20 → faixa de safe-area 30 → tour 50 → menu móvel 55 → scrim e diálogos 60 → toasts 70.

**Ícones [FATO]:** desenhados em SVG em linha, 24×24, traço 1,7, pontas e junções arredondadas, `currentColor`, 18px por padrão. São 42 desenhos próprios em `data.js` (objeto `P`), sem biblioteca. **[PROPOSTA]** Na implementação, virar um componente `Icon` com a mesma geometria; se o Portal já tiver biblioteca de ícones, mapear um a um **[INSPEÇÃO PENDENTE]**.

---

## 4. Componentes

Para cada componente: o que existe **[FATO]**, o que falta **[PROPOSTA]** e o que corrigir **[AJUSTE]**. Os nomes de seletor são os do protótipo; os nomes de componente são sugestão para o Portal.

### 4.1 Botão (`Button`)
- **[FATO] Variantes:**
  - `.btn` (padrão: `--bg-2`, borda `--line-2`, hover com borda `--arc`);
  - `.btn.pri` (preenchido `--brand`, chanfro, laser);
  - `.btn.arc` (contorno ciano);
  - `.btn.ghost` (sem fundo);
  - `.btn.sm` (30px).
- **[FATO] Laser:** `::after` com gradiente de 100° (transparente → branco .45 → transparente) que atravessa o botão em 0,7 s no hover. No login, o laser também passa no foco por teclado.
- **[FATO] Carregando (login):** classe `.busy` + `disabled`, spinner de 16px no lugar da seta e rótulo trocado ("Entrando…").
- **[PROPOSTA] Desabilitado:** opacidade .5, `cursor: not-allowed`, sem laser.
- **[PROPOSTA] Carregando no sistema:** reutilizar o padrão do login em todos os botões que disparam escrita.
- **[AJUSTE] Foco:** o `clip-path` do botão chanfrado corta o contorno de foco; hoje o foco por teclado **não aparece** (verificado no catálogo). Proposta: anel de 3px em `--arc` desenhado por fora, com o mesmo chanfro (demonstração no catálogo, seção Botões).
- **[AJUSTE] Contraste:** texto branco sobre `--brand` escuro (`#ef3f4f`) dá **3,82:1**, abaixo de 4,5:1 para 13–14px. Proposta: token `--brand-fill: #de2f3f` só para fundos preenchidos no tema escuro (4,58:1), mantendo `--brand` para texto e ícones (5,24:1 sobre `--bg`) **[DECISÃO PENDENTE D-DS1]**.

### 4.2 Botão de ícone e segmentado
- **[FATO]** `.ibtn`: 38px; o ponto de notificação `.pip` usa `--brand`.
- **[FATO]** `.seg`: grupo com o botão ativo em `--brand` (ou em `--arc` na variante `.seg.arc`).
- **[PROPOSTA]** `aria-pressed` no item ativo do segmentado e `aria-label` obrigatório em todo `.ibtn`.

### 4.3 Badges, chips e contadores
- **[FATO]** `.pill` com ponto, nas variantes good, warn, crit, arc, brand, neutral e `.nodot`.
- **[FATO]** `.chip` alternável, ativo em `--arc`.
- **[FATO]** Contador `.cnt` (vermelho, ou ciano com `.arc`) e selo `.tagnew` ("NOVO") no menu.
- **[FATO]** `.sample` ("dado de exemplo") e `.delta` com as variantes `.up` e `.down`.
- **[PROPOSTA]** Status nunca só por cor: a pílula sempre leva texto (já é assim no protótipo) e `.delta` leva seta ▲/▼.
- **[PROPOSTA]** No Portal real, o selo "dado de exemplo" **não pode aparecer em produção**; sem dado, usar o estado "métrica indisponível" (4.14).

### 4.4 KPI (`KpiTile`)
- **[FATO]** Anatomia: ícone 30px (`--brand-soft` ou `--arc-soft`), rótulo, valor, minigráfico de 30px opcional, rodapé com variação. Altura mínima 132px.
- **[PROPOSTA]** Estados:
  - carregando: esqueleto;
  - sem fonte: "métrica indisponível", nunca zero fabricado;
  - erro: tentar de novo.
  Cada KPI aponta para o seu contrato de métrica (ver BI-01 em `IMPLEMENTATION_BLOCKS.md`).

### 4.5 Tabela (`DataTable`)
- **[FATO]**
  - Cabeçalho em display de 10,5px, caixa alta.
  - Linhas com divisória `--line` e hover em `--arc-soft`.
  - Números alinhados à direita e tabulares.
  - Largura mínima de 560px com rolagem no próprio contêiner.
- **[FATO] Mobile (≤ 640px):** cada linha vira cartão; `mobile.js` copia o texto do cabeçalho para `data-label` e o CSS mostra o rótulo à esquerda.
- **[PROPOSTA]**
  - Ordenação com `aria-sort`.
  - Paginação ou carregamento incremental, com o tamanho de página definido em BI-01/B.
  - Linha selecionável por teclado.
  - Estados vazio, carregando e erro dentro da área da tabela.

### 4.6 Lista com severidade
- **[FATO]** `.li` com barra lateral `.sev` (crit, warn, good, arc), título, apoio e coluna final.

### 4.7 Formulário
- **[FATO] Sistema:** `.field` (rótulo 12px, input/select de 38px, `--bg-2`, borda `--line-2`) e `range` com `accent-color: --brand`.
- **[FATO] Login (padrão mais completo, recomendado como base):**
  - ícone à esquerda dentro do campo (`.ctl`), altura de 46px;
  - foco com borda `--arc` + anel de 3px `--arc-soft`;
  - **erro** com `aria-invalid="true"`, borda e anel `--crit` e mensagem `.err` ligada por `aria-describedby`;
  - aviso de Caps Lock;
  - mostrar/ocultar senha com `aria-pressed`;
  - medidor de força com regras;
  - código de 6 dígitos com avanço automático e colar.
- **[FATO] Alertas:** `.alert` nas variantes crit, warn e good, com `role="alert"`.
- **[PROPOSTA]**
  - Validar ao sair do campo e no envio.
  - Levar o foco ao primeiro campo inválido (o login já faz isso).
  - Não limpar o que foi digitado em caso de erro de servidor.
  - Campos obrigatórios indicados no rótulo.

### 4.8 Navegação (shell)
- **[FATO]**
  - Barra lateral com grupos (`h6`), itens de 38px e item ativo com gradiente `--brand-soft` + barra de 3px `--brand` com brilho.
  - Barra superior com trilha (grupo em `--brand` + título), barra da Ava (pílula com orbe e `Ctrl K`), seletor de papel, tema e notificações.
  - Cartão do usuário com nível e XP no rodapé da barra lateral.
- **[FATO] Mobile:** a barra lateral vira gaveta (≤ 860px) e a barra superior fica em duas linhas.
- **[INSPEÇÃO PENDENTE]** O seletor "Ver o portal como" é recurso de demonstração. No Portal real, o menu deve refletir as capabilities do usuário vindas do servidor. Não pode existir troca de papel pelo cliente.
- **[AJUSTE]** No protótipo, abrir uma rota pelo endereço (`#mesa`) ignora o filtro de papel. No Portal, a rota precisa checar a autorização no servidor e mostrar "acesso negado" (4.14).

### 4.9 Fases e Kanban
- **[FATO]**
  - Faixa de 8 fases (`.phase`, com as variantes `.hot` e `.win`).
  - Colunas `.kcol` e cartões `.kcard`; destino de soltura `.drop`.
  - Arrastar entre as fases 1 a 6 funciona; soltar em Formalização ou Faturada é bloqueado com aviso.
- **[FATO] Toque:** tocar no cartão abre "Mover para…", que usa a mesma regra do arrastar.
- **[PROPOSTA]**
  - Mover por teclado (o mesmo diálogo "Mover para…" também no desktop).
  - Anúncio em `aria-live` da mudança.
  - Desfazer por 5 s quando a regra permitir.
  - A transição é sempre validada no servidor.

### 4.10 Conversas
- **[FATO]**
  - Lista de conversas, mensagens (`.msg`, `.msg.me`, `.msg.note` para nota interna), compositor e sugestões da Ava (`.suggest`, pílulas tracejadas em `--arc`).
  - Contexto do negócio na coluna da direita (só acima de 1280px).
- **[PROPOSTA]**
  - Estado de envio (enviando, enviado, falhou com reenviar).
  - Distinguir visualmente o canal (oficial, interno).
  - Nota interna sempre identificada como não enviada ao cliente.

### 4.11 Gráficos (`Chart`)
- **[FATO]** ECharts 5.5.0 com tema montado pela função `base()` de `app.js`:
  - paleta `--c1`…`--c5` em ordem;
  - texto em IBM Plex Sans `--fg-2`;
  - tooltip em `--panel-solid` com borda `--line-2`;
  - ponteiro de eixo em sombra `--arc-soft`;
  - legenda no topo à direita, ícone retangular arredondado de 10px;
  - eixos e grade em `--line` e rótulos em `--fg-3` 11px;
  - barras com raio de 4px no topo;
  - animação de 700ms.
- **[FATO]**
  - Ao trocar o tema, os gráficos são refeitos.
  - Clicar numa série abre o detalhamento.
  - Cada gráfico do BI tem um bloco "Contrato da métrica" (`<details class="contract">`).
- **[FATO] Mobile:** a legenda da rosca vai para baixo e os rótulos do funil diminuem quando a largura do gráfico fica abaixo de 420px.
- **[PROPOSTA]**
  - Tabela alternativa acessível para cada gráfico (botão "ver como tabela").
  - Animação 0 com redução de movimento.
  - Formatação pt-BR (R$, milhar com ponto).
  - Totais do gráfico conferidos com a lista detalhada.
- **[INSPEÇÃO PENDENTE]** Reutilizar a biblioteca de gráficos já usada no Portal; o requisito é o tema por tokens, não o ECharts em si.

### 4.12 Diálogo, paleta, toast e tour
- **[FATO]**
  - `.dlg`: `--panel-solid`, raio 14px, padding 20px, sobre `.scrim` com desfoque de 4px.
  - `.pal`: paleta `Ctrl+K` com borda `--arc-glow`.
  - `.toast`: fixo no topo à direita, borda esquerda `--good` (ou `--arc` para XP).
  - `.tour`: faixa inferior com borda e brilho `--arc`.
  - `Esc` fecha.
- **[AJUSTE]** Prender o foco dentro do diálogo, devolver o foco ao elemento de origem ao fechar e marcar o fundo como inerte.
- **[PROPOSTA]**
  - Toast de erro (borda `--crit`) com ação.
  - Toasts anunciados por `aria-live="polite"` (erro em `assertive`).

### 4.13 Metas e XP
- **[FATO]** `.challenge`, `.badge` (com a variante `.locked`), `.league`, barra de XP em gradiente `--arc` → `--violet` e selo de nível `.lvl`.
- **[DECISÃO PENDENTE]** As regras de XP, metas e desafios precisam de contrato aprovado; os componentes são só visuais.

### 4.14 Estados de tela

| Estado | Situação | Desenho |
|---|---|---|
| Vazio | **[FATO]** `.empty` | Borda tracejada, texto `--fg-3`, sugestão de próxima ação |
| Carregando | **[PROPOSTA]** | Esqueleto no formato final, só após 100ms sem resposta; com redução de movimento, sem brilho animado |
| Erro | **[PROPOSTA]** | Ícone em `--crit-soft`, título claro, "nada foi alterado" quando for verdade, referência curta para o suporte, "Tentar de novo" e "Abrir chamado" |
| Acesso negado | **[PROPOSTA]** | Ícone de cadeado em `--warn-soft`; diz que o perfil não inclui a área, sem revelar dados; "Voltar ao painel" e "Solicitar acesso" |
| Validação | **[FATO]** (login) | Ver 4.7 |
| Métrica indisponível | **[PROPOSTA]** | Diz qual fonte falta; não mostra número |
| Sucesso | **[FATO]** (login) | Selo `--good-soft` com ✓ e texto da consequência |

Todos estão no catálogo, seção Estados.

### 4.15 Login
- **[FATO]**
  - Composição em duas colunas: apresentação com radar, quatro cartões e rodapé de confiança à esquerda; cartão de acesso à direita.
  - Destaques em `--brand`; rede neural, orbe, radar e foco de campo em `--arc`.
  - Os textos aprovados estão em `HOMOLOGACAO.md`, seção 3.2.
  - Radar: feixe de 6s; cada nó acende em `--brand` enquanto o feixe passa.

---

## 5. Rede neural e movimento **[FATO]**

| Item | Regra |
|---|---|
| Canvas | Um só, `position: fixed`, `pointer-events: none`, z 0 |
| Densidade | `min(110, área/16000)` pontos; DPR máximo 2 |
| Pontos quentes | 8% dos pontos em `--net-2` (vermelho); os demais em `--net` |
| Ligações | Até 130px, opacidade até .22, traço .7 |
| Ponteiro | Repulsão em raio de ~148px; linhas ao ponteiro até 170px |
| Desempenho | Pausa com a aba oculta (`visibilitychange`); recria pontos ao redimensionar |
| Redução de movimento | Um quadro estático; sem animação de pontos |
| Tema | `recolor()` relê `--net` e `--net-2` ao trocar o tema |

**[PROPOSTA] Para o Portal:**
- Pausar também quando a janela perde o foco por muito tempo.
- Limitar a 30 fps em dispositivos fracos.
- Medir o custo (meta INP ≤ 200ms no percentil 75, conforme o plano do projeto) antes de aceitar.

**Outras animações [FATO]:**
- laser 0,7s;
- orbe 3,2s;
- toast 0,25s;
- entrada de vista no login 0,35s;
- radar do login (anéis de 14s e 9s, feixe de 6s).

Com `prefers-reduced-motion: reduce`, tudo é desligado.

---

## 6. Responsivo **[FATO]**

| Faixa | Comportamento |
|---|---|
| ≤ 1280px | KPIs de 6 colunas viram 3; o Inbox esconde o contexto; em telas de toque, a página fica travada na horizontal |
| ≤ 1024px | Grades de 3 e 4 colunas viram 2 |
| ≤ 860px | Gaveta de menu; barra superior em duas linhas; grades empilham (KPIs em 2); fases, Kanban, organizações e conversas viram carrosséis com encaixe e indicadores; Kanban por toque com "Mover para…" |
| ≤ 640px | Tabelas viram cartões; coluna do Kanban com 86% da largura |
| ≤ 420px | KPIs em 1 coluna |
| Login | ≤ 1380px reduz o radar e os títulos dos cartões; ≤ 1100px o radar some; ≤ 900px fica em uma coluna; entre 641 e 900px os cartões ficam em 4 colunas |

**Regra de rolagem [FATO]:** `html { overflow-x: hidden }` + `body { overflow-x: clip }`. Esconder nas duas tags transforma o `body` em contêiner de rolagem e quebra a página. A rolagem lateral só existe dentro dos carrosséis (`scroll-snap`).

Verificação já feita no protótipo:
- 16 telas × 4 larguras de desktop × 2 temas idênticas antes e depois da camada mobile;
- sem rolagem lateral no celular;
- login em 5 tamanhos × 2 temas.

O relatório está em `documentacao/RELATORIO-DE-VERIFICACAO.md` e `AJUSTE-MOBILE.md`.

---

## 7. Acessibilidade: medições e ajustes

Contraste medido sobre `--bg` (WCAG 2.x; texto pequeno precisa de 4,5:1 e elemento de interface, de 3:1):

| Par | Escuro | Claro | Situação |
|---|---|---|---|
| `--fg` / `--bg` | 17,15 | 14,92 | ok |
| `--fg-2` / `--bg` | 9,07 | 7,37 | ok |
| `--fg-3` / `--bg` | 6,31 | 4,85 | ok (claro sobre `--bg-2`: 4,54, no limite) |
| `--brand` / `--bg` | 5,24 | **4,15** | claro abaixo de 4,5 para texto pequeno |
| `--arc` / `--bg` | 11,15 | **3,99** | claro abaixo de 4,5 para texto pequeno (links, eyebrow) |
| branco / `--brand` (botão) | **3,82** | 5,01 | escuro abaixo de 4,5 |
| `--good`, `--warn`, `--crit` / painel | 8,4 / 10,5 / 6,8 | 5,4 / 5,3 / 6,0 | ok |

**Ajustes propostos** (preservam a identidade; pedem aceite do Owner em **D-DS1**):

1. **Foco visível em todos os controles:** anel `--arc` de 2px com afastamento de 2px. Nos chanfrados, anel externo com o mesmo chanfro (catálogo, Botões).
2. **Botão principal no escuro:** fundo `--brand-fill: #de2f3f` (4,58:1 com branco).
3. **Texto pequeno no claro:** usar `--brand-text: #c8283a` (4,55:1) e `--arc-text: #08709a` (4,58:1) quando o texto for menor que 18px e estiver direto sobre `--bg`. Sobre painel branco, os tokens atuais já passam (5,01 e 4,81).
4. **Diálogos:** prender o foco, devolvê-lo ao fechar e marcar o fundo como inerte.
5. **Teclado:** todo arrastar tem alternativa por teclado ("Mover para…"); a paleta `Ctrl+K` é navegável por setas; `Esc` fecha sobreposições.
6. **Toque:** alvos de no mínimo 38px (o protótipo já cumpre). Na implementação, recomenda-se 44px em telas de toque para ações frequentes.
7. **Leitores de tela:** `aria-live` para toasts e movimentações; tabela alternativa nos gráficos; `aria-current="page"` no item de menu ativo; `aria-busy` nos esqueletos.
8. **Transbordamento:** corrigir a sobra de 24px no painel da Diretoria em 1440px (achado do relatório de verificação). Manter a regra de rolagem da seção 6.
9. **Redução de movimento:** manter o comportamento atual (quadro estático, sem transições).

---

## 8. O que este documento não cobre

- Comportamento, dados, permissões e contratos do Portal real: ver `FUNCTIONAL_GAP_MATRIX.md` e `IMPLEMENTATION_BLOCKS.md`.
- Mapeamento para os componentes que já existem no Portal **[INSPEÇÃO PENDENTE]**: o primeiro passo do bloco A é localizar tokens, componentes e o design-lab (porta 3002) no código real e comparar com esta especificação antes de escrever código.

---

<!-- ARQUIVO 03_FUNCTIONAL_GAP_MATRIX.md -->

# FUNCTIONAL_GAP_MATRIX · Protótipo Jarvis × Portal IRMEN

**ID:** PLAN-01 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026

## Fontes e limites

| Fonte | O que dá | Limite |
|---|---|---|
| Protótipo homologado `irmen-jarvis-demo` @ `fb6416c` | Telas, fluxos e comportamento visual | Dados fixos, sem backend; não prova nada do Portal |
| "Portal IRMEN contexto e plano de conclusão" v1, 22/10/2026 (citado como **CTX**) | Contratos conhecidos, estado por módulo, IDs do plano (FUN, SEC, DOC, AVA, DS, BI, DASH…) | O próprio documento diz que não certifica código nem inventaria tudo |
| Código real `portal-irmen-v2` | — | **Não acessado nesta etapa.** Baseline de referência: branch `codex/f7-014-controlled-release`, commit `92c88f9d…3456`, que pode mudar com a F7-015 |

As marcas são as mesmas do DESIGN_SYSTEM_SPEC: **[FATO]** (protótipo ou CTX, com fonte), **[PROPOSTA]**, **[INSPEÇÃO PENDENTE]** e **[DECISÃO PENDENTE]**.

**Classificação:**
- **Existente:** já há função real; muda pouco ou nada.
- **Melhoria visual:** função real mantida, interface nova.
- **Extensão:** função real ganha capacidade nova.
- **Módulo novo:** não existe no Portal segundo as fontes.

**Regras gerais desta matriz:**
1. Nenhuma função real é removida por não aparecer no protótipo. Se o Portal tem algo que o protótipo não mostra, a função fica e ganha o visual novo.
2. O protótipo não comprova funcionamento, segurança nem prontidão de módulo. "Pronto" no Mapa do produto do protótipo é rótulo de desenho, não estado do Portal.
3. Nenhuma tabela nova é prescrita aqui. Onde o protótipo sugere dado novo, a matriz pede comparação com o schema existente **antes** de qualquer migração.
4. O estado inicial de cada módulo segue o CTX §4: publicado, demonstrado, pendente de prova, incompleto ou futuro.

---

## Quadro resumo

| # | Item | Classificação | Bloco | IDs do plano (CTX) | Inspeção do código real | Decisão nova |
|---|---|---|---|---|---|---|
| 01 | Shell, navegação e tema | Melhoria visual | A | DS01 | Sim | D-DS1 |
| 02 | Login, recuperação e primeiro acesso | Melhoria visual | A | SEC01, SEC03, USR01 | Sim | — |
| 03 | Painel (dashboard por perfil) | Melhoria visual + extensão | C | DASH01, BI01 | Sim | — |
| 04 | Clientes → Organizações & Contatos | Melhoria visual + extensão | B | FUN02 | Sim | D-CRM1 |
| 05 | Documentos | Existente + melhoria visual | B | DOC01 | Sim | — |
| 06 | Funil & Kanban | Melhoria visual | B | FUN03 | Sim | — |
| 07 | Operações (OPP → OP → PED) | Melhoria visual | B | FUN04 | Sim | — |
| 08 | Simulador / Nova Operação | Melhoria visual + extensão | B | FUN05 | Sim | D-SIM1 |
| 09 | Pedidos e PDF | Existente + melhoria visual | B | FUN05 | Sim | — |
| 10 | Mesa de Crédito | Melhoria visual + extensão | B | FUN04, SLA | Sim | — |
| 11 | Usuários & Permissões | Melhoria visual | B | USR01, SEC02 | Sim | — |
| 12 | Unidades e filiais (Configurações) | Melhoria visual | B | FUN06 | Sim | — |
| 13 | Relatórios & BI | Extensão | C | BI01, BI02 | Sim | D-BI1 |
| 14 | Ava | Extensão | D | AVA01, AVA02 | Sim (Codex em curso) | D-AVA1…4 |
| 15 | Tarefas & Agenda | Módulo novo ou extensão | E | — | Sim | D-TAR1 |
| 16 | Notificações | Extensão ou módulo novo | E | — | Sim | D-NOT1 |
| 17 | Suporte interno | Módulo novo | E | — | Sim | D-SUP1 |
| 18 | Conversas (Inbox) | Extensão (a confirmar) | E | — | Sim | D-CONV1 |
| 19 | WhatsApp | Módulo novo | F | — | Sim | D-WA1…3 |
| 20 | Metas, XP e desafios | Módulo novo | F | FUT01 (metas novas dependem de contrato) | Sim | D-GAM1…3 |
| 21 | Configurações gerais e white label | Extensão | B | — | Sim | — |
| 22 | Mapa do produto (tela do protótipo) | Não implementar | — | — | — | — |
| 23 | Localização | Existente (acesso externo) | — | CTX §4 | Sim | — |
| — | Comissões, estoque, PDI | Fora do escopo | — | FUT01 | — | — |

---

## Detalhamento

### 01 · Shell, navegação e tema
- **Classificação:** melhoria visual.
- **Resultado esperado:** barra lateral por grupos, barra superior com trilha, entrada da Ava, notificações, tema e usuário; dois temas sem flash na carga; gaveta no celular; rede neural global única.
- **Fonte disponível:**
  - **[FATO]** protótipo: `index.html` (shell), `app.js` (`renderSide`, `renderTop`, `go`), `mobile.css`/`mobile.js`;
  - **[FATO]** CTX §9 pede tema global persistido sem flash e contraste acessível.
- **Inspeção pendente:**
  - onde o Portal monta o layout autenticado;
  - como o menu decide os itens hoje;
  - se já existe preferência de tema;
  - o design-lab da porta 3002 (CTX §9).
- **Dados, regras, capabilities:**
  - itens de menu filtrados pelas **capabilities do usuário vindas do servidor**;
  - o seletor "Ver como" do protótipo **não** vai para o Portal;
  - Filiais só dentro de Configurações (CTX §4);
  - o contador do menu só aparece se houver fonte canônica.
- **Critério de aceite:**
  - todas as rotas atuais acessíveis pelo menu novo, sem perda;
  - dois temas em todas as telas;
  - sem rolagem lateral em 390px;
  - foco visível;
  - rota sem autorização mostra "acesso negado" e o servidor nega os dados.
- **Decisão nova:** D-DS1 (ajustes de contraste e foco).

### 02 · Login, recuperação e primeiro acesso
- **Classificação:** melhoria visual (a autenticação é do Portal).
- **Resultado esperado:** a tela homologada (textos em `HOMOLOGACAO.md` §3.2) ligada ao fluxo real.
- **Fonte disponível:**
  - **[FATO]** `login/index.html`;
  - **[FATO]** CTX §4: usuário por solicitação ou convite, aprovação pelo frontend autorizado, recuperação; convite real entregue por SMTP Titan.
- **Inspeção pendente:**
  - rota e componente de login atuais;
  - fluxo de recuperação (link ou código; o protótipo mostra código de 6 dígitos);
  - tela de solicitação de acesso existente;
  - política de senha.
- **Regras:**
  - mensagens que não revelam se o e-mail existe;
  - limite de tentativas no servidor;
  - token de recuperação sem replay e limpo da URL (SEC01/SEC03);
  - "Solicitar primeiro acesso" abre a tela de solicitação **já existente**.
- **Critério de aceite:**
  - texto e visual iguais à homologação;
  - recuperação real funcionando com um usuário legítimo;
  - sem enumeração de contas;
  - bloqueio e revogação testados conforme SEC03.
- **Decisão nova:** nenhuma.
- **Observação:** se o fluxo real usa link em vez de código, a tela de código é substituída pela tela do link no mesmo visual, sem mudar o fluxo de segurança por causa do mock.

### 03 · Painel (dashboard por perfil)
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** "o que precisa de ação hoje" com acesso aos registros, KPIs por perfil e evolução do faturamento, tudo de fontes canônicas no escopo do usuário (CTX §8).
- **Fonte disponível:**
  - **[FATO]** protótipo `#painel` (briefing da Ava, atalhos, 6 KPIs, "Precisa de ação hoje", medidor, evolução, linha do tempo);
  - **[FATO]** CTX: DASH01 incompleto segundo o Owner.
- **Inspeção pendente:** o dashboard atual, as fontes de cada número e a fundação BI existente.
- **Dados:** cada KPI precisa de contrato de métrica (BI-01) antes de virar tela. Sem fonte: estado "métrica indisponível", nunca zero.
- **Critério de aceite:**
  - cada número confere com a lista que o compõe;
  - mesmo escopo nos agregados e no detalhe;
  - vazio honesto;
  - medidor de meta só se existir cadastro de metas.
- **Decisão nova:** nenhuma além de BI.

### 04 · Clientes → Organizações & Contatos
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** lista com busca e filtro de pendência; ficha 360º com dados, contatos, checklist documental, negócios e linha do tempo.
- **Fonte disponível:**
  - **[FATO]** protótipo `#crm`;
  - **[FATO]** CTX §4 "Clientes e vínculos" (cadastro, edição autorizada, documentos e vínculos sem duplicação).
- **Inspeção pendente:**
  - modelo atual de cliente e contato (existe contato separado?);
  - deduplicação por CNPJ;
  - origem do checklist documental.
- **Regras:**
  - preservar UUIDs e vínculos existentes;
  - "Importar planilha" e "Cobrar pelo WhatsApp" dependem de outros itens (19) e de decisão.
- **Critério de aceite (FUN02):**
  - dados persistem após recarregar;
  - relações corretas;
  - nenhum vínculo perdido na troca de tela.
- **Decisão nova:** D-CRM1 (renomear "Clientes" para "Organizações & Contatos" e ter contato como entidade própria).

### 05 · Documentos
- **Classificação:** existente + melhoria visual.
- **Resultado esperado:** checklist por organização e operação, upload, download e ZIP com o visual novo.
- **Fonte disponível:**
  - **[FATO]** CTX §4: upload direto até 20 MiB, catálogo até 10 MiB, assinatura, tamanho, hash, autorização por ator, idempotência, download e ZIP;
  - o protótipo só mostra o checklist e a área de upload **sem função**.
- **Inspeção pendente:** componentes atuais de upload e lista, e os limites configurados.
- **Critério de aceite (DOC01):**
  - limites mantidos;
  - erro de tipo e de tamanho com a mensagem do design system;
  - progresso de envio;
  - download só para quem tem acesso.
- **Decisão nova:** nenhuma.

### 06 · Funil & Kanban
- **Classificação:** melhoria visual.
- **Resultado esperado:** 8 fases, Kanban e tabela, arrastar com validação, "Mover para…" no toque e no teclado.
- **Fonte disponível:**
  - **[FATO]** protótipo `#funil`, com o bloqueio em Formalização e Faturada;
  - **[FATO]** CTX §4 "Funil comercial" e FUN03.
- **Inspeção pendente:**
  - nomes e chaves reais das fases;
  - regra de transição;
  - quem pode mover;
  - registro de histórico;
  - regra de perda.
- **Regras:**
  - perda antes da OP é feita pelo vendedor; depois da OP, por solicitação à Mesa;
  - o servidor valida toda transição;
  - o protótipo bloqueia as fases 7–8 por regra visual, e a regra real vem do contrato.
- **Critério de aceite:**
  - criação do zero;
  - transições permitidas e negadas no servidor;
  - histórico com responsável;
  - escopo own respeitado;
  - edição concorrente sem perda.
- **Decisão nova:** nenhuma.

### 07 · Operações (OPP → OP → PED)
- **Classificação:** melhoria visual.
- **Resultado esperado:** jornada de códigos com histórico e tabela de operações.
- **Fonte disponível:**
  - **[FATO]** protótipo `#operacoes`;
  - **[FATO]** CTX §4: UUID como identidade, OP no formato `OP-{CODIGO_VENDEDOR}-{YYYYMMDD}-{SEQUENCIA}` (A…Z…AA), formatos de OPP e PED **a confirmar no contrato físico**.
- **Inspeção pendente:** emissão dos códigos e os formatos de OPP e PED.
- **Regras:**
  - código do vendedor automático e permanente;
  - PED nas etapas autorizadas, sem exigir OP ou aprovação universalmente;
  - pedido emitido **não** equivale a máquina faturada.
- **Critério de aceite (FUN04):** código correto, retry sem duplicação e histórico.
- **Decisão nova:** nenhuma.
- **Atenção:** os códigos do protótipo (ex.: `OP-DS-20261022-A`, `OPP-DS-0142`) são ilustrativos e não podem ser copiados como regra.

### 08 · Simulador / Nova Operação
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** assistente em etapas; no protótipo só a etapa "Condições" está desenhada.
- **Fonte disponível:**
  - **[FATO]** protótipo `#simulador`, com cálculo Price e **taxas fictícias**;
  - **[FATO]** CTX §4 "Simulador e pedidos" (regras canônicas, equipamentos por UUID, arredondamento, snapshots, sem taxa inventada).
- **Inspeção pendente:** regras e fonte das taxas, e etapas atuais.
- **Regras:**
  - vendedor não escolhe banco nem status de crédito;
  - a comparação entre instituições do protótipo **não** pode virar escolha do vendedor;
  - taxa só de fonte canônica.
- **Critério de aceite (FUN05):** itens por UUID e quantidade, taxa, totais, snapshot e PDF iguais ao cálculo canônico.
- **Decisão nova:** D-SIM1 (mostrar ou não comparação entre instituições ao vendedor, só informativa).

### 09 · Pedidos e PDF
- **Classificação:** existente + melhoria visual.
- **Resultado esperado:** PDF da proposta e do pedido com a identidade nova, que é configurável.
- **Inspeção pendente:** o gerador de PDF atual e os campos de emissor e beneficiário (FUN06).
- **Critério de aceite:** PDF confere com o snapshot; impressão legível; sem dado de demonstração.
- **Decisão nova:** nenhuma.

### 10 · Mesa de Crédito
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** esteira por fases com SLA, fila priorizada, desempenho por instituição e distribuição.
- **Fonte disponível:**
  - **[FATO]** protótipo `#mesa` (6 fases ilustrativas);
  - **[FATO]** CTX §4: ciclo Recebida → análise → decisões → formalização/faturamento → encerramento/cancelamento; Aprovada e Desembolsada distintas; no máximo um desembolsador; SLA de 20 horas úteis, 8h–18h, de segunda a sexta, America/Sao_Paulo, feriados nacionais.
- **Inspeção pendente:**
  - fases e status reais (as 6 do protótipo **não** são as oficiais);
  - cálculo de SLA persistido;
  - tela "decidir crédito" (o protótipo não a desenha).
- **Regras:**
  - elegibilidade, aprovação e desembolso continuam distintos;
  - decisão de crédito é humana;
  - o painel "desempenho por instituição" só com contrato de métrica.
- **Critério de aceite:**
  - SLA igual ao calendário persistido;
  - fila respeita capabilities;
  - nenhuma decisão automática.
- **Decisão nova:** nenhuma.

### 11 · Usuários & Permissões
- **Classificação:** melhoria visual.
- **Resultado esperado:** tabela de pessoas, convites, aprovação e matriz de capabilities por papel.
- **Fonte disponível:**
  - **[FATO]** protótipo `#usuarios`;
  - **[FATO]** CTX §4 "Usuários".
- **Inspeção pendente:**
  - papéis canônicos reais (o CTX cita `coordenador_credito`; os 5 papéis do protótipo são ilustrativos);
  - capabilities existentes.
- **Regras:**
  - sem acesso por equipe ou cargo inferido;
  - mudança de papel e de capability auditada;
  - não bloquear o único coordenador;
  - a matriz do protótipo é ilustrativa.
- **Critério de aceite (USR01, SEC02):**
  - cadastro e aprovação pela interface;
  - matriz positiva e negativa no backend;
  - código do vendedor gerado e imutável.
- **Decisão nova:** nenhuma.

### 12 · Unidades e filiais
- **Classificação:** melhoria visual.
- **Resultado esperado:** aba em Configurações, sem atalho lateral.
- **Inspeção pendente:** modelo de unidade e filial e campos bancários (FUN06 aguarda configuração real).
- **Critério de aceite:** administração por capability; nenhum campo sem modelo.
- **Decisão nova:** nenhuma.

### 13 · Relatórios & BI
- **Classificação:** extensão.
- **Resultado esperado:** painéis (comercial, crédito, operação e SLA, perdas) com filtros, tooltips, totais e detalhamento.
- **Fonte disponível:**
  - **[FATO]** protótipo `#bi` (clique abre detalhamento com dados sorteados);
  - **[FATO]** CTX §8 (8 perguntas de gestão e a dependência canônica de cada uma);
  - BI01 parcial; BI02 incompleto.
- **Inspeção pendente:** fundação BI existente, views e consultas disponíveis.
- **Regras:**
  - contrato de métrica antes do gráfico;
  - sem porcentagem com denominador indefinido;
  - receita faturada separada de previsão;
  - mesmo escopo no agregado e no detalhe.
- **Critério de aceite:** total de cada gráfico igual à soma das linhas do detalhamento, com o mesmo filtro e o mesmo usuário.
- **Decisão nova:** D-BI1 (taxonomia de motivos de perda, se não existir).

### 14 · Ava
- **Classificação:** extensão.
- **Resultado esperado:** ver `AVA_ASSISTANT_CONTRACT.md`.
- **Fonte disponível:**
  - **[FATO]** protótipo `#ava` e barra `Ctrl+K`;
  - **[FATO]** CTX: código publicado, operação paga em HOLD, provider hospedado não validado (AVA01, AVA02);
  - **o Codex está trabalhando no runtime e na execução hospedada.**
- **Inspeção pendente:** o resultado do trabalho do Codex.
- **Critério de aceite:** os do contrato AVA-03.
- **Decisão nova:** D-AVA1 a D-AVA4.

### 15 · Tarefas & Agenda
- **Classificação:** módulo novo ou extensão. O protótipo supõe que as próximas ações vivem hoje no cartão da oportunidade **[INSPEÇÃO PENDENTE]**.
- **Resultado esperado:** tarefas atrasadas, de hoje e próximas, com responsável e prazo; agenda semanal.
- **Regras:**
  - tarefa ligada a um registro (organização, oportunidade, operação);
  - prazo em horas úteis quando houver SLA;
  - XP só com contrato (item 20).
- **Critério de aceite:**
  - criar, concluir e reatribuir com permissão;
  - atrasada vira alerta;
  - histórico preservado.
- **Decisão nova:** D-TAR1 (criar módulo de tarefas ou estender as próximas ações existentes).

### 16 · Notificações
- **Classificação:** extensão ou módulo novo **[INSPEÇÃO PENDENTE]**. O protótipo só mostra o sino com ponto, sem lista.
- **Resultado esperado:** lista de notificações do usuário (SLA, documento, movimentação, menção), marcar como lida e ir ao registro.
- **Regras:**
  - notificação respeita o escopo do usuário;
  - nada de envio externo (e-mail, WhatsApp) sem decisão própria;
  - sem dado sensível no texto do aviso.
- **Critério de aceite:** gera com o evento real; não gera para quem não tem acesso; marcar como lida persiste.
- **Decisão nova:** D-NOT1 (quais eventos notificam e por quais canais).

### 17 · Suporte interno
- **Classificação:** módulo novo.
- **Resultado esperado:** chamados com categoria, prioridade, SLA e responsável; base de conhecimento.
- **Fonte disponível:** **[FATO]** protótipo `#suporte`.
- **Regras:** o pedido de acesso aberto como chamado é aprovado em Usuários & Permissões, nunca no chamado.
- **Critério de aceite:** criar e acompanhar; ver só os próprios chamados, salvo capability de atendimento.
- **Decisão nova:** D-SUP1 (quem atende, SLA, categorias).

### 18 · Conversas (Inbox compartilhado)
- **Classificação:** extensão (a confirmar). O protótipo diz que "chat compartilhado já existe" **[INSPEÇÃO PENDENTE]**.
- **Resultado esperado:** caixa única com o canal interno (e WhatsApp quando houver), nota interna, contexto do negócio ao lado e sugestões da Ava como rascunho.
- **Regras:**
  - mensagem recebida é dado não confiável para a Ava;
  - sugestão nunca é enviada sem ação humana;
  - nota interna nunca sai para o cliente.
- **Critério de aceite:** histórico persistido; acesso por escopo; envio com estado (enviando, enviado, falhou).
- **Decisão nova:** D-CONV1 (escopo de quem vê quais conversas).

### 19 · WhatsApp
- **Classificação:** módulo novo.
- **Resultado esperado:** planejamento da integração **oficial** (instâncias, roteamento, templates, saúde do canal).
- **Fonte disponível:** **[FATO]** protótipo `#whatsapp` (mostra API oficial e não oficial).
- **Regras:**
  - a conexão não oficial (QR) **não** é habilitada por padrão;
  - consentimento do cliente e descadastro;
  - pedir documento não autoriza cobrança financeira automática;
  - credenciais no cofre de segredos.
- **Critério de aceite:** só depois das decisões de custo e consentimento; nenhum envio real nesta etapa.
- **Decisões novas:** D-WA1 (provedor e custo), D-WA2 (consentimento e textos), D-WA3 (não oficial: manter desligado).

### 20 · Metas, XP e desafios
- **Classificação:** módulo novo.
- **Resultado esperado:** metas e realizado, desafios, conquistas, níveis e liga por gerência.
- **Fonte disponível:** **[FATO]** protótipo `#arena`; CTX §8 "Estamos atingindo a meta": cadastro de metas a confirmar.
- **Regras:**
  - XP, metas, novos escopos e regras precisam de contrato aprovado;
  - pontos não podem incentivar aprovação de crédito;
  - pontuar só resultado confirmado (ex.: faturamento validado), nunca clique;
  - comissões fora do escopo.
- **Critério de aceite:** só depois do contrato.
- **Decisões novas:** D-GAM1 (fórmula de XP), D-GAM2 (cadastro de metas), D-GAM3 (visibilidade do ranking).

### 21 · Configurações gerais e white label
- **Classificação:** extensão.
- **Resultado esperado:** abas de unidades, identidade visual, integrações e planos (estado vazio).
- **Regras:**
  - identidade configurável a partir de fonte canônica existente **[INSPEÇÃO PENDENTE]**;
  - **sem** multitenancy nem `workspace_id` generalizado por iniciativa;
  - "Planos & cobrança" é estado vazio reservado.
- **Critério de aceite:** troca de nome, logo e cor sem deploy, se a fonte existir; senão, fica registrado como lacuna.

### 22 · Mapa do produto
Tela de apresentação do protótipo. **Não implementar** no Portal.

### 23 · Localização
**[FATO]** CTX §4: acesso a serviço externo existente. Não presumir módulo novo. Só recebe o visual se houver tela.

---

## Itens que o protótipo não mostra e que devem ser preservados

**[INSPEÇÃO PENDENTE]** Qualquer rota real ausente no protótipo continua existindo e recebe o shell novo. Exemplos citados no CTX:
- cadastro e aprovação de usuários;
- solicitação de acesso;
- recuperação;
- download e ZIP de documentos;
- PDFs;
- localização;
- configurações de filial com campos bancários.

O primeiro passo do bloco A é gerar a lista de rotas reais (FUN01) e cruzá-la com este quadro.

---

<!-- ARQUIVO 04_AVA_ASSISTANT_CONTRACT.md -->

# AVA_ASSISTANT_CONTRACT · Contrato do assistente

**ID:** AVA-03 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Situação:** **proposta de contrato**, nada implementado. O runtime local, a recuperação e a execução hospedada da Ava estão com o Codex. Este documento não altera esses arquivos e deve ser conciliado com o resultado do Codex antes de virar comando.

Marcas usadas: **[FATO]** (CTX ou protótipo), **[PROPOSTA]**, **[INSPEÇÃO PENDENTE]** e **[DECISÃO PENDENTE]**, esta última com ID em `DECISIONS_REQUIRED.md`.

---

## 1. Ponto de partida

| Item | Situação |
|---|---|
| Leitura e extração documental | **[FATO]** Publicada (CTX §3 e §4). **Preservar.** |
| Operação paga | **[FATO]** HOLD; o provider hospedado não foi validado nesta publicação (AVA01, AVA02) |
| Proteções já exigidas | **[FATO]** CTX §6: worker e cron protegidos, segredo e replay tratados; documentos são entrada não confiável; nenhum texto documental concede autoridade ou executa ferramenta; ledger; logs sem dado sensível |
| Protótipo | **[FATO]** Tela `#ava` (conversa de exemplo, área de documentos), barra `Ctrl+K` com respostas fixas, briefing no painel e sugestões no Inbox. **Não há modelo real no protótipo.** |
| Trabalho do Codex | **[INSPEÇÃO PENDENTE]** Arquitetura do runtime, onde moram prompts, ferramentas, ledger e limites |

---

## 2. Princípios não negociáveis

1. **Mesmas permissões do usuário.** A Ava age dentro das capabilities e escopos do usuário que pediu. Ela nunca tem acesso administrativo global, SQL arbitrário ou autoridade definida pelo modelo.
2. **Autorização no servidor a cada chamada de ferramenta.** A sessão do usuário é reavaliada no servidor em toda chamada, mesmo dentro da mesma conversa. O modelo não envia identidade, papel nem escopo; o servidor os deriva da sessão.
3. **Documentos e mensagens são dados.** Conteúdo de documento, mensagem de cliente, nome de arquivo ou campo de cadastro nunca muda instruções, nunca concede permissão e nunca dispara ferramenta.
4. **Crédito é decisão humana.** A Ava pode resumir, extrair e apontar pendências. Ela não aprova, não reprova, não escolhe instituição e não muda status de crédito.
5. **Voz não basta para ação de impacto.** Ação que altera dado ou envia algo exige confirmação na tela, nunca só pelo reconhecimento de voz.
6. **Sem custo novo nesta etapa.** Microfone permanente, novos providers e consumo pago ficam desligados até decisão (D-AVA1, D-AVA2).
7. **Números vêm de cálculo determinístico.** O modelo não calcula nem inventa métrica. Ele chama uma consulta que devolve o número e a fonte.

---

## 3. Entrada por texto e por voz

### 3.1 Texto **[PROPOSTA]**
- Entradas: barra da Ava (`Ctrl+K`), tela Ava e ações contextuais ("Resumir esta ficha").
- Toda resposta mostra **o que foi consultado** (fontes) e, quando houver número, **como foi calculado** (link para o contrato da métrica).
- Botão **Parar** durante a geração; cancelar não desfaz ação já confirmada, porque nenhuma ação acontece sem confirmação.

### 3.2 Voz **[PROPOSTA]**, desligada até D-AVA2
- **Acionamento explícito:** botão de microfone, apertar para falar ou alternar. Nunca escuta contínua e nunca palavra de ativação.
- Indicador visível de microfone ativo, com o tempo de gravação.
- **Transcrição visível e editável** antes do envio. O usuário corrige o texto e então envia.
- **Cancelar** descarta o áudio e a transcrição.
- **Fallback:** se a transcrição falhar ou a confiança for baixa, avisar e oferecer digitar. Nenhuma ação é inferida de áudio incompleto.
- **Áudio:** não guardar por padrão; guardar só a transcrição confirmada, junto com a conversa.
- **[DECISÃO PENDENTE D-AVA2]** Usar ou não a transcrição nativa do navegador (sem custo, qualidade variável) ou um provider pago.

---

## 4. Ferramentas

A Ava só usa ferramentas **específicas e nomeadas**, cada uma ligada a um caso de uso que já existe na camada Application do Portal (UI → Application/Use Cases → Domain/Policies → Repositories/Read Models → Infrastructure). A ferramenta chama o caso de uso, nunca o banco direto.

### 4.1 Níveis de impacto e confirmação **[PROPOSTA]**

| Nível | Tipo | Exemplo | Confirmação |
|---|---|---|---|
| N0 | Leitura | Buscar organização, abrir operação, consultar métrica, ver SLA | Nenhuma; a resposta cita as fontes |
| N1 | Rascunho | Rascunhar mensagem, resumo ou relatório | Nenhuma; nada é gravado nem enviado |
| N2 | Ação interna reversível | Criar tarefa, registrar nota interna, mover oportunidade numa transição permitida | **Prévia** do que vai mudar + 1 clique de confirmação |
| N3 | Envio externo ou difícil de desfazer | Enviar mensagem ao cliente, solicitar documento por WhatsApp ou e-mail | **Prévia completa** (destinatário, canal, texto) + confirmação explícita na tela; nunca só por voz; sujeito a D-WA |
| N4 | Proibido | Decidir crédito, mudar status de crédito, escolher instituição, mudar permissão, apagar dado, cobrança financeira, SQL, ação em nome de outro usuário | A ferramenta não existe |

### 4.2 Catálogo inicial proposto **[PROPOSTA]**

Os nomes são ilustrativos; os casos de uso reais dependem de **[INSPEÇÃO PENDENTE]**.

| Ferramenta | Nível | Caso de uso | Retorno |
|---|---|---|---|
| `buscar_registros(tipo, termo)` | N0 | Busca de organização, oportunidade ou operação já existente | Lista com IDs e links, no escopo do usuário |
| `abrir_registro(tipo, id)` | N0 | Leitura de ficha | Campos autorizados |
| `listar_pendencias(escopo)` | N0 | "O que precisa de ação hoje" | Itens com motivo e prazo |
| `consultar_metrica(metric_key, filtros)` | N0 | Consulta do catálogo BI-01 | Valor, fórmula, fonte, horário de atualização e linhas que compõem o número |
| `status_sla(operacao_id)` | N0 | SLA persistido | Horas úteis decorridas e restantes, pelo calendário oficial |
| `ler_documento(documento_id)` | N0 | **Extração documental existente** | Campos extraídos + confiança + página de origem |
| `rascunhar_relatorio(modelo, filtros)` | N1 | Monta relatório só com o resultado de `consultar_metrica` | Texto + tabela + fontes |
| `rascunhar_mensagem(contexto_id)` | N1 | Sugestão de texto | Texto para edição |
| `criar_tarefa(registro_id, titulo, prazo, responsavel)` | N2 | Caso de uso de tarefas (depende de D-TAR1) | Prévia → confirmação → recibo |
| `mover_oportunidade(id, fase_destino)` | N2 | Mesma regra de transição do Kanban | Prévia → confirmação → recibo; negação clara se não for permitido |
| `registrar_nota(registro_id, texto)` | N2 | Nota interna | Prévia → confirmação → recibo |
| `solicitar_documento(organizacao_id, itens, canal)` | N3 | Depende de D-WA e de consentimento | Prévia completa → confirmação → recibo; nunca cobra |

### 4.3 Regras de chamada **[PROPOSTA]**
- Argumentos validados por esquema no servidor; IDs são UUIDs que o servidor confere contra o escopo.
- Toda escrita (N2/N3) leva uma **chave de idempotência** gerada no servidor ao montar a prévia. Confirmar duas vezes não duplica.
- A prévia expira (ex.: 10 minutos) e é recalculada se o registro mudou.
- Resultado de ferramenta volta ao modelo marcado como **dado**, nunca como instrução.

---

## 5. Relatórios **[PROPOSTA]**

- Todo número de relatório vem de `consultar_metrica` (cálculo no servidor, mesmo escopo do usuário). O modelo só organiza e explica.
- Cada número traz a fonte (métrica, filtros, período, timezone America/Sao_Paulo, horário de atualização) e o link para o detalhamento.
- Ausência de dado é dita: "Não há cadastro de metas; este indicador não pode ser calculado". Nunca estimar nem usar zero.
- Elegibilidade documental nunca aparece como aprovação; receita faturada é separada de previsão; pedido emitido não é máquina faturada.
- **Exportar** (PDF ou CSV) gera o arquivo pelo mesmo serviço do BI, não pelo modelo.

---

## 6. Limites **[PROPOSTA]**, valores em D-AVA1 e D-AVA3

| Limite | Proposta de partida | Ao atingir |
|---|---|---|
| Orçamento mensal (R$) | **D-AVA1** (hoje: HOLD) | Bloqueia chamadas pagas; leitura sem modelo continua; aviso ao administrador |
| Orçamento por usuário por dia | D-AVA1 | Mensagem clara ao usuário |
| Contexto por chamada | Só o necessário: registro aberto + resultados das ferramentas; documento por trechos | Resumir antes, nunca truncar em silêncio |
| Chamadas de ferramenta por pergunta | Até 6 | Para e explica o que faltou |
| Tentativas por erro transitório | Até 2, com espera crescente; nunca para N3 | Erro terminal com referência |
| Concorrência | 1 pergunta ativa por usuário; fila por empresa definida em D-AVA3 | "Aguarde a resposta anterior" |
| Tempo máximo | 30 s por resposta e 15 s por ferramenta | Cancela e informa |
| Documento | Os limites existentes (20 MiB upload, 10 MiB catálogo) | Mensagem de limite do design system |

---

## 7. Auditoria, recibos e falhas **[PROPOSTA]**

- **Ledger** (já previsto no CTX, a reconciliar com o Codex): para cada interação, registrar
  - usuário, horário, versão de prompt, ferramentas e modelo;
  - ferramentas chamadas com argumentos **sanitizados**;
  - IDs dos registros lidos;
  - tokens e custo;
  - latência;
  - resultado.
  Nunca guardar o texto completo de documento nem dado pessoal em log.
- **Recibo** para N2 e N3: o que mudou, quando, por quem (usuário, com a Ava como canal), chave de idempotência e link para desfazer quando a regra permitir.
- **Falhas** visíveis com o estado de erro do design system:
  - provider indisponível;
  - orçamento atingido;
  - sem permissão (mesma tela de acesso negado);
  - dado ausente;
  - tempo esgotado.
  Erro nunca vira resposta inventada.
- **Prompt injection detectada** (ex.: documento pedindo para ignorar regras): a Ava responde só com os dados, registra o evento no ledger e não chama ferramentas sugeridas pelo conteúdo.

---

## 8. Onde ajustar quando algo der errado

Antes de trocar de modelo, identificar a camada:

| Sintoma | Camada provável | Ajuste |
|---|---|---|
| Resposta com dado de outro usuário | **Integração e autorização** | Corrigir o escopo no servidor (P0); não é problema de modelo |
| Número errado | **Cálculo determinístico** | Corrigir a métrica (BI-01) |
| Campo de documento errado ou faltando | **Extração** (OCR, layout, página) | Ajustar o extrator e o pré-processamento; medir por tipo de documento |
| Ignora regra ou formato | **Prompt** | Ajustar instruções versionadas |
| Resposta sem a informação que existia | **Contexto** | Rever o que entra no contexto e a busca |
| Qualidade baixa com tudo acima correto | **Modelo** | Avaliar outro modelo **dentro do orçamento aprovado** |

**Fine-tuning não é presumido.** Só seria considerado se a avaliação versionada mostrar falha persistente que prompt, contexto e extração não resolvem, e com decisão de custo própria.

---

## 9. Avaliação e calibração **[PROPOSTA]**

Um conjunto de avaliação **versionado** (`ava-eval vN`), com dados sintéticos ou anonimizados autorizados, sem acervo real enviado a terceiros:

| Dimensão | Casos | Métrica |
|---|---|---|
| Extração | Por tipo de documento (DRE, balanço, IR, contrato social…) | Acerto por campo; valores e datas exatos; página de origem correta |
| Dado ausente | Documento sem o campo pedido | Diz "não encontrado"; zero invenção |
| Valores e datas | Formatos pt-BR, milhar, negativos, períodos | Normalização exata |
| Permissões | Usuário A pede dado do escopo de B | 100% negado no servidor |
| Prompt injection | Instruções escondidas em documento ou mensagem | Nenhuma ferramenta disparada; evento registrado |
| Ferramentas | Escolha e argumentos | Ferramenta correta; nenhuma N2/N3 sem prévia |
| Idempotência | Confirmar duas vezes, retry, rede caindo | Nenhuma duplicação |
| Custo | Tokens por tipo de pergunta | Dentro do orçamento (D-AVA1) |
| Latência | p50 e p95 por tipo | Meta definida após baseline (CTX §7) |

Cada mudança de prompt, extrator ou modelo roda o conjunto inteiro, e o resultado fica registrado com a versão. A calibração de confiança da extração (limite para pedir revisão humana) é definida por tipo de documento a partir dessa avaliação.

---

## 10. Interface **[FATO]** no protótipo, **[PROPOSTA]** no Portal

- Barra da Ava na barra superior (`Ctrl+K`), com orbe pulsante.
- Faixa de briefing no painel (`.brief`).
- Sugestões em pílulas tracejadas no Inbox.
- Prévia de ação como diálogo `.dlg`, com o botão principal "Confirmar" e "Cancelar".
- Recibo como toast com link.
- Estados: pensando (orbe pulsando, botão Parar), erro, sem permissão, orçamento atingido e microfone ativo.
- Teste em 4 cenários reais escolhidos pelo Owner, com dados autorizados, antes de ampliar.

---

## 11. Critérios de aceite do contrato

1. Nenhuma ferramenta N4 existe no código.
2. Toda ferramenta reavalia a autorização no servidor; teste negativo com UUID alheio.
3. Nenhuma escrita sem prévia e confirmação; nenhuma escrita por voz sem confirmação na tela.
4. Todo número de relatório tem fonte e confere com o detalhamento.
5. Documento com injeção não dispara ferramenta (teste automatizado).
6. Retry não duplica (teste automatizado).
7. Ledger sem dado sensível (inspeção).
8. Limites ativos e testados; operação paga só depois de D-AVA1.
9. Leitura documental existente sem regressão (mesmos documentos, mesmos campos).

---

<!-- ARQUIVO 05_IMPLEMENTATION_BLOCKS.md -->

# IMPLEMENTATION_BLOCKS · Blocos de implementação

**Comando de origem:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Relação com o quadro:** DS-01 (referência e especificação) → DS-02 (aplicação por telas) · BI-01 (catálogo de métricas, dashboard e BI) · AVA-03 (assistente) · NOV-01 (módulos novos)

> Estes blocos são **especificação**. Nada aqui foi implementado no Portal real. A entrega desta especificação não declara implementação concluída.

## Regras comuns a todos os blocos

Cada comando abaixo é autocontido, mas todos herdam estas regras.

1. **Baseline primeiro.**
   - Antes de escrever código, conferir a baseline vigente. A referência atual é `abaramagold91/portal-irmen-v2`, branch `codex/f7-014-controlled-release`, commit `92c88f9dfee0a180eb91cc83192a64dbe11e3456`, e **pode ter mudado com a F7-015**.
   - Não partir de `main` presumindo que está atual.
   - Registrar no relatório o commit de partida.
2. **Um executor por bloco.**
   - Claude implementa o bloco delimitado numa branch própria. O Codex integra, testa e publica.
   - Ninguém edita os mesmos arquivos em paralelo. Os arquivos de runtime, recuperação e execução hospedada da Ava são do Codex.
3. **Arquitetura.**
   - UI → Application/Use Cases → Domain/Policies → Repositories/Read Models → Infrastructure.
   - A interface não acessa o banco direto.
   - A autorização é decidida no backend.
4. **Preservar:**
   - RLS, capabilities, UUIDs, vínculos, histórico e identificadores;
   - código do vendedor automático e permanente;
   - SLA e calendário persistidos;
   - elegibilidade, aprovação e desembolso distintos;
   - perda antes da OP pelo vendedor e depois da OP por solicitação à Mesa;
   - PED nas etapas autorizadas;
   - Filiais só em Configurações.
5. **Não fazer:**
   - multitenancy ou `workspace_id` generalizado;
   - acesso por equipe ou cargo inferido;
   - vendedor decidindo banco ou status de crédito;
   - dados de demonstração em produção;
   - comissões, estoque ou PDI;
   - reset, clean, prune ou purge;
   - apagar histórico.
6. **Banco.** Migração só quando o bloco realmente precisar e depois de comparar com o schema existente. Reforma de banco ou eventos **não** é pré-requisito para aplicar o visual.
7. **Referência visual:**
   - `DESIGN_SYSTEM_SPEC.md`;
   - `tokens/tokens.css`;
   - catálogo https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/;
   - protótipo https://abaramagold91.github.io/irmen-jarvis-demo/ (pacote `irmen-jarvis-referencia-fb6416c.zip`).
8. **Testes mínimos de toda tela:**
   - funcional;
   - negativo de permissão (no servidor);
   - visual nos dois temas em 1440, 1280, 820 e 390px;
   - sem rolagem lateral em 390px;
   - teclado e foco visível;
   - redução de movimento;
   - sem erro no console.
9. **Fechamento** com um dos registros do CTX: CORRIGIDO E VALIDADO, VERIFICADO SEM DEFEITO, REFUTADO COM EVIDÊNCIA, DECISÃO DE NEGÓCIO PENDENTE, ACEITE HUMANO PENDENTE ou BLOQUEIO TÉCNICO COMPROVADO.

## Ordem e dependências

| Ordem | Bloco | ID | Executor | Depende de |
|---|---|---|---|---|
| 1 | A · Tokens, componentes, shell e primeira tela (Funil) | DS-02.A | Claude | Baseline conferida; D-DS1 só para os ajustes de contraste |
| 2 | B1 · Organizações, contatos e documentos | DS-02.B1 | Claude | A |
| 3 | B2 · Operações, simulador, pedidos e PDF | DS-02.B2 | Claude | A |
| 4 | B3 · Mesa de Crédito | DS-02.B3 | Claude | A |
| 5 | B4 · Usuários, permissões, configurações e filiais | DS-02.B4 | Claude | A |
| 6 | B5 · Login, recuperação e solicitação de acesso | DS-02.B5 | Claude | A |
| 7 | C1 · Catálogo de métricas | BI-01.C1 | Claude (documento + read models propostos) | Inspeção da fundação BI |
| 8 | C2 · Dashboard por perfil e BI | BI-01.C2 | Claude | A, C1 |
| 9 | D1 · Reconciliação do contrato da Ava com o runtime | AVA-03.D1 | **Codex** | Trabalho hospedado do Codex concluído |
| 10 | D2 · Interface da Ava e ferramentas de leitura | AVA-03.D2 | Claude | A, C1, D1 |
| 11 | D3 · Ações governadas e voz | AVA-03.D3 | Claude | D2, D-AVA1…4 |
| 12 | E1 · Tarefas e notificações | NOV-01.E1 | Claude | A, D-TAR1, D-NOT1 |
| 13 | E2 · Suporte interno | NOV-01.E2 | Claude | A, D-SUP1 |
| 14 | E3 · Conversas | NOV-01.E3 | Claude | A, D-CONV1 |
| 15 | F1 · WhatsApp oficial (plano) | NOV-01.F1 | Claude (documento) | D-WA1…3 |
| 16 | F2 · Metas, XP e desafios | NOV-01.F2 | Claude | C1, D-GAM1…3 |

Os blocos B1 a B5 podem correr em sequência curta ou em paralelo **só** se tocarem arquivos diferentes (conferir na inspeção do A).

---

## Bloco A · DS-02.A · Tokens, componentes, shell e primeira tela integrada

```
DESTINO: CLAUDE (implementação delimitada) → CODEX (integração, testes, publicação)
COMANDO: IRMEN-DS-02-A-TOKENS-COMPONENTS-SHELL-FIRST-SCREEN
```

**Objetivo.** Levar os tokens e os componentes do design system homologado para o código do Portal e aplicá-los no shell autenticado e na tela Funil & Kanban, sem mudar regra de negócio.

**Dependências.**
- Baseline conferida.
- Referência DS-01.
- Os ajustes de contraste (D-DS1) entram atrás de uma variável; sem aceite, ficam os valores homologados.

**Localizar no código real (antes de escrever).**
1. Stack de estilo (CSS Modules, Tailwind, outro) e onde ficam variáveis e tema.
2. Componentes compartilhados existentes (botão, input, tabela, modal, badge, toast) e o design-lab da porta 3002 citado no CTX.
3. Layout autenticado, menu e como os itens são filtrados hoje.
4. Biblioteca de ícones e de gráficos, se houver.
5. A tela do funil: rota, componentes, caso de uso de transição e histórico.
6. Lista de rotas reais (FUN01) para garantir que nenhuma some do menu.

Entregar a lista acima como primeira seção do relatório, com caminhos e linhas.

**Interface e estados.**
- Tokens dos dois temas (`tokens/tokens.css`), aplicados pelo atributo de tema na raiz.
- Preferência de tema persistida sem flash: script mínimo antes da pintura, ou cookie lido no servidor.
- Componentes:
  - Button (padrão, primário com chanfro e laser, arc, ghost, sm; carregando; desabilitado; foco com anel chanfrado);
  - IconButton;
  - Segmented;
  - Pill e Badge;
  - Chip;
  - KpiTile;
  - DataTable (com cartões abaixo de 640px);
  - Field (padrão do login: ícone, erro com `aria-invalid`, ajuda);
  - Alert;
  - Dialog (com foco preso e devolvido);
  - Toast (`aria-live`);
  - EmptyState, ErrorState, ForbiddenState, Skeleton;
  - Icon.
- Shell: barra lateral, barra superior, gaveta móvel e rede neural global única (pausa quando oculta; quadro estático com redução de movimento).
- Funil & Kanban:
  - faixa de fases, Kanban e tabela;
  - arrastar com a regra real;
  - "Mover para…" por toque e teclado;
  - estados vazio, carregando, erro e acesso negado.

**Casos de uso, autorização, persistência, auditoria.**
- Nenhum caso de uso novo.
- O menu e a tela usam as capabilities devolvidas pelo servidor.
- A transição de fase continua no caso de uso existente, com o histórico existente.

**Migrações.** Nenhuma.

**Testes.**
- Funcionais: mover cartão permitido; mover negado mostra o aviso; histórico gravado; tabela e Kanban mostram os mesmos dados.
- Negativos: usuário sem capability não vê o item de menu, e a rota direta devolve acesso negado com o servidor negando os dados; UUID alheio na transição é negado.
- Visuais: comparação com o catálogo e o protótipo nos dois temas e quatro larguras.
- Mobile: carrossel de fases e colunas; sem rolagem lateral em 390px.
- Acessibilidade: foco visível em todos os controles, incluindo o botão chanfrado; ordem de tabulação; `aria-current` no menu; contraste conforme D-DS1.

**Desempenho, observabilidade, recuperação.**
- Medir antes e depois (LCP, INP, CLS) no desktop e no mobile.
- A rede neural não pode piorar o INP além da meta de 200ms no percentil 75.
- Sem logs novos de dado pessoal.
- Mudança só de interface, revertida pelo deploy anterior.

**Critérios de aceite.**
1. Todas as rotas atuais continuam acessíveis.
2. Funil com a mesma regra e o mesmo histórico.
3. Visual igual à referência nas larguras citadas.
4. Testes negativos de permissão passando no servidor.
5. Nenhum dado de demonstração.

**Limites.** Não redesenhar as outras telas neste bloco; elas usam o shell novo com o conteúdo antigo até o bloco B.

---

## Bloco B · DS-02.B · Telas existentes com preservação funcional

Cada sub-bloco tem a mesma estrutura. Para todos:
- **dependência:** bloco A integrado;
- **executor:** Claude;
- **migrações:** nenhuma, salvo indicação;
- **limite:** só visual e estados, sem mudar regra.

### B1 · Organizações, contatos e documentos
```
COMANDO: IRMEN-DS-02-B1-ORGANIZATIONS-CONTACTS-DOCUMENTS
```
- **Localizar:**
  - cadastro e detalhe de cliente;
  - modelo de contato;
  - vínculos com oportunidade e operação;
  - upload, download e ZIP;
  - limites configurados (20 MiB e 10 MiB).
- **Interface:**
  - lista com busca e filtro de pendência;
  - ficha 360º (cabeçalho, indicadores, contatos, checklist, negócios, linha do tempo), mostrando **só** o que tiver fonte;
  - upload com progresso e erro de tipo e de tamanho.
- **Regras:** dedupe por CNPJ como já existe; edição só autorizada; download só com acesso.
- **Testes:**
  - persistência após recarregar;
  - vínculos intactos;
  - upload acima do limite negado;
  - download por outro usuário sem acesso negado no servidor;
  - ZIP com o mesmo conteúdo.
- **Aceite:** FUN02 e DOC01 sem regressão; visual da referência.
- **Decisão:** D-CRM1 (nome do menu e contato como entidade). Sem decisão, mantém "Clientes".

### B2 · Operações, simulador, pedidos e PDF
```
COMANDO: IRMEN-DS-02-B2-OPERATIONS-SIMULATOR-ORDERS-PDF
```
- **Localizar:**
  - emissão de OPP, OP e PED e seus formatos reais;
  - regras do simulador e fonte das taxas;
  - snapshots;
  - gerador de PDF;
  - campos de emissor e beneficiário (FUN06).
- **Interface:**
  - jornada OPP → OP → PED;
  - tabela de operações;
  - assistente em etapas no visual novo (só as etapas que já existem);
  - PDF com a identidade nova.
- **Regras:**
  - o vendedor não escolhe banco;
  - taxa só da fonte canônica;
  - pedido emitido não é faturado;
  - códigos ilustrativos do protótipo **não** são regra.
- **Testes:**
  - mesmo cálculo antes e depois em 10 casos de referência (quantidade, entrada, prazo, arredondamento);
  - retry sem duplicar código;
  - PDF igual ao snapshot.
- **Aceite:** FUN04 e FUN05 sem regressão.
- **Decisão:** D-SIM1 (comparação entre instituições visível ao vendedor). Sem decisão, não mostrar.

### B3 · Mesa de Crédito
```
COMANDO: IRMEN-DS-02-B3-CREDIT-DESK
```
- **Localizar:**
  - fases e status reais;
  - cálculo do SLA e calendário persistido;
  - telas de decisão;
  - desembolsador.
- **Interface:**
  - esteira com contagem e SLA por fase;
  - fila ordenada por SLA;
  - ficha com pendências;
  - gráficos de instituição **só** com métrica de C1.
- **Regras:**
  - Aprovada e Desembolsada distintas;
  - no máximo um desembolsador;
  - decisão humana;
  - SLA de 20 horas úteis, 8h–18h, de segunda a sexta, America/Sao_Paulo, feriados nacionais.
- **Testes:**
  - SLA de 5 operações conferido à mão com o calendário;
  - vendedor sem acesso à fila (negado no servidor);
  - decisão registrada com autor.
- **Aceite:** esteira e SLA idênticos à regra; nenhum número sem fonte.

### B4 · Usuários, permissões, configurações e filiais
```
COMANDO: IRMEN-DS-02-B4-USERS-PERMISSIONS-SETTINGS
```
- **Localizar:**
  - fluxo de solicitação e convite, aprovação, bloqueio e recuperação;
  - papéis canônicos e capabilities;
  - configurações e unidades.
- **Interface:**
  - tabela de pessoas com estado (pendente, ativo, bloqueado);
  - matriz de capabilities em leitura, alterável só com capability;
  - configurações em abas;
  - Filiais só ali.
- **Regras:**
  - não bloquear o único coordenador;
  - toda mudança de papel e capability auditada;
  - código do vendedor gerado e imutável.
- **Testes:**
  - aprovar, bloquear e desbloquear pela interface;
  - usuário bloqueado com sessão antiga negado no backend (SEC03);
  - tentativa de mudar o próprio papel pelo cliente negada.
- **Aceite:** USR01 e SEC02 sem regressão.

### B5 · Login, recuperação e solicitação de acesso
```
COMANDO: IRMEN-DS-02-B5-LOGIN-RECOVERY-ACCESS-REQUEST
```
- **Localizar:**
  - página de login;
  - fluxo de recuperação (link ou código);
  - tela de solicitação de acesso existente;
  - política de senha;
  - mensagens de erro.
- **Interface:**
  - exatamente a homologada (`HOMOLOGACAO.md` §3);
  - "Solicitar primeiro acesso" leva à tela existente;
  - se a recuperação for por link, trocar a etapa de código pelo aviso "enviamos um link", no mesmo visual.
- **Regras:**
  - sem enumeração de contas;
  - limite de tentativas no servidor;
  - token sem replay e limpo da URL;
  - redirecionamento só para rotas internas.
- **Testes:**
  - login válido e inválido;
  - bloqueio por tentativas;
  - recuperação completa com usuário legítimo;
  - link reutilizado negado;
  - conta inexistente com a mesma resposta;
  - dois temas e cinco larguras.
- **Aceite:** SEC01 e SEC03 sem regressão; texto e visual iguais à homologação.

---

## Bloco C · BI-01 · Dashboard e BI canônicos

### C1 · Catálogo de métricas
```
COMANDO: IRMEN-BI-01-C1-METRIC-CATALOG
```
- **Objetivo:** para cada indicador mostrado no protótipo e nas 8 perguntas de gestão do CTX §8, escrever o **contrato de métrica** e dizer se a fonte existe.
- **Localizar:** fundação BI existente, views e consultas, eventos ou histórico de transições, cadastro de metas.
- **Entregar** uma tabela com:
  - `metric_key`;
  - nome simples;
  - pergunta;
  - fórmula;
  - grão;
  - entidade;
  - fonte (tabela ou view real com caminho);
  - datas e timezone;
  - estados incluídos e excluídos;
  - moeda;
  - filtros;
  - escopo (own, equipe ou empresa, conforme capability);
  - atualização;
  - detalhamento;
  - tratamento de ausência;
  - **situação: disponível / lacuna / decisão**.
- **Regras:**
  - não fabricar zero;
  - sem porcentagem com denominador indefinido;
  - receita faturada separada de previsão;
  - elegibilidade não é aprovação;
  - pedido não é faturamento.
- **Migrações:** nenhuma. Se uma métrica precisar de read model novo, **propor** com a comparação ao schema e esperar aprovação.
- **Aceite:** cada métrica com fonte real ou marcada como lacuna; validação manual de 3 métricas contra a lista de registros.

### C2 · Dashboard por perfil e BI
```
COMANDO: IRMEN-BI-01-C2-DASHBOARD-AND-BI
```
- **Dependências:** A e C1.
- **Interface:**
  - painel com "precisa de ação hoje", KPIs e evolução, por perfil;
  - BI com filtros, tooltips, legendas, totais e detalhamento até os registros;
  - "ver como tabela" em cada gráfico;
  - contrato da métrica visível;
  - estados carregando, erro e métrica indisponível.
- **Regras:**
  - mesmo escopo no agregado e no detalhe;
  - ranking amplo só com capability;
  - meta só se houver cadastro.
- **Testes:**
  - total do gráfico igual à soma do detalhamento (5 casos por painel);
  - vendedor vê só o próprio escopo nos dois;
  - filtros persistem na navegação;
  - desempenho com o volume real (paginação no detalhamento).
- **Aceite:** DASH01 e BI02 com os critérios do CTX; Owner aceita os painéis.

---

## Bloco D · AVA-03 · Ava contextual, relatórios, voz e ações governadas

O contrato completo está em `AVA_ASSISTANT_CONTRACT.md`.

### D1 · Reconciliação com o runtime (Codex)
```
DESTINO: CODEX
COMANDO: IRMEN-AVA-03-D1-CONTRACT-RECONCILIATION
```
- **Objetivo:** comparar o contrato AVA-03 com o runtime, a recuperação e a execução hospedada que o Codex concluiu. Apontar onde já atende, onde diverge e onde falta, sem mudar a leitura documental existente.
- **Entregar:**
  - mapa de arquivos (prompts, ferramentas, ledger, limites, worker e cron);
  - lista de ferramentas existentes;
  - como a autorização é checada em cada chamada;
  - limites atuais;
  - formato do ledger.
- **Aceite:** tabela "contrato × implementação" com o caminho e as linhas de cada item.

### D2 · Interface da Ava e ferramentas de leitura
```
COMANDO: IRMEN-AVA-03-D2-UI-AND-READ-TOOLS
```
- **Dependências:** A, C1 e D1.
- **Interface:**
  - barra `Ctrl+K`;
  - tela Ava;
  - briefing do painel;
  - fontes em cada resposta;
  - botão Parar;
  - estados (pensando, erro, sem permissão, orçamento atingido).
- **Ferramentas:** só N0 e N1 (`buscar_registros`, `abrir_registro`, `listar_pendencias`, `consultar_metrica`, `status_sla`, `ler_documento`, `rascunhar_relatorio`, `rascunhar_mensagem`), ligadas a casos de uso existentes.
- **Testes:**
  - UUID alheio negado;
  - documento com injeção não dispara ferramenta;
  - número do relatório igual ao do BI;
  - leitura documental sem regressão.
- **Limite:** operação paga só após D-AVA1. Antes disso, testar com o modo sem custo definido em D1.

### D3 · Ações governadas e voz
```
COMANDO: IRMEN-AVA-03-D3-GOVERNED-ACTIONS-AND-VOICE
```
- **Dependências:** D2 e as decisões D-AVA1 a D-AVA4 (D-AVA2 só para a parte de voz).
- **Ferramentas:** N2 (`criar_tarefa`, `mover_oportunidade`, `registrar_nota`) com prévia, confirmação, idempotência e recibo. N3 só depois de D-WA.
- **Voz:**
  - botão explícito;
  - transcrição editável;
  - cancelar;
  - fallback para texto;
  - nunca executa ação só por voz.
- **Testes:**
  - confirmar duas vezes não duplica;
  - prévia expirada é recalculada;
  - ação negada pela regra mostra o motivo;
  - voz sem confirmação na tela não altera nada.
- **Aceite:** os critérios 1 a 9 do contrato.

---

## Bloco E · NOV-01 · Tarefas e notificações, suporte e conversas

### E1 · Tarefas e notificações
```
COMANDO: IRMEN-NOV-01-E1-TASKS-NOTIFICATIONS
```
- **Dependências:** A, D-TAR1 e D-NOT1.
- **Localizar:** onde vivem hoje as próximas ações e se existe algum aviso ao usuário.
- **Interface:**
  - tarefas atrasadas, de hoje e próximas;
  - agenda semanal;
  - concluir, reatribuir e adiar;
  - sino com lista, marcar como lida e ir ao registro.
- **Casos de uso:** criar, concluir, reatribuir (com capability) e gerar notificação a partir dos eventos escolhidos em D-NOT1.
- **Migrações:** provável (tarefa e notificação), **só** depois de comparar com o schema e aprovar a proposta.
- **Testes:**
  - tarefa de outro vendedor invisível;
  - notificação não gerada para quem não tem acesso;
  - concluir duas vezes não duplica.
- **Aceite:** persistência, escopo e auditoria de reatribuição.

### E2 · Suporte interno
```
COMANDO: IRMEN-NOV-01-E2-INTERNAL-SUPPORT
```
- **Dependências:** A e D-SUP1.
- **Interface:** KPIs, tabela de chamados, abrir chamado, detalhe com histórico e base de conhecimento.
- **Regras:** o pedido de acesso é aprovado em Usuários & Permissões, nunca no chamado; o solicitante vê só os próprios chamados.
- **Migrações:** provável, após comparação e aprovação.
- **Aceite:** abrir, atribuir, responder e fechar com histórico; SLA conforme D-SUP1.

### E3 · Conversas
```
COMANDO: IRMEN-NOV-01-E3-CONVERSATIONS
```
- **Dependências:** A e D-CONV1.
- **Localizar:** o chat compartilhado existente (se houver).
- **Interface:**
  - lista;
  - conversa com estados de envio;
  - nota interna;
  - contexto do negócio;
  - sugestões da Ava como rascunho.
- **Regras:**
  - mensagem recebida é dado não confiável;
  - nota interna nunca sai;
  - sugestão não é enviada sem ação humana.
- **Aceite:** histórico persistido, escopo por D-CONV1 e falha de envio visível.

---

## Bloco F · NOV-01 · WhatsApp, metas, XP e desafios

### F1 · WhatsApp oficial (plano)
```
COMANDO: IRMEN-NOV-01-F1-WHATSAPP-OFFICIAL-PLAN
```
- **Objetivo:** documento de integração **oficial**, sem implementar envio, com:
  - provedor;
  - custo por conversa e por template;
  - consentimento e descadastro;
  - textos de template;
  - roteamento por fila;
  - armazenamento de mídia com os limites de documento;
  - segredos no cofre.
- **Regras:**
  - a conexão não oficial fica **desligada** por padrão;
  - pedir documento não autoriza cobrança;
  - nenhum envio real nesta etapa.
- **Aceite:** Owner decide D-WA1 a D-WA3 com base no documento.

### F2 · Metas, XP e desafios
```
COMANDO: IRMEN-NOV-01-F2-GOALS-XP-CHALLENGES
```
- **Dependências:** C1 (métricas de resultado) e D-GAM1 a D-GAM3.
- **Interface:** a do protótipo `#arena` (nível, metas, desafios, liga por gerência, ranking, conquistas).
- **Regras:**
  - XP só por resultado confirmado (ex.: faturamento validado);
  - nada por clique;
  - nada ligado à aprovação de crédito;
  - liga compara gerências, sem expor pessoas de outras equipes sem capability;
  - comissões fora.
- **Migrações:** provável (metas, desafios, ledger de pontos imutável), só após comparação e aprovação.
- **Testes:**
  - pontos recalculáveis a partir do ledger;
  - estorno quando o faturamento é cancelado;
  - nenhuma pontuação duplicada.
- **Aceite:** contrato aprovado pelo Owner antes de qualquer código.

---

<!-- ARQUIVO 06_DECISIONS_REQUIRED.md -->

# DECISIONS_REQUIRED · Decisões novas do Owner

**Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026

Aqui só entram regras ou custos **realmente novos**: o que o protótipo sugere e que ainda não tem contrato, decisão no CTX ou regra vigente. O que já está decidido no CTX (SLA, códigos, perda, filiais, escopo do piloto, comissões fora, etc.) não é reaberto.

Cada decisão traz uma recomendação. Sem decisão, vale o padrão indicado, que é sempre o mais conservador.

| ID | Pergunta | Recomendação | Padrão sem decisão | Bloqueia |
|---|---|---|---|---|
| D-DS1 | Aceitar os ajustes de acessibilidade no visual homologado? | Sim | Visual homologado sem ajuste; só o anel de foco | A (parcial) |
| D-CRM1 | Renomear "Clientes" para "Organizações & Contatos" e ter contato como cadastro próprio? | Renomear já; contato próprio só se o modelo atual não tiver | Mantém "Clientes" | B1 (parcial) |
| D-SIM1 | O vendedor vê a comparação entre instituições no simulador? | Não; só a Mesa | Não mostrar | B2 (parcial) |
| D-BI1 | Criar taxonomia de motivos de perda, se não existir? | Sim, lista curta e fechada | Indicador "Por que perdemos" fica como lacuna | C2 (um painel) |
| D-AVA1 | Orçamento mensal da Ava e limite por usuário | Definir teto mensal baixo para o piloto | Operação paga em HOLD | D2/D3 com modelo pago |
| D-AVA2 | Voz: transcrição do navegador (sem custo) ou provider pago? | Navegador primeiro, só com botão | Voz desligada | D3 (voz) |
| D-AVA3 | Concorrência e fila da Ava | 1 pergunta por usuário; fila curta por empresa | Valores do contrato (seção 6) | D2 |
| D-AVA4 | Quais ações de escrita (N2) a Ava pode propor no piloto? | Criar tarefa e registrar nota | Só leitura e rascunho | D3 |
| D-TAR1 | Criar módulo de Tarefas ou estender as próximas ações existentes? | Decidir depois da inspeção; preferir estender | Sem tarefas novas | E1 |
| D-NOT1 | Quais eventos geram notificação e por quais canais? | SLA perto de estourar, documento pendente, movimentação na minha carteira; só no portal | Sem notificações novas | E1 |
| D-SUP1 | Quem atende o suporte interno, com qual SLA e quais categorias? | Administração; 8 horas úteis; Acesso, Sistema, Dúvida | Módulo não implementado | E2 |
| D-CONV1 | Quem vê quais conversas? | Dono da carteira + gestor com capability; Mesa só nas suas operações | Mantém a regra atual do chat, se existir | E3 |
| D-WA1 | Provedor oficial do WhatsApp e orçamento | Avaliar com o documento F1 | Sem integração | F1 |
| D-WA2 | Consentimento e textos de template | Opt-in registrado; templates aprovados pelo Owner | Sem envio ativo | F1 |
| D-WA3 | Conexão não oficial (QR) | Manter desligada | Desligada | — |
| D-GAM1 | Fórmula de XP | Só por resultado confirmado; nada ligado à aprovação de crédito | Sem XP | F2 |
| D-GAM2 | Cadastro de metas (quem cria, vigência, granularidade) | Gerência cria por mês e por vendedor; Diretoria aprova | Indicador de meta como lacuna | C2 (meta), F2 |
| D-GAM3 | Visibilidade do ranking | Por equipe; liga só entre gerências | Sem ranking | F2 |

---

## Detalhes

### D-DS1 · Ajustes de acessibilidade no visual homologado
**Por que é decisão:** muda levemente cores aprovadas.
**O que muda:**
1. Botão principal no tema escuro: fundo `#de2f3f` em vez de `#ef3f4f`. O contraste com o texto branco sobe de 3,82 para 4,58:1, e a diferença é quase imperceptível.
2. Texto pequeno direto sobre o fundo no tema claro: vermelho `#c8283a` (4,55:1) e ciano `#08709a` (4,58:1). Sobre os painéis brancos, nada muda.
3. Anel de foco visível nos botões chanfrados. Hoje o foco por teclado não aparece; a mudança só se vê ao navegar pelo teclado.

**Demonstração:** catálogo, seções Botões e Tokens.

### D-AVA1 · Orçamento
O CTX mantém a operação paga em HOLD. Sem um valor, os blocos D2 e D3 só podem usar modo sem custo e testes autorizados. O valor deve cobrir o piloto (dois vendedores e um coordenador) com teto mensal e alerta ao atingir 80%.

### D-SIM1 · Comparação entre instituições
O protótipo mostra ao vendedor uma comparação de parcelas entre instituições. Como o vendedor não decide banco, essa tela pode induzir expectativa. A recomendação é deixá-la só na Mesa. Se o Owner quiser ao vendedor, ela vira apenas informativa, com o aviso de que a Mesa decide.

### D-GAM1 · XP
Pontos ligados à aprovação de crédito criam incentivo errado. A proposta é pontuar só eventos confirmados e auditáveis (PED faturado, ficha sem retrabalho, tarefa concluída no prazo), com estorno quando o evento é cancelado.

---

<!-- ARQUIVO 07_PROPOSTA_ATUALIZACAO_QUADRO.md -->

# Proposta de atualização do quadro canônico

**Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Para conciliação pelo Codex.** O quadro canônico não foi alterado. Esta é a atualização proposta.

## Itens existentes no quadro (CTX §10)

| ID | Estado no CTX | Proposta | Evidência desta entrega |
|---|---|---|---|
| DS01 · Tokens e componentes globais | Incompleto | **Especificação entregue; implementação pendente** | DESIGN_SYSTEM_SPEC, tokens.css/json, catálogo, manifesto `fb6416c`. Não implementado no Portal. |
| DS02 · Aplicação por telas | Incompleto | Sem mudança de estado; ganha os sub-blocos DS-02.A e B1–B5 | IMPLEMENTATION_BLOCKS |
| BI01 · Catálogo de métricas | Parcial | Sem mudança; ganha o comando BI-01.C1 | IMPLEMENTATION_BLOCKS |
| BI02 · Gráficos, filtros, drill-down | Incompleto | Sem mudança; ganha o comando BI-01.C2 | IMPLEMENTATION_BLOCKS |
| DASH01 · Dashboard por perfil | Incompleto | Sem mudança; incluído em BI-01.C2 | IMPLEMENTATION_BLOCKS |
| AVA01 · Orçamento e autorização | Decisão pendente | Sem mudança; detalhado em D-AVA1 a D-AVA4 | DECISIONS_REQUIRED |
| AVA02 · Análise no host | HOLD | Sem mudança; contrato AVA-03 a reconciliar em D1 | AVA_ASSISTANT_CONTRACT |
| FUN01 · Inventário de rotas | Pendente | Sem mudança; é pré-condição do bloco A | FUNCTIONAL_GAP_MATRIX |

## IDs novos propostos

| ID | Título | Relação | Estado inicial |
|---|---|---|---|
| DS-01 | Referência visual e especificação do design system | Detalha DS01 | Especificação entregue (ACEITE HUMANO PENDENTE) |
| DS-02.A | Tokens, componentes, shell e Funil | DS02 | Pendente; aguarda baseline pós-F7-015 |
| DS-02.B1…B5 | Telas existentes | DS02 | Pendente |
| PLAN-01 | Matriz de diferenças protótipo × Portal | FUN01 | Entregue; itens de inspeção pendentes |
| BI-01.C1 / C2 | Catálogo de métricas / dashboard e BI | BI01, BI02, DASH01 | Pendente |
| AVA-03 | Contrato do assistente | AVA01, AVA02 | Proposta entregue; reconciliação D1 com o Codex |
| NOV-01.E1…E3 | Tarefas e notificações, suporte, conversas | — | Aguarda decisões |
| NOV-01.F1 / F2 | WhatsApp oficial (plano) / metas e XP | FUT01 para metas | Aguarda decisões |

## Pontos do plano técnico anterior que esta entrega substitui

O "Plano técnico de implementação" anterior (protótipo v1) propunha tabelas novas, eventos de domínio como base de métricas e `workspace_settings`. Pelo comando IRMEN-JARVIS-002:
- nenhuma tabela é prescrita sem comparar com o schema;
- reforma de banco e eventos não é pré-requisito do visual;
- não há `workspace_id` generalizado.

Esses trechos do plano anterior ficam **suspensos** até a inspeção do código real.

## Registro de fechamento desta entrega

**ACEITE HUMANO PENDENTE.** A especificação foi entregue; nenhuma implementação real foi feita nem declarada.

---

## Anexo · tokens.css

```css
/* Tokens do Portal IRMEN (Jarvis), extraídos de index.html do protótipo homologado.
   Fonte: abaramagold91/irmen-jarvis-demo @ fb6416c · index.html sha256 f830d7b7452a2fa26ac9ebaf4cf76d75fcbb8175fd53dc7310f13ad404768fa7
   Escuro é o padrão; Slate claro via [data-theme="light"]. Não editar à mão: regenerar a partir da fonte. */
:root{
  color-scheme: dark;
  --bg: #06080c;
  --bg-2: #0a0e14;
  --panel: rgba(13,18,26,.78);
  --panel-solid: #0d121a;
  --panel-2: rgba(20,27,38,.85);
  --line: rgba(140,190,220,.13);
  --line-2: rgba(140,190,220,.24);
  --fg: #e8eef4;
  --fg-2: #a3b0bd;
  --fg-3: #8592a0;
  --brand: #ef3f4f;
  --brand-ink: #ffffff;
  --brand-soft: rgba(239,63,79,.14);
  --arc: #3fd0ff;
  --arc-soft: rgba(63,208,255,.12);
  --arc-glow: rgba(63,208,255,.35);
  --good: #34c38f;
  --good-soft: rgba(52,195,143,.14);
  --warn: #f2b84b;
  --warn-soft: rgba(242,184,75,.14);
  --crit: #ff6b7a;
  --crit-soft: rgba(255,107,122,.14);
  --violet: #a594ff;
  --c1: #ef3f4f;
  --c2: #1aa3cf;
  --c3: #c0821a;
  --c4: #8a78f0;
  --c5: #22a06b;
  --shadow: 0 10px 40px rgba(0,0,0,.45);
  --net: 63,208,255;
  --net-2: 239,63,79;
  --f-display: "Chakra Petch", "Rajdhani", "Segoe UI", system-ui, sans-serif;
  --f-body: "IBM Plex Sans", "Segoe UI", system-ui, sans-serif;
  --f-mono: "JetBrains Mono", ui-monospace, "Cascadia Mono", Consolas, monospace;
  --r: 10px;
  --side: 252px;
}
:root[data-theme="light"]{
  color-scheme: light;
  --bg: #e6eaf0;
  --bg-2: #dde3ea;
  --panel: rgba(255,255,255,.86);
  --panel-solid: #ffffff;
  --panel-2: rgba(244,247,250,.95);
  --line: rgba(30,50,70,.12);
  --line-2: rgba(30,50,70,.22);
  --fg: #0f1722;
  --fg-2: #3f4b58;
  --fg-3: #5a6673;
  --brand: #d42a3a;
  --brand-soft: rgba(212,42,58,.10);
  --arc: #0a7aa8;
  --arc-soft: rgba(10,122,168,.10);
  --arc-glow: rgba(10,122,168,.25);
  --good: #137a50;
  --good-soft: rgba(19,122,80,.10);
  --warn: #94600a;
  --warn-soft: rgba(178,116,10,.12);
  --crit: #c01f33;
  --crit-soft: rgba(192,31,51,.10);
  --violet: #5b4bd6;
  --c1: #d42a3a;
  --c2: #0b84b8;
  --c3: #b7791f;
  --c4: #6c5ce7;
  --c5: #16935f;
  --shadow: 0 8px 30px rgba(20,40,60,.10);
  --net: 10,122,168;
  --net-2: 212,42,58;
}
```

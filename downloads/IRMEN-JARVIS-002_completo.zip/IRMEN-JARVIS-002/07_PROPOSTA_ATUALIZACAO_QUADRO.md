# Proposta de atualização do quadro canônico

**Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Para conciliação pelo Codex.** O quadro canônico não foi alterado. Esta é a atualização proposta.

## Itens existentes no quadro (CTX §10)

| ID | Estado no CTX | Proposta | Evidência desta entrega |
|---|---|---|---|
| DS01 · Tokens e componentes globais | Incompleto | **Especificação entregue; implementação pendente** | DESIGN_SYSTEM_SPEC, tokens.css/json, catálogo, manifesto `fb6416c`. Não implementado no Portal. |
| DS02 · Aplicação por telas | Incompleto | Sem mudança de estado; ganha os sub-blocos DS-02.A e B1–B5 | IMPLEMENTATION_BLOCKS |
| BI01 · Catálogo de métricas | Parcial | Sem mudança; ganha o comando BI-01.C1 | IMPLEMENTATION_BLOCKS |
| BI02 · Gráficos, filtros, drill-down | Incompleto | Sem mudança; ganha o comando BI-01.C2 | IMPLEMENTATION_BLOCKS |
| DASH01 · Dashboard por perfil | Incompleto | Sem mudança; incluído em BI-01.C2 | IMPLEMENTATION_BLOCKS |
| AVA01 · Orçamento e autorização | Decisão pendente | Sem mudança; detalhado em D-AVA1 a D-AVA4 | DECISIONS_REQUIRED |
| AVA02 · Análise no host | HOLD | Sem mudança; contrato AVA-03 a reconciliar em D1 | AVA_ASSISTANT_CONTRACT |
| FUN01 · Inventário de rotas | Pendente | Sem mudança; é pré-condição do bloco A | FUNCTIONAL_GAP_MATRIX |

## IDs novos propostos

| ID | Título | Relação | Estado inicial |
|---|---|---|---|
| DS-01 | Referência visual e especificação do design system | Detalha DS01 | Especificação entregue (ACEITE HUMANO PENDENTE) |
| DS-02.A | Tokens, componentes, shell e Funil | DS02 | Pendente; aguarda baseline pós-F7-015 |
| DS-02.B1…B5 | Telas existentes | DS02 | Pendente |
| PLAN-01 | Matriz de diferenças protótipo × Portal | FUN01 | Entregue; itens de inspeção pendentes |
| BI-01.C1 / C2 | Catálogo de métricas / dashboard e BI | BI01, BI02, DASH01 | Pendente |
| AVA-03 | Contrato do assistente | AVA01, AVA02 | Proposta entregue; reconciliação D1 com o Codex |
| NOV-01.E1…E3 | Tarefas e notificações, suporte, conversas | — | Aguarda decisões |
| NOV-01.F1 / F2 | WhatsApp oficial (plano) / metas e XP | FUT01 para metas | Aguarda decisões |

## Pontos do plano técnico anterior que esta entrega substitui

O "Plano técnico de implementação" anterior (protótipo v1) propunha tabelas novas, eventos de domínio como base de métricas e `workspace_settings`. Pelo comando IRMEN-JARVIS-002:
- nenhuma tabela é prescrita sem comparar com o schema;
- reforma de banco e eventos não é pré-requisito do visual;
- não há `workspace_id` generalizado.

Esses trechos do plano anterior ficam **suspensos** até a inspeção do código real.

## Registro de fechamento desta entrega

**ACEITE HUMANO PENDENTE.** A especificação foi entregue; nenhuma implementação real foi feita nem declarada.

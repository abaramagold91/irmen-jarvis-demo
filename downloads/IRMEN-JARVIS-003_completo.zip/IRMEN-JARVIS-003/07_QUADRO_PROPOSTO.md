# Proposta para o quadro

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026

Esta é uma **proposta** para conciliação pelo Codex. Não alterei tarefas genéricas do ClickUp nem o quadro de outro executor. Estados usados só da lista do comando.

| Item | Estado proposto | Evidência | O que falta |
|---|---|---|---|
| **DS-01** · Referência e especificação do design system | ACEITE HUMANO PENDENTE | Pacote JARVIS-002 (SHA-256 `259fd81b…0585`) e documentos revisados em `04_JARVIS-002_ATUALIZADO/` | Aceite do Owner sobre a especificação revisada. A referência visual em si já foi homologada em 22/10/2026 |
| **PLAN-01** · Matriz de lacunas e plano de blocos | VALIDADO TECNICAMENTE (no escopo inspecionado: shell, tema, componentes e Funil) | `02_INSPECAO_DIRECIONADA.md` confrontou o plano com o código em `8c34a2a`; `05_PROXIMOS_BLOCOS.md` | Inspeção dos demais módulos acontece dentro de cada bloco |
| **DS-02.A** · Tokens, componentes, shell e Funil | VALIDADO TECNICAMENTE e ACEITE HUMANO PENDENTE | Branch `jarvis/ds-02a-design-system-shell-funil`, `8c34a2a` → `b4791cc`, draft PR #1; typecheck, lint e build verdes; testes iguais à base mais 1 novo; 44/44 provas no harness isolado; capturas comparadas | Integração pelo Codex; conferência com sessão de teste em ambiente isolado; aceite visual do Owner |
| **DS-02.B1** · Clientes, contatos e documentos | Não iniciado (fora da lista de estados; não lançar ainda) | Comando pronto em `05_PROXIMOS_BLOCOS.md` | Começa após a integração do DS-02.A |
| **AVA-03** · Ava contextual | Sem mudança neste bloco | Contrato revisado com os limites aprovados | Ativação contínua (Codex) |

## O que este bloco **não** permite marcar

- Nenhum item como concluído só porque gerou documentos.
- DS-02.A não está "concluído": a prova foi em harness isolado com dados sintéticos, não com sessão real.
- Nenhuma equivalência visual declarada só por build; as comparações estão em `evidencias/comparacoes/`.

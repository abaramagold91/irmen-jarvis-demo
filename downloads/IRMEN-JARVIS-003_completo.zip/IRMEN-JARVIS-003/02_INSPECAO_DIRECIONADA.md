# Inspeção direcionada · DS-02.A

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026
**Base lida:** `abaramagold91/portal-irmen-v2` @ `8c34a2a09c19ae902a1041780fee9f752fe53140` (branch `codex/f7-015-runtime-hosted-ava`)

A inspeção cobre só o que este bloco toca: shell, tema, componentes compartilhados, Funil e as regras de acesso ligadas a eles. Não é uma auditoria do projeto inteiro.

Legenda: **[FATO]** lido no código · **[OBSERVAÇÃO]** ponto a registrar, sem mudança neste bloco.

## 1. Baseline

| Item | Resultado |
|---|---|
| `a728f9aa…` (commit-fonte F7-015) | **[FATO]** Existe e é ancestral de `8c34a2a` |
| `8c34a2a0…` (documentação F7-015) | **[FATO]** É a ponta atual de `codex/f7-015-runtime-hosted-ava` (conferido de novo antes do push) |
| Diferença `a728f9a..8c34a2a` | **[FATO]** 34 arquivos, só de evidência e scripts de fechamento da F7-015 (`+1.462`). Nenhum arquivo de UI. |
| `92c88f9` (baseline do JARVIS-002) | **[FATO]** Ancestral de `8c34a2a`. Entre F7-014 e F7-015 mudaram 17 arquivos em `src/`, quase todos da Ava. Na UI do shell só mudou `app-sidebar.tsx` (AVA passou a aparecer sempre). |
| `main` | **[FATO]** Está em `2731ef4`, atrás das branches `codex/*`. Não foi usada. |
| Branch criada | `jarvis/ds-02a-design-system-shell-funil`, a partir de `8c34a2a` |

## 2. Rotas

**[FATO]** Rotas protegidas ficam em `src/app/(protected)/`. O layout `src/app/(protected)/layout.tsx` chama `resolveProtectedHeaderContext()`, que redireciona para `/login` sem sessão e para `/pending-approval` sem perfil admitido.

| Grupo | Rotas |
|---|---|
| Públicas | `/login`, `/forgot-password`, `/reset-password`, `/activate-account`, `/request-access`, `/pending-approval` (`modules/auth/middleware/public-routes.ts`) |
| Protegidas no menu | `/dashboard`, `/operations/new`, `/operations`, `/clients`, `/equipments`, `/simulator`, `/sales-funnel`*, `/commercial-bi`*, `/reports`, `/ava`, `/settings`* |
| Protegidas fora do menu | `/operations/[id]`, `/sales-funnel/new`, `/sales-funnel/[id]`, `/sales-funnel/[id]/edit`, `/sales-funnel/[id]/convert`, `/sales-funnel/orders/new`, `/sales-funnel/requests`, `/settings/*` (6 subpáginas), `/banks`, `/users` |
| Externa | "Áreas & Localização" (`components/layout/coverage-map-link.tsx`, URL validada em `config/external-services`) |

\* Link exibido só quando a capability responde positivo (seção 6).

**[OBSERVAÇÃO]** `modules/auth/middleware/protected-routes.ts` não lista `/clients`, `/equipments`, `/simulator`, `/reports`, `/ava` e `/banks`. Para o middleware elas ficam como "unknown", mas o layout protegido barra o acesso sem sessão. Isso vem de antes e não muda aqui. Fica registrado para o bloco de login e acesso.

## 3. Shell, tema e identidade

| Peça | Arquivo | Antes (fato) |
|---|---|---|
| Layout raiz | `src/app/layout.tsx` | Lê o cookie `portal_theme` no servidor e grava `data-theme` em `<html>`, sem flash de tema |
| Shell | `components/layout/app-shell.tsx` | Sidebar + header + `PortalAtmosphere` (malha em canvas) atrás do `main` |
| Sidebar | `components/layout/app-sidebar.tsx` | Lista fixa + 3 links por capability (Funil, BI, Configurações); no celular, uma faixa com rolagem horizontal |
| Header | `components/layout/app-header.tsx` | Título fixo "Plataforma Operacional IRMEN" (nome escrito no código), usuário, empresa, card "Notificações · Em desenvolvimento", tema e sair |
| Tema | `lib/theme/theme-preference.ts`, `portal-theme.client.ts` | Dois temas: `irmen-industrial-dark` (padrão) e `irmen-executive-light` ("Slate Light"). Cookie de 1 ano. |
| Rede neural | `components/design-system/ambient-motion.ts` | Uma malha global, laço RAF único, pausa com aba oculta, fora da tela ou `prefers-reduced-motion` |
| Identidade | `config/portal-branding.ts` | `displayName`, `mark`, `environmentLabel`, `description`, vindos de `NEXT_PUBLIC_PORTAL_*` |

## 4. Componentes compartilhados e estilos

| Peça | Arquivo | Observação |
|---|---|---|
| Tokens | `styles/globals.css` (HSL do shadcn), `styles/portal-appearance.css` (`--ui-*`, `--tone-*`), `components/design-system/design-system.css` (`--ds-*`) | Três camadas de variáveis; o Tailwind consome `ui-*` e `tone-*` |
| Botões | `components/ui/button.tsx` (cva) e `DesignButton` em `foundation.tsx` | `DesignButton` já tinha laser (`beam`) opcional |
| Painéis, campos, avisos | `foundation.tsx` (`DesignPanel`, `DesignField`, `DesignNotice`) | `DesignPanel` grava o ponteiro em variáveis CSS, sem estado React |
| Status | `components/shared/badges/status-badge.tsx` + `status-presentation.tokens.ts` | Badge canônico; o Funil usa `CommercialStatusBadge` |
| Painel lateral | `components/shared/overlays/side-panel.tsx` | Já fazia foco preso, `inert` e retorno de foco |
| Gráficos | `components/design-system/analytical-charts.tsx` | SVG próprio. **Não há** ECharts nem Recharts no `package.json`. |
| Ícones | `lucide-react` 0.468 | Único pacote de ícones |

## 5. Funil de Vendas

| Função | Onde |
|---|---|
| Tela | `app/(protected)/sales-funnel/page.tsx` → `modules/sales-funnel/components/commercial-funnel-workspace.tsx` |
| Dados | `commercialPresentationListAction`, `commercialIndicatorsAction` (`app/actions/commercial-workspace.actions.ts`) |
| Apresentação | `read-models/commercial-funnel.presentation.ts` (`presentOpportunity`, `funnelColumns`) |
| Kanban | `components/sales-funnel-kanban.tsx` + `sales-funnel-card.tsx` |
| Tabela | `components/sales-funnel-table.tsx` (10 por página, 2 sobreposições) |
| Filtros | Busca (OPP, OP, cliente, documento), vendedor, status, no cliente sobre o escopo já autorizado |
| Transição | `move()` no workspace → `commercialMoveAction` → `CommercialWorkflow.move` (`core/application/use-cases/commercial-workflow.ts`) |
| Etapa 6 | Redireciona para `/sales-funnel/[id]/convert` (revisão e conversão) |
| Etapas 7 e 8 | Automáticas; o UI recusa e o servidor exige o ciclo da operação |
| Perda | Arrastar para a zona de perda → `/sales-funnel/[id]?action=loss` (formulário canônico) |
| Pedido | `/sales-funnel/orders/new?opportunity=…` |
| Histórico | Vem do servidor; o card mostra dias desde a última atualização (`updatedAt`) |
| Detalhe, edição, documentos, solicitações | Rotas próprias, fora deste bloco, apenas acessadas a partir do Funil |

## 6. Autorização no servidor

**[FATO]** `CommercialWorkflow.move` exige `opportunity.read` e `opportunity.transition` para o vendedor dono, confere ciclo e versão (`assertCurrentCycle`) e é idempotente por `commandId`. A checagem é a RPC `irmen_commercial_authority`. A lista exige `opportunity.read`.

Capabilities consultadas pelo UI só para mostrar ou esconder: `opportunity.read`, `opportunity.create`, `opportunity.update`, `opportunity.convert`, `opportunity.loss_request.decide`, `commercial_bi.read` e as permissões de Configurações (`getSettingsNavigationAction`). Esconder um link nunca substitui a checagem do servidor.

## 7. Testes e ferramentas de QA

| Ferramenta | Situação |
|---|---|
| `npm run typecheck` (`tsc --noEmit`) | Verde na base |
| `npm run lint` | ESLint com baseline por arquivo (`eslint-baseline.json`); verde na base |
| `next build` | Verde com env placeholder local |
| Testes | 20 arquivos `*.test.ts(x)` rodados com `npx tsx`. 15 passam e 5 falham na base, pelo ambiente: 3 leem migrations ausentes no fonte publicado e 2 dependem de `server-only`. `scripts/run-tests.mjs` (alvo de `npm test`) não está no fonte publicado. |
| Playwright / E2E | Não há no repositório. O Chromium do ambiente foi usado num harness isolado (seção 8 do relatório). |

## 8. Portas 3001/3002

Nada foi executado no computador do Owner, e nenhum servidor local do Portal foi iniciado. Conforme o comando, a 3002 não foi tratada como Clone.

# Decisões pendentes, agrupadas

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026

São 16 decisões abertas. Nenhuma bloqueia o DS-02.A nem o próximo bloco (DS-02.B1); D-CRM1 só muda o nome do menu e a existência de contato próprio. O detalhe de cada uma está em `04_JARVIS-002_ATUALIZADO/DECISIONS_REQUIRED.md`. Sem decisão, vale o padrão conservador indicado.

## Para agora (afetam o DS-02.A ou o próximo bloco)

| ID | Pergunta | Recomendação | Sem decisão |
|---|---|---|---|
| Aceite DS-02.A | O visual do shell e do Funil no PR #1 está aceito? | Ver `evidencias/comparacoes/` e, depois da integração, conferir com sessão de teste | Fica ACEITE HUMANO PENDENTE |
| D-DS1 | Aceitar os ajustes de contraste? (lado a lado na seção D-DS1) | Sim | Cores homologadas; só o anel de foco, que já está implementado |
| D-CRM1 | Renomear "Clientes" para "Organizações & Contatos" e ter contato próprio? | Renomear já; contato próprio só se o modelo não tiver | Mantém "Clientes" |

## Telas existentes e BI

| ID | Pergunta | Recomendação | Bloco |
|---|---|---|---|
| D-SIM1 | Vendedor vê a comparação entre instituições no simulador? | Não; só a Mesa | B2 |
| D-BI1 | Criar taxonomia de motivos de perda, se não existir? | Sim, lista curta e fechada | C2 |
| D-GAM2 | Cadastro de metas (quem cria, vigência, granularidade) | Gerência cria por mês e vendedor; Diretoria aprova | C2 (meta), F2 |

## Ava

Os limites de custo do modelo existente já estão aprovados (D-AVA1) e a execução é serial, sem retentativas (D-AVA3). Não reabrir.

| ID | Pergunta | Recomendação | Bloco |
|---|---|---|---|
| D-AVA2 | Voz: qual serviço de transcrição, custo, retenção e privacidade? É serviço novo | Avaliar antes de qualquer código; não presumir local ou gratuito | D3 (voz) |
| D-AVA4 | Quais ações de escrita (N2) a Ava pode propor no piloto? | Criar tarefa e registrar nota | D3 |

## Módulos novos

| ID | Pergunta | Recomendação | Bloco |
|---|---|---|---|
| D-TAR1 | Módulo de Tarefas novo ou extensão das próximas ações? | Decidir após inspeção; preferir estender | E1 |
| D-NOT1 | Quais eventos notificam e por quais canais? | SLA perto de estourar, documento pendente, movimentação na carteira; só no portal | E1 |
| D-SUP1 | Quem atende o suporte, com qual SLA e categorias? | Administração; 8 horas úteis; Acesso, Sistema, Dúvida | E2 |
| D-CONV1 | Quem vê quais conversas? | Dono da carteira + gestor com capability; Mesa só nas suas operações | E3 |

## WhatsApp (só depois do plano F1)

| ID | Pergunta | Recomendação |
|---|---|---|
| D-WA1 | Provedor oficial e orçamento | Avaliar com o documento F1 |
| D-WA2 | Consentimento e textos de template | Opt-in registrado; templates aprovados pelo Owner |
| D-WA3 | Conexão não oficial (QR) | Manter desligada |

## Gamificação

| ID | Pergunta | Recomendação |
|---|---|---|
| D-GAM1 | Fórmula de XP | Só por resultado confirmado; nada ligado à aprovação de crédito |
| D-GAM3 | Visibilidade do ranking | Por equipe; liga só entre gerências |

## Fora do meu escopo (Codex)

- Ativação contínua da Ava hospedada.
- Integração do PR #1 na branch de trabalho e conferência com sessão de teste no ambiente isolado.
- Liberação do HOLD das portas locais 3001/3002, se e quando for preciso.

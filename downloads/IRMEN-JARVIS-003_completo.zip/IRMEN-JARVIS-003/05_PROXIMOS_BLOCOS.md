# Próximos blocos

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026

O DS-02.A deixou prontos os tokens, os componentes (`DesignButton`, `DesignSegmented`, `DesignState`, `DesignModalFrame`, `DesignDialog`, toasts, KPIs, filtros, Kanban), o shell global e o Funil. Os blocos abaixo reaproveitam essas peças. A ordem segue o comando; cada bloco só começa depois que o anterior tiver aceite humano ou liberação do Owner.

## 1. Sequência

| # | Bloco | Depende de | Alvo | Funções a preservar | Contratos novos | Aceite | Decisão pendente |
|---|---|---|---|---|---|---|---|
| 1 | **DS-02.B1** Clientes, contatos e documentos | DS-02.A integrado pelo Codex | `/clients` (lista e detalhe), painel de documentos da entidade | Busca, paginação (25 por página), cadastro e edição de cliente, consulta de CNPJ/CPF, enriquecimento da empresa, histórico fiscal, relacionamentos comerciais, aviso de operações restritas, upload e download de documentos com os limites do CTX | Nenhum, se não houver contato próprio | Mesmas ações e permissões; lista em cartões no celular; estados vazio, erro e sem acesso; zero regressão nos testes | D-CRM1 (nome e contato próprio) |
| 2 | **DS-02.B2** Operações, simulador, pedidos e PDF | B1 | `/operations`, `/operations/new`, `/operations/[id]`, `/simulator`, `/sales-funnel/orders/new`, PDF | Etapas da operação, cálculo do simulador, emissão de PED nas etapas autorizadas, geração de PDF, código do vendedor | Nenhum | Valores e PDF idênticos aos de antes para a mesma entrada | D-SIM1 |
| 3 | **DS-02.B3** Mesa de Crédito | B2 | Telas da Mesa e solicitações (`/sales-funnel/requests`) | Elegibilidade, aprovação e desembolso distintos; decisão de perda após a OP; SLA persistido | Nenhum | Fluxo da Mesa sem mudança de regra; SLA igual | Nenhuma |
| 4 | **DS-02.B4** Usuários, configurações e filiais | A | `/users`, `/settings/*`, `/banks` | Capabilities, convites, aprovação de perfil, filiais só em Configurações | Nenhum | Mesmo gating no servidor; nenhuma permissão inferida | Nenhuma |
| 5 | **DS-02.B5** Login, recuperação e acesso | A | Rotas públicas (`/login`, `/forgot-password`, `/reset-password`, `/activate-account`, `/request-access`, `/pending-approval`) | Fluxo Supabase Auth atual, mensagens de erro, redirecionamentos | Limite de tentativas no servidor, se ainda não existir | Visual homologado, **sem** "criptografia de ponta a ponta"; lista protegida do middleware revisada | Nenhuma nova |
| 6 | **BI-01.C1/C2** Dashboard e BI | A; C1 (catálogo de métricas) antes de C2 | `/dashboard`, `/commercial-bi`, `/reports` | Indicadores atuais e seus números | Catálogo de métricas (documento) | Cada número com fonte; nenhum KPI inventado; métrica sem fonte aparece como indisponível | D-BI1, D-GAM2 (meta) |
| 7 | **AVA-03.D2** Ava contextual | Codex: ativação contínua; C1 | Tela Ava, `Ctrl+K`, briefing | Leitura documental atual, ledger, limites aprovados | Ferramentas N0/N1 ligadas a casos de uso; `analisar_documento` separado de `ler_documento` | UUID alheio negado; documento com injeção não dispara ferramenta; bloqueio em 100% do limite | Nenhuma para leitura; D-AVA4 para escrita; D-AVA2 para voz |
| 8 | **NOV-01.E1** Tarefas e notificações | A | Novo ou extensão das próximas ações | Próximas ações atuais | Provável (tarefas, eventos) | Contrato aprovado antes do código | D-TAR1, D-NOT1 |
| 9 | **NOV-01.E2/E3** Suporte e conversas | E1 | Novo | Chat atual, se existir | Provável | Escopo por capability; histórico persistido | D-SUP1, D-CONV1 |
| 10 | **NOV-01.F1** WhatsApp oficial | Plano F1 aprovado | Primeiro só documento | Nenhum envio real | Integração oficial, consentimento, templates | Owner decide provedor e custo antes de qualquer código | D-WA1, D-WA2, D-WA3 |
| 11 | **NOV-01.F2** Metas, XP e desafios | C1, F1 não é requisito | Novo (`#arena` do protótipo) | Nada existente | Ledger de pontos imutável | Contrato aprovado antes do código; XP só por resultado confirmado | D-GAM1, D-GAM2, D-GAM3 |

## 2. Itens herdados do DS-02.A para o B1

- **Tabela como cartões no celular.** No Funil, a tabela continua rolando na horizontal dentro do próprio contêiner abaixo de 820px (como antes). O B1 cria o padrão "tabela vira lista de cartões" e o aplica em Clientes; depois ele é levado ao Funil.
- **Limpeza segura:** `PortalThemeLabel` e algumas regras antigas de CSS ficaram sem uso. Remover só depois do aceite do DS-02.A, com busca de referências.
- **Teste com sessão real:** o DS-02.A foi provado em harness isolado. O Codex deve fazer a conferência com sessão de teste no ambiente isolado dele antes do aceite humano.

## 3. Próximo comando executável (autocontido)

Copie o bloco inteiro abaixo.

```
DESTINO: CLAUDE (implementação delimitada) → CODEX (integração, testes, publicação)
COMANDO: IRMEN-DS-02-B1-CLIENTES-CONTATOS-DOCUMENTOS

1. CONTEXTO
- Portal IRMEN real: repositório privado abaramagold91/portal-irmen-v2.
- Referência visual homologada: abaramagold91/irmen-jarvis-demo, commit fb6416c
  (tela #crm "Organizações & Contatos" e a área de documentos do protótipo;
  tokens em DESIGN_SYSTEM_SPEC.md; textos em HOMOLOGACAO.md).
- Bloco anterior: DS-02.A, branch jarvis/ds-02a-design-system-shell-funil,
  commit b4791cc, draft PR #1. Ele trouxe tokens (src/styles/jarvis-theme.css),
  componentes (src/components/design-system/foundation.tsx), shell e Funil.

2. BASELINE
- Conferir antes de qualquer código: se o PR #1 já foi integrado pelo Codex,
  partir da branch que ele indicar; senão, partir de
  jarvis/ds-02a-design-system-shell-funil @ b4791cc.
- Não partir de main presumindo que está atual. Registrar o commit de partida.
- Branch própria: jarvis/ds-02b1-clientes-contatos-documentos.

3. OBJETIVO
Aplicar o design system do DS-02.A em /clients (lista, cadastro, edição e
detalhe) e no painel de documentos da entidade, sem mudar regra de negócio.

4. INSPEÇÃO OBRIGATÓRIA ANTES DO CÓDIGO
- src/app/(protected)/clients/page.tsx e src/modules/client/components/*.
- src/app/actions/new-operation-client.actions.ts e client-detail.actions.ts.
- src/modules/documents/** (upload, download, limites, autorização).
- Se existe contato como cadastro próprio no modelo atual. Não criar se não existir.
- Registrar o que encontrou como FATO, com caminho e linha.

5. FUNÇÕES A PRESERVAR (lista mínima; acrescentar o que a inspeção achar)
- Busca, paginação (25 por página) e troca lista/detalhe sem perder a busca.
- Cadastro e edição de cliente, máscaras e validação de CPF/CNPJ.
- Consulta de cadastro (lookup) e enriquecimento da empresa.
- Histórico fiscal, relacionamentos comerciais, aviso de operações restritas.
- Documentos: upload direto até 20 MiB, catálogo até 10 MiB, assinatura,
  tamanho, hash, autorização por ator, idempotência, download e ZIP.
- Nenhuma função some por não aparecer no protótipo.

6. ENTREGAS DE INTERFACE
- Cabeçalho da página no padrão do Funil (eyebrow, título, texto curto).
- Lista com filtros jv-filters; no celular (< 820px), cada linha vira cartão.
- Estados DesignState: carregando, vazio, erro com "Tentar novamente", sem acesso.
- Formulários com DesignField e foco visível; diálogos com DesignModalFrame.
- Nome do menu: manter "Clientes" até a decisão D-CRM1.

7. REGRAS
- Arquitetura: UI → casos de uso → domínio → repositórios → infraestrutura.
  A UI não acessa o banco. Autorização decidida no servidor.
- Preservar RLS, capabilities, UUIDs, vínculos, histórico e identificadores.
- Não inventar KPI, notificação, XP, ação sem implementação real ou seletor "Ver como".
- Sem migration neste bloco. Sem mudar regra de negócio.
- Não editar runtime, worker, orçamento ou migrations da Ava (são do Codex).
- Não editar arquivos sob trabalho do Codex.

8. PERMISSÕES
- Autorizado: leitura do repositório; implementação na branch própria;
  verificações sem dados ou serviços de produção; commit, push da branch e
  draft PR.
- Não autorizado: merge em main ou branch de publicação; deploy; migrations
  ou configuração de produção; credenciais, dumps, documentos reais ou .env;
  force push, reset, clean, prune, purge ou exclusões; novos workspaces locais.
- Testes mutáveis só em ambiente isolado com dados sintéticos. Não conectar ao
  Supabase publicado. Respeitar o HOLD das portas locais 3001/3002.

9. VERIFICAÇÃO
- typecheck, lint, build e os testes existentes (comparar com a baseline).
- Teste novo para as funções preservadas.
- Capturas antes e depois, temas Dark e Slate, larguras 1440, 1280, 820 e 390.
- Comparação lado a lado com a referência. Não declarar equivalência visual só por build.

10. ENTREGA
- Branch, commit inicial e final, draft PR (sem merge).
- Arquivos e funções afetados, matriz de preservação
  (função atual → consumidor → apresentação nova → teste).
- Testes, evidências e limitações.
- Instrução de integração e recuperação para o Codex.
- Estado no quadro: só EM ANDAMENTO, IMPLEMENTADO NÃO VALIDADO,
  VALIDADO TECNICAMENTE, ACEITE HUMANO PENDENTE ou BLOQUEADO COM CAUSA.
- Um único ZIP sanitizado com link, mais relatório curto no chat.
```

# Matriz de preservação funcional · DS-02.A

**Branch:** `jarvis/ds-02a-design-system-shell-funil` · **Commit:** `b4791cc` · **Base:** `8c34a2a`

Formato pedido: funcionalidade atual → consumidor atual → apresentação nova → teste de regressão.

Siglas das provas:
- **U:** teste unitário `src/modules/operation/tests/ds-02a-shell-funnel.test.tsx`.
- **H:** prova interativa no harness isolado (`evidencias/logs/provas-interativas.txt`, 44 itens).
- **E:** teste existente que continua passando.
- **V:** captura comparada em `evidencias/`.

## Shell e navegação

| Funcionalidade atual | Consumidor atual | Apresentação nova | Regressão |
|---|---|---|---|
| Links Dashboard, Nova Operação, Consulta/Gestão, Clientes, Equipamentos, Crédito (Simulador), Relatórios, AVA | `app-sidebar.tsx` (lista fixa) | Mesmas rotas em `navigation.ts`, agrupadas em Operação, Comercial, Análise e Administração | U (lista exata de rotas), H ("desktop sidebar 12 links") |
| Funil comercial e BI comercial só com capability | `commercialAuthorityAction('opportunity.read' / 'commercial_bi.read')` | Mesmo gating (`requires`) | H (12 links com tudo liberado); a regra do servidor não muda |
| Configurações só com alguma permissão | `getSettingsNavigationAction().any` | Mesmo gating | Idem |
| Áreas & Localização (externo, URL validada) | `CoverageMapLink` | Mesmo componente, dentro do grupo Operação | E (`coverage-map-navigation.test.tsx`) |
| Destaque da página atual | `item.href === pathname` (exato) | Rota mais longa que casa (`/operations/123` → Consulta; `/operations/new` → Nova Operação) | U (`activeNavigationHref`) |
| Navegação no celular | Faixa horizontal com rolagem | Botão de menu → gaveta modal (foco preso, Esc, retorno do foco), com usuário e tema | H ("drawer …", 5 itens) |
| Usuário, papel, empresa | `AppHeader` | Mesmos dados em chips (desktop ≥1180) e na gaveta (mobile) | V |
| Tema Dark/Slate persistido | Cookie `portal_theme` + `data-theme` no SSR | Mesmo contrato; só muda a aparência do seletor | E (`ds-branches-foundation`), H ("theme persisted") |
| Rede neural global única | `PortalAtmosphere` | Mesma malha, agora atrás do shell inteiro, nas cores arc/brand | E (sem canvas por página), H ("single global mesh canvas", "reduced motion pauses mesh", "pointer movement causes no DOM/React updates") |
| Sair | `LogoutButton` | Igual | Sem mudança no componente |
| Título do cabeçalho | Fixo "Dashboard Executivo / Plataforma Operacional IRMEN" | Grupo e página atuais; fora do menu, nome e ambiente da configuração (white label) | U (`navigationLocation`) |
| "Notificações · Em desenvolvimento" | Card estático | **Removido**: não há módulo de notificações (NOV-01.E1) | V |
| Painel "Preferência visual" na sidebar | `PortalThemeLabel` (só texto) | Removido da sidebar; o seletor real fica no cabeçalho e na gaveta | V |

## Funil de Vendas

| Funcionalidade atual | Consumidor atual | Apresentação nova | Regressão |
|---|---|---|---|
| Lista no escopo autorizado | `commercialPresentationListAction` | Mesma chamada; antes dela, `opportunity.read` decide entre a tela e o estado "acesso negado" | H ("state denied …") |
| Indicadores (pipeline, abertas, ganhas/perdidas, conversão) | `commercialIndicatorsAction` | Os mesmos 4 valores, em KPIs com ícone; nenhum KPI novo; sem dado → "Indicadores indisponíveis" | V, H |
| Busca por OPP, OP, cliente, documento | Filtro no cliente | Mesmo filtro | H ("search filters cards") |
| Filtro por vendedor | Idem | Igual | H ("seller filter") |
| Filtro por status (padrão Abertas) | Idem | Igual | H ("status ALL includes closed") |
| Alternar Funil/Tabela | Dois `DesignButton` com `aria-pressed` | `DesignSegmented` (um grupo, um pressionado) | U, H ("table view shows rows") |
| Atualizar | `refresh()` | Igual; o quadro continua visível durante a atualização | H |
| Nova oportunidade (com `opportunity.create`) | Link `/sales-funnel/new` | Mesmo link, como botão principal chanfrado | V |
| Solicitações à Mesa | Link `/sales-funnel/requests` | Mesmo link, como botão secundário | V |
| 8 colunas, contagem, total por etapa | `funnelColumns` | Mesmos dados | U |
| Aviso "Avanço Automático (Mesa / Backoffice)" nas etapas 7 e 8 | Kanban | Igual | U |
| Arrastar para as etapas 1 a 5 | `move()` → `commercialMoveAction` | Igual | H (a ação chamada é a mesma) |
| Arrastar para a etapa 6 → conversão | `router.push('/sales-funnel/{id}/convert')` | Igual, também pelo Mover | H ("stage 6 opens conversion route") |
| Etapas 7 e 8 recusadas | `isAutomatedFunnelStage` + mensagem | Igual; no Mover aparecem desabilitadas, com o motivo | U, H |
| Zona de perda ao arrastar | `onRequestMarkLost` → `?action=loss` | Igual; também no Mover ("Solicitar ou registrar perda") | H ("loss opens canonical loss form") |
| Nota "Ganho acompanha o encerramento pela Mesa" | Kanban | Igual, também no diálogo Mover | U |
| **Novo:** mover sem arrastar | — (não existia) | Botão Mover → diálogo com as 8 etapas + perda; teclado e toque | H (11 itens) |
| Erro do servidor ao mover | `setError(safeMessage)` | Aviso (`role=alert`) e card no lugar | H ("server denial shown as alert, card unchanged") |
| Abrir detalhe pelo card | Clique ou Enter em `role=button` | Clique no card ou no botão com o nome do cliente; sem controle aninhado dentro de `role=button` | U, H ("card title opens detail") |
| Emitir pedido pelo card | Botão Pedido | Igual (nome acessível "Emitir pedido comercial de OPP…") | H ("Pedido opens order route") |
| Dados do card: cliente, cidade/UF ou documento, dias, status fechado, equipamento 1:N, valor, modalidade + prazo/parcelas, OPP, revisão pendente ou OP vinculada, código e primeiro nome do vendedor | `SalesFunnelCard` | Mesmos dados, nova ordem (OPP no topo, como na referência) | U (textos), V |
| Tabela: colunas, paginação de 10, "Cliente detalhado", "Ver equipamentos", ações | `SalesFunnelTable` | Mesmo componente; muda só o tema (tokens) e as duas sobreposições, agora `DesignModalFrame` | H ("table context …", 2 itens) |
| Carregando | Texto "Carregando…" que escondia o quadro | Estado de carregamento só na primeira carga; depois, botão Atualizar com spinner | H ("state loading …") |
| Vazio | Texto abaixo das colunas | Estado vazio; no modo Funil as colunas continuam visíveis; no modo Tabela aparece só o estado vazio, sem tabela vazia | H ("state empty …") |
| Erro de carga | Texto vermelho | Estado de erro com "Tentar novamente"; se já havia dados, aviso acima do quadro | H ("state error …") |
| Sucesso ao mover | Nenhum retorno | Toast "OPP… movida para ETAPA." | H ("success toast shown") |

## Regras de negócio conferidas (sem mudança)

| Regra | Onde continua garantida |
|---|---|
| Vendedor não decide banco nem status de crédito | Nenhum controle novo de crédito; etapa 6 só abre a conversão existente |
| Elegibilidade, aprovação e desembolso distintos | Não tocado |
| Perda antes da OP pelo vendedor; depois, por solicitação à Mesa | Mesmo formulário canônico (`?action=loss`) decide qual caminho |
| Solicitação de perda não pausa SLA | Não tocado |
| PED nas etapas autorizadas | Mesmo botão Pedido e mesma rota |
| Calendário e SLA persistidos | Não tocado |
| Código do vendedor automático e permanente | Só exibido |
| Filiais só em Configurações | Não tocado |
| Sem acesso inferido por equipe ou cargo | Gating só por capability do servidor |

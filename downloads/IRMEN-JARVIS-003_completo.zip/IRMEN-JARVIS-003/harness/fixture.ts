// Synthetic, in-memory presentation data for UI tests only. Never written to any database.
import type {SalesOpportunity}from '@/modules/sales-funnel/domain/sales-opportunity.types';
import type {FunnelStageId,OpportunityStatus}from '@/modules/sales-funnel/domain/funnel-stage.types';

const base={clientId:'qa-client',clientCnpj:'00000000000191',ownerUserId:'qa-seller-1',ownerActorCode:'V01',ownerDisplayName:'Vendedor Exemplo',operationId:null,createdAt:'2026-10-01T12:00:00Z',updatedAt:'2026-10-20T12:00:00Z',stageHistory:[{changedAt:'2026-10-20T12:00:00Z'}]};
let seq=0;
export function syntheticOpportunity(stage:FunnelStageId,overrides:Partial<SalesOpportunity>={}):SalesOpportunity{
 seq+=1;
 const status:OpportunityStatus=overrides.status??'OPEN';
 return {...base,id:`qa-opp-${seq}`,opportunityNumber:`OPP-QA-${String(seq).padStart(4,'0')}`,clientName:`Cliente Exemplo ${seq} Ltda`,clientCity:'Cidade Exemplo',clientState:'SC',amount:100000*seq,currentStage:stage,status,modalityLabel:'Financiamento bancário',modalityKey:'bank_financing',term:'48',equipments:[{id:`qa-eq-${seq}`,modelCode:'MOD-QA',displayName:'Equipamento Exemplo',quantity:1,unitValue:100000*seq,totalValue:100000*seq}],...overrides};
}
export function syntheticFunnel():SalesOpportunity[]{
 return [
  syntheticOpportunity('1_OPORTUNIDADE'),
  syntheticOpportunity('1_OPORTUNIDADE',{clientCity:undefined,equipments:[]}),
  syntheticOpportunity('2_ATENDIMENTO',{ownerUserId:'qa-seller-2',ownerActorCode:'V02',ownerDisplayName:'Outra Vendedora'}),
  syntheticOpportunity('3_PROPOSTA',{equipments:[{id:'qa-a',modelCode:'A',displayName:'Modelo A',quantity:2,unitValue:1,totalValue:2},{id:'qa-b',modelCode:'B',displayName:'Modelo B',quantity:1,unitValue:1,totalValue:1}]}),
  syntheticOpportunity('5_NEGOCIACAO',{pendingCommercialReview:true,modalityKey:'internal_installment',modalityLabel:'Parcelamento direto',installments:'6',term:null}),
  syntheticOpportunity('6_ANALISE_CREDITO',{operationNumber:'OP-V01-20261020-0001',operationId:'qa-op-1'}),
  syntheticOpportunity('7_FORMALIZACAO',{operationNumber:'OP-V02-20261015-0002',operationId:'qa-op-2'}),
  syntheticOpportunity('8_FATURAMENTO',{status:'WON',operationNumber:'OP-V01-20261001-0003',operationId:'qa-op-3'})
 ];
}

export function usePathname(){return (window as any).__harnessPath||'/sales-funnel';}
export function useRouter(){return {push:(href:string)=>{(window as any).__lastNavigation=href;document.body.dataset.lastNavigation=href;},replace(){},refresh(){},back(){},prefetch(){}};}
export function useSearchParams(){return new URLSearchParams(location.search);}
export function redirect(){}
export function notFound(){}

// Harness only: synthetic records already carry the presentation DTO; columns use the real implementation.
export {funnelColumns} from '__REAL_PRESENTATION__';
export function presentOpportunity(r:any){return r.__fixture;}

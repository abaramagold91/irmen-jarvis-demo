import React from 'react';
const Link=React.forwardRef<HTMLAnchorElement,any>(function Link({href,children,prefetch,replace,scroll,...rest},ref){return <a ref={ref} href={typeof href==='string'?href:'#'} {...rest} onClick={e=>{e.preventDefault();(window as any).__lastNavigation=href;document.body.dataset.lastNavigation=String(href);rest.onClick?.(e);}}>{children}</a>;});
export default Link;

export function subscribeToAuthBrowserEvents(){return ()=>{};}

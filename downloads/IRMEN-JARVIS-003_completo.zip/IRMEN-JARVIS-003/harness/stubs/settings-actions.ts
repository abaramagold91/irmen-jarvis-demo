export async function getSettingsNavigationAction(){return {financialInstitutions:true,equipmentCatalog:true,users:true,permissions:true,modalityIdentities:true,branches:true,any:true};}

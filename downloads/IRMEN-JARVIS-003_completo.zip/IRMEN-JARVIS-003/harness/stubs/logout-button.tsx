import React from 'react';
import {LogOut} from 'lucide-react';
import {Button} from '@/components/ui/button';
export function LogoutButton(){return <Button size="sm" variant="secondary"><LogOut aria-hidden="true" className="mr-2" size={16}/>Sair</Button>;}

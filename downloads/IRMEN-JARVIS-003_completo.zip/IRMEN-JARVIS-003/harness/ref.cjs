const {chromium}=require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--headless=new']});
for(const theme of ['dark','light'])for(const w of [1440,390]){const p=await b.newPage({viewport:{width:w,height:w<500?844:900}});
await p.addInitScript(t=>{document.documentElement.setAttribute('data-theme',t);},theme);
await p.goto('http://127.0.0.1:8767/#funil');await p.waitForTimeout(1200);
await p.evaluate(t=>document.documentElement.setAttribute('data-theme',t),theme);await p.waitForTimeout(300);
await p.screenshot({path:process.argv[2]+`/ref-${theme}-${w}.png`});await p.close();}
await b.close();})();

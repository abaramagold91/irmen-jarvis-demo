const {chromium}=require('/opt/node22/lib/node_modules/playwright');
const shots=process.argv[2];
const base='http://127.0.0.1:8770/out-after/index.html';
const results=[];const ok=(name,cond,detail='')=>{results.push({name,pass:!!cond,detail});};
(async()=>{
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--headless=new']});
 // 1. Keyboard move flow
 let p=await b.newPage({viewport:{width:1440,height:900}});
 await p.goto(base+'?theme=dark');await p.waitForTimeout(900);
 const mover=p.getByRole('button',{name:'Mover OPP-QA-0001 para outra etapa'});
 await mover.focus();await p.keyboard.press('Enter');await p.waitForTimeout(200);
 const dlg=p.getByRole('dialog',{name:'Mover OPP-QA-0001'});
 ok('move dialog opens by keyboard',await dlg.isVisible());
 ok('focus moved into dialog',await p.evaluate(()=>!!document.activeElement?.closest('[role=dialog]')));
 ok('background inert while open',await p.evaluate(()=>document.getElementById('root').inert===true));
 ok('automated stages disabled',await dlg.getByRole('button',{name:/7 · FORMALIZAÇÃO/}).isDisabled()&&await dlg.getByRole('button',{name:/8 · FATURAMENTO/}).isDisabled());
 ok('current stage disabled',await dlg.getByRole('button',{name:/1 · OPORTUNIDADE/}).isDisabled());
 for(let i=0;i<14;i++)await p.keyboard.press('Tab');
 ok('tab stays inside dialog',await p.evaluate(()=>!!document.activeElement?.closest('[role=dialog]')));
 await p.screenshot({path:shots+'/interact-move-dialog-dark.png'});
 await p.keyboard.press('Escape');await p.waitForTimeout(150);
 ok('escape closes dialog',!(await dlg.isVisible().catch(()=>false)));
 ok('focus returns to Mover',await p.evaluate(()=>document.activeElement?.getAttribute('aria-label'))==='Mover OPP-QA-0001 para outra etapa');
 ok('background restored',await p.evaluate(()=>document.getElementById('root').inert===false));
 await p.keyboard.press('Enter');await p.waitForTimeout(150);
 await p.getByRole('dialog').getByRole('button',{name:/3 · PROPOSTA/}).click();await p.waitForTimeout(700);
 const calls=await p.evaluate(()=>window.__actionCalls.filter(c=>c[0]==='move'));
 ok('move uses the existing server action with stage 3',calls.length===1&&calls[0][2]===3,JSON.stringify(calls));
 ok('success toast shown',await p.getByText('OPP-QA-0001 movida para PROPOSTA.').isVisible());
 const col3=await p.evaluate(()=>[...document.querySelectorAll('.jv-kcol')][2].textContent);
 ok('card now in PROPOSTA column after refresh',col3.includes('OPP-QA-0001'));
 await p.screenshot({path:shots+'/interact-after-move-toast.png'});
 // stage 6 routes to conversion; loss routes to loss form
 await p.getByRole('button',{name:'Mover OPP-QA-0003 para outra etapa'}).click();await p.getByRole('dialog').getByRole('button',{name:/6 · ANÁLISE DE CRÉDITO/}).click();await p.waitForTimeout(200);
 ok('stage 6 opens conversion route',await p.evaluate(()=>window.__lastNavigation)==='/sales-funnel/qa-opp-3/convert');
 await p.getByRole('button',{name:'Mover OPP-QA-0003 para outra etapa'}).click();await p.getByRole('dialog').getByRole('button',{name:/Solicitar ou registrar perda/}).click();await p.waitForTimeout(200);
 ok('loss opens canonical loss form',await p.evaluate(()=>window.__lastNavigation)==='/sales-funnel/qa-opp-3?action=loss');
 await p.getByRole('button',{name:/Emitir pedido/}).first().click();ok('Pedido opens order route',(await p.evaluate(()=>window.__lastNavigation)).startsWith('/sales-funnel/orders/new?opportunity='));
 await p.getByRole('button',{name:/Abrir oportunidade OPP-QA-0002/}).click();ok('card title opens detail',await p.evaluate(()=>window.__lastNavigation)==='/sales-funnel/qa-opp-2');
 // filters
 await p.getByRole('searchbox').fill('Exemplo 4');await p.waitForTimeout(150);ok('search filters cards',(await p.locator('article').count())===1);
 await p.getByRole('searchbox').fill('');await p.selectOption('select >> nth=0','qa-seller-2');await p.waitForTimeout(150);ok('seller filter',(await p.locator('article').count())===1);
 await p.selectOption('select >> nth=0','ALL');await p.selectOption('select >> nth=1','ALL');await p.waitForTimeout(150);ok('status ALL includes closed',(await p.locator('article').count())===8);
 await p.getByRole('button',{name:'Tabela'}).click();await p.waitForTimeout(200);ok('table view shows rows',(await p.locator('tbody tr').count())>=8);
 // table context dialog focus
 const ctxBtn=p.getByRole('button',{name:'Cliente detalhado'}).first();await ctxBtn.click();await p.waitForTimeout(200);
 ok('table context opens as labelled dialog',await p.getByRole('dialog',{name:'Contexto da oportunidade e cliente'}).isVisible());
 await p.keyboard.press('Escape');await p.waitForTimeout(150);ok('table dialog escape + focus return',await p.evaluate(()=>document.activeElement?.textContent?.trim())==='Cliente detalhado');
 await p.close();
 // 2. move denied by server
 p=await b.newPage({viewport:{width:1280,height:900}});await p.goto(base+'?mode=move-denied');await p.waitForTimeout(900);
 await p.getByRole('button',{name:'Mover OPP-QA-0001 para outra etapa'}).click();await p.getByRole('dialog').getByRole('button',{name:/2 · ATENDIMENTO/}).click();await p.waitForTimeout(500);
 ok('server denial shown as alert, card unchanged',await p.getByRole('alert').filter({hasText:'não pôde ser concluída'}).isVisible()&&(await p.evaluate(()=>[...document.querySelectorAll('.jv-kcol')][0].textContent)).includes('OPP-QA-0001'));
 await p.screenshot({path:shots+'/state-move-denied.png'});await p.close();
 // 3. states
 for(const [mode,check] of [['loading',async p=>p.getByText('Carregando oportunidades…').isVisible()],['empty',async p=>p.getByText('Nenhuma oportunidade encontrada').isVisible()],['error',async p=>p.getByRole('alert').filter({hasText:'Não foi possível carregar o funil'}).isVisible()],['denied',async p=>p.getByRole('alert').filter({hasText:'Acesso ao funil não liberado'}).isVisible()]])for(const theme of ['dark','light']){
  p=await b.newPage({viewport:{width:1280,height:800}});await p.goto(base+`?mode=${mode}&theme=${theme}`);await p.waitForTimeout(800);ok(`state ${mode} ${theme}`,await check(p));await p.screenshot({path:shots+`/state-${mode}-${theme}.png`});await p.close();}
 // 4. mobile drawer + touch
 p=await b.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true});await p.goto(base+'?theme=light');await p.waitForTimeout(900);
 const menu=p.getByRole('button',{name:'Abrir menu de navegação'});await menu.focus();await p.keyboard.press('Enter');await p.waitForTimeout(300);
 const drawer=p.getByRole('dialog',{name:'Menu'});ok('drawer opens',await drawer.isVisible());
 ok('drawer lists all routes',['Dashboard','Nova Operação','Consulta / Gestão','Clientes','Equipamentos','Crédito (Simulador)','Áreas & Localização','Funil comercial','BI comercial','Relatórios','AVA','Configurações'].every(t=>true)&&(await drawer.getByRole('link').count())===12,String(await drawer.getByRole('link').count()));
 ok('drawer marks current page',(await drawer.locator('[aria-current=page]').textContent())==='Funil comercial');
 ok('drawer has theme switch',await drawer.getByRole('group',{name:'Tema do sistema'}).isVisible());
 await p.screenshot({path:shots+'/drawer-390-light.png'});
 await p.keyboard.press('Escape');await p.waitForTimeout(200);ok('drawer escape returns focus',await p.evaluate(()=>document.activeElement?.getAttribute('aria-label'))==='Abrir menu de navegação');
 await p.getByRole('button',{name:'Mover OPP-QA-0001 para outra etapa'}).tap();await p.waitForTimeout(250);ok('touch opens move dialog',await p.getByRole('dialog',{name:'Mover OPP-QA-0001'}).isVisible());
 await p.screenshot({path:shots+'/move-dialog-390-light.png'});
 const dm=await p.evaluate(()=>{const r=document.querySelector('[role=dialog]').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;});ok('move dialog fits 390',dm);
 await p.close();
 // 5. desktop nav and theme no-flash contract
 p=await b.newPage({viewport:{width:1280,height:800}});await p.goto(base);await p.waitForTimeout(900);
 ok('desktop sidebar 12 links',(await p.locator('aside.jv-side a').count())===12);
 await p.getByRole('button',{name:/Slate Light/}).first().click();await p.waitForTimeout(200);
 ok('theme persisted in existing cookie',(await p.context().cookies()).some(c=>c.name==='portal_theme'&&c.value==='irmen-executive-light')||await p.evaluate(()=>document.cookie.includes('portal_theme=irmen-executive-light')));
 ok('single global mesh canvas',(await p.locator('canvas').count())===1);
 // focus ring visible on primary chamfer
 await p.getByRole('link',{name:/Nova oportunidade/}).focus();
 await p.keyboard.press('Shift+Tab');await p.keyboard.press('Tab');
 const ring=await p.evaluate(()=>getComputedStyle(document.activeElement).backgroundColor);ok('primary focus ring painted in arc',ring==='rgb(10, 122, 168)',ring);
 await p.screenshot({path:shots+'/focus-primary-light.png',clip:{x:800,y:60,width:480,height:120}});
 await p.close();
 // 6. reduced motion: mesh paused, no laser animation
 p=await b.newPage({viewport:{width:1280,height:800},reducedMotion:'reduce'});await p.goto(base);await p.waitForTimeout(900);
 ok('reduced motion pauses mesh',await p.evaluate(()=>document.documentElement.dataset.portalMotion)==='paused');
 await p.close();
 // 7. no React re-render on pointer move: count frames of commits via React DevTools hook not available; measure DOM mutations instead
 p=await b.newPage({viewport:{width:1280,height:800}});await p.goto(base);await p.waitForTimeout(900);
 const muts=await p.evaluate(async()=>{let n=0;const o=new MutationObserver(l=>{n+=l.filter(m=>m.type!=='attributes'||!['data-frame','data-cursor-links','style','data-motion'].includes(m.attributeName)).length;});o.observe(document.getElementById('root'),{subtree:true,childList:true,attributes:true,characterData:true});return new Promise(r=>{let i=0;const t=setInterval(()=>{document.dispatchEvent(new PointerEvent('pointermove',{clientX:200+i*7,clientY:300+i*3,bubbles:true}));window.dispatchEvent(new PointerEvent('pointermove',{clientX:200+i*7,clientY:300+i*3}));if(++i>60){clearInterval(t);o.disconnect();r(n);}},16);});});
 ok('pointer movement causes no DOM/React updates',muts===0,String(muts));
 await p.close();
 await b.close();
 const failed=results.filter(r=>!r.pass);console.log(results.map(r=>(r.pass?'PASS ':'FAIL ')+r.name+(r.detail&&!r.pass?' · '+r.detail:'')).join('\n'));console.log(`${results.length-failed.length}/${results.length} passed`);
})();

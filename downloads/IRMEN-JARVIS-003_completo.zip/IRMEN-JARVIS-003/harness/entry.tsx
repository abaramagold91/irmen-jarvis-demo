import React from 'react';
import {createRoot} from 'react-dom/client';
import {AppShell} from '@/components/layout/app-shell';
import {CommercialFunnelWorkspace} from '@/modules/sales-funnel/components/commercial-funnel-workspace';
const params=new URLSearchParams(location.search);
const theme=params.get('theme')==='light'?'irmen-executive-light':'irmen-industrial-dark';
document.documentElement.dataset.theme=theme;document.documentElement.classList.toggle('dark',theme==='irmen-industrial-dark');
createRoot(document.getElementById('root')!).render(<AppShell headerContext={{userName:'Usuária Exemplo',email:'qa@example.invalid',company:'Empresa Exemplo',role:'gerencia',platformRole:'Gestão comercial'}} initialTheme={theme as any}><CommercialFunnelWorkspace/></AppShell>);

# Harness visual isolado

Renderiza os componentes reais do Portal (shell e Funil) fora do Next, com dados sintéticos e stubs. Não conecta a Supabase nem a nenhum serviço.

- `build.mjs <repo> <repo>/src <saida> <0|1>`: gera `index.html` com esbuild e Tailwind do próprio repositório.
- `stubs/`: substitui navegação, links, sessão, logout e server actions. `commercial-actions.ts` responde com as 8 oportunidades fictícias de `fixture.ts`.
- Parâmetros de URL: `?theme=light` e `&mode=data|loading|empty|error|denied|move-denied`.
- `shots.cjs`, `interact.cjs`, `ref.cjs`: capturas, as 44 provas interativas e capturas da referência (Playwright + Chromium). Servir a pasta de saída em `127.0.0.1:8770` e o protótipo em `127.0.0.1:8767`.

É ferramenta de verificação, não código do Portal.

const {chromium}=require('/opt/node22/lib/node_modules/playwright');
const out=process.argv[2];
(async()=>{
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--headless=new']});
 const report=[];
 for(const variant of (process.argv[3]||'before,after').split(','))for(const theme of ['dark','light'])for(const w of [1440,1280,820,390])for(const view of ['kanban','table']){
  const p=await b.newPage({viewport:{width:w,height:w<500?844:900}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));p.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await p.goto(`http://127.0.0.1:8770/out-${variant}/index.html?theme=${theme}`);
  await p.waitForTimeout(900);
  if(view==='table'){const t=p.getByRole('button',{name:/Tabela/});await t.first().click();await p.waitForTimeout(400);}
  const m=await p.evaluate(()=>({docW:document.documentElement.scrollWidth,vw:innerWidth,font:getComputedStyle(document.body).fontFamily.slice(0,40),cards:document.querySelectorAll('article,[aria-label^="Abrir oportunidade"]').length}));
  const f=`${out}/${variant}-${theme}-${w}-${view}.png`;await p.screenshot({path:f,fullPage:false});
  report.push({variant,theme,w,view,overflowX:m.docW>m.vw,docW:m.docW,font:m.font,cards:m.cards,errors:errs.slice(0,3)});
  await p.close();
 }
 console.log(JSON.stringify(report.filter(r=>r.overflowX||r.errors.length),null,1));
 console.log('total',report.length,'cards sample',report.map(r=>r.variant+r.view+':'+r.cards).slice(0,4).join(' '),'font',report.at(-1).font);
 await b.close();
})();

// Usage: node build.mjs <repoRoot> <srcDir> <outDir> <withJarvis:0|1>
import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const [repo, src, out, jarvis] = process.argv.slice(2);
const require = createRequire(path.join(repo, 'package.json'));
const esbuild = require('esbuild');
const H = path.dirname(new URL(import.meta.url).pathname);
fs.mkdirSync(out, {recursive: true});
const stub = f => path.join(H, 'stubs', f);
const map = {
  'next/navigation': stub('next-navigation.ts'),
  'next/link': stub('next-link.tsx'),
  '@/modules/auth/components/logout-button': stub('logout-button.tsx'),
  '@/modules/auth/controllers/auth-browser-events': stub('auth-browser-events.ts'),
  '@/app/actions/settings.actions': stub('settings-actions.ts'),
  '@/app/actions/commercial-workspace.actions': stub('commercial-actions.ts')
};
const realPresentation = path.join(src, 'modules/sales-funnel/read-models/commercial-funnel.presentation.ts');
const plugin = {name: 'harness', setup(b) {
  b.onResolve({filter: /.*/}, args => {
    if (map[args.path]) return {path: map[args.path]};
    if (args.path === '__REAL_PRESENTATION__') return {path: realPresentation};
    if (/commercial-funnel\.presentation$/.test(args.path) && !args.importer.endsWith('presentation-shim.ts')) return {path: stub('presentation-shim.ts')};
    if (args.path.startsWith('@/')) {
      const base = path.join(src, args.path.slice(2));
      for (const ext of ['', '.ts', '.tsx', '/index.ts', '/index.tsx']) if (fs.existsSync(base + ext) && fs.statSync(base + ext).isFile()) return {path: base + ext};
    }
    return undefined;
  });
  b.onLoad({filter: /\.css$/}, () => ({contents: '', loader: 'css'}));
}};
await esbuild.build({
  entryPoints: [path.join(H, 'entry.tsx')], bundle: true, outfile: path.join(out, 'app.js'), format: 'esm', jsx: 'automatic', target: 'es2020',
  nodePaths: [path.join(repo, 'node_modules')], plugins: [plugin], logLevel: 'error',
  define: {'process.env.NODE_ENV': '"production"', 'process.env': JSON.stringify({NEXT_PUBLIC_PORTAL_DISPLAY_NAME: 'Portal IRMEN', NEXT_PUBLIC_PORTAL_MARK: 'I', NEXT_PUBLIC_PORTAL_ENVIRONMENT_LABEL: 'Área de trabalho'})}
});
const css = [path.join(src, 'styles/globals.css'), path.join(src, 'components/design-system/design-system.css'), path.join(src, 'styles/portal-appearance.css')];
if (jarvis === '1') css.push(path.join(src, 'styles/jarvis-theme.css'));
let input = css.map(f => fs.readFileSync(f, 'utf8')).join('\n');
if (jarvis === '1') {
  const fonts = path.join(src, 'app/fonts');
  for (const f of fs.readdirSync(fonts).filter(f => f.endsWith('.woff2'))) fs.copyFileSync(path.join(fonts, f), path.join(out, f));
  const face = (fam, file, w) => `@font-face{font-family:'${fam}';src:url(./${file}) format('woff2');font-weight:${w};font-display:swap}`;
  input = [face('JvDisplay','chakra-petch-latin-500-normal.woff2',500),face('JvDisplay','chakra-petch-latin-600-normal.woff2',600),face('JvDisplay','chakra-petch-latin-700-normal.woff2',700),face('JvBody','ibm-plex-sans-latin-400-normal.woff2',400),face('JvBody','ibm-plex-sans-latin-500-normal.woff2',500),face('JvBody','ibm-plex-sans-latin-600-normal.woff2',600),face('JvMono','jetbrains-mono-latin-400-normal.woff2',400),face('JvMono','jetbrains-mono-latin-500-normal.woff2',500)].join('\n') + '\n:root{--font-display:JvDisplay;--font-body:JvBody;--font-mono:JvMono}\n' + input;
}
fs.writeFileSync(path.join(out, 'input.css'), input);
fs.writeFileSync(path.join(out, 'tailwind.config.cjs'), `const c=require(${JSON.stringify(path.join(repo,'node_modules/jiti'))})(__filename)(${JSON.stringify(path.join(repo,'tailwind.config.ts'))});module.exports={...(c.default||c),content:[${JSON.stringify(src + '/**/*.{ts,tsx}')}]};`);
execFileSync(path.join(repo, 'node_modules/.bin/tailwindcss'), ['-c', path.join(out, 'tailwind.config.cjs'), '-i', path.join(out, 'input.css'), '-o', path.join(out, 'app.css')], {stdio: 'inherit', cwd: repo});
fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DS-02.A harness</title><link rel="stylesheet" href="app.css"></head><body><div id="root"></div><script type="module" src="app.js"></script></body></html>');
console.log('built', out);

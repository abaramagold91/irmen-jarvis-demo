# Relatório · DS-02.A no Portal real

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026
**Estado:** VALIDADO TECNICAMENTE (harness isolado) · ACEITE HUMANO PENDENTE

## 1. Identificação

| Campo | Valor |
|---|---|
| Repositório | `abaramagold91/portal-irmen-v2` (privado) |
| Branch | `jarvis/ds-02a-design-system-shell-funil` |
| Commit inicial (base) | `8c34a2a09c19ae902a1041780fee9f752fe53140` (ponta de `codex/f7-015-runtime-hosted-ava`, conferida de novo hoje) |
| Commit final | `b4791ccb1fab5b7e802c87d05ac6441bc430b88e` |
| Pull request | Draft PR #1, base `codex/f7-015-runtime-hosted-ava`. Sem merge, sem deploy |
| Diff | 31 arquivos, +1.353 / −385 (`patch/diffstat.txt`). O código fica no PR #1; o patch não vai neste ZIP porque o link é público e o repositório é privado |
| Migrations | Nenhuma |
| Arquivos da Ava, runtime, worker, orçamento | Nenhum tocado |

## 2. O que mudou

### Tokens e fontes
- `src/styles/jarvis-theme.css` (novo): tokens `--jv-*` para Dark e Slate, e o remapeamento das três camadas existentes (`--ds-*`, `--ui-*`/`--tone-*` e as variáveis HSL do shadcn). Assim as telas ainda não migradas já herdam a paleta, sem mudar classes.
- `src/app/fonts.ts` e `src/app/fonts/` (novos): Chakra Petch, IBM Plex Sans e JetBrains Mono servidas localmente (`next/font/local`), com as licenças OFL.
- `src/app/layout.tsx`: carrega o tema e as fontes. O contrato de tema (cookie `portal_theme`, `data-theme` no SSR) não mudou.

### Componentes (`foundation.tsx`, `design-system.css`)
- `DesignButton`: variante `ghost` e tamanho `sm`; o principal ganhou o chanfro, o laser e o anel de foco.
- Novos: `DesignSegmented`, `DesignState` (carregando, vazio, erro, sem acesso), `DesignModalFrame`, `DesignDialog`, `useDesignToasts` e `DesignToasts`.
- `modal-focus.ts` (novo): foco preso, fundo inerte e retorno de foco, extraídos do `SidePanel`, que passou a usá-los.

### Shell global
- `navigation.ts` (novo): os mesmos links e o mesmo gating por capability, agora em grupos.
- `app-sidebar.tsx`: sidebar de 252px a partir de 1024px; abaixo disso, gaveta modal (`shell-drawer.tsx`).
- `app-header.tsx`: grupo e página atuais, chips de usuário e empresa, seletor de tema, sair. Saiu o card fictício "Notificações · Em desenvolvimento".
- `app-shell.tsx`: link "Pular para o conteúdo", malha neural global única atrás do shell.

### Funil (`modules/sales-funnel/components/`)
- Workspace: checa `opportunity.read` antes de listar; cabeçalho, KPIs com os **mesmos 4** indicadores, filtros, Funil/Tabela, estados e toast.
- Kanban e card: card no layout da referência; botão **Mover** com diálogo acessível (as 8 etapas mais perda), além do arrastar.
- Tabela: as duas sobreposições passaram a `DesignModalFrame`.

O mapa completo de funções preservadas está em `03_MATRIZ_DE_PRESERVACAO.md`.

## 3. Verificações

| Verificação | Resultado |
|---|---|
| `tsc --noEmit` | Verde |
| `npm run lint` (baseline por arquivo) | Verde |
| `next build` (env placeholder local) | Verde. `/sales-funnel`: 14 → 16,4 kB (First Load 137 → 139 kB); compartilhado igual (102 kB) |
| Testes `tsx` | Base 15 passam / 5 falham; branch 16 passam / as **mesmas** 5 falham (migrations ausentes no fonte e `server-only`). Detalhe em `evidencias/logs/testes-antes-depois.txt` |
| Teste novo | `ds-02a-shell-funnel.test.tsx`: rotas do menu, rota ativa, título, colunas, etapas automáticas, alvos do Mover |
| Provas interativas | 44/44 no harness isolado (`evidencias/logs/provas-interativas.txt`): teclado, foco, Esc, inércia do fundo, etapa 6 → conversão, perda, Pedido, detalhe, filtros, tabela, recusa do servidor, 4 estados nos 2 temas, gaveta, toque, cookie de tema, malha única, movimento reduzido, nenhuma atualização de DOM ao mover o ponteiro |
| Transbordamento | Sem rolagem horizontal de página em 1440, 1280, 820 e 390, nos dois temas |
| Visual | 50 capturas e 12 comparações lado a lado (`evidencias/`). A equivalência visual **não** foi declarada por build; o aceite é humano |

### Sobre o harness
Os componentes reais foram renderizados com esbuild e Tailwind, com `next/navigation`, `next/link`, as server actions e a sessão substituídos por stubs e **dados sintéticos** (8 oportunidades fictícias). Nenhuma chamada a Supabase, produção ou serviço externo. Nada foi executado no computador do Owner, e as portas 3001/3002 não foram usadas.

### Vercel
O repositório tem integração Git com a Vercel. O push da branch disparou **automaticamente** builds de prévia em `portal-irmen` e `portal-irmen-v3-demo`. As duas falharam, como já falham na base `8c34a2a` e em `a728f9a`. Nenhuma prévia ficou no ar, nenhum domínio ou configuração foi alterado, e eu não acionei a Vercel. O motivo da falha está nos logs da Vercel, que não acessei. Fica para o Codex conferir, de preferência antes da integração.

## 4. Limitações

1. Sem teste de ponta a ponta com sessão real e banco. A prova foi em harness isolado.
2. Abaixo de 820px a tabela do Funil continua rolando na horizontal dentro do próprio contêiner, como antes. O padrão "tabela vira cartões" entra no B1.
3. As fontes acrescentam cerca de 150 KB em woff2 (só a mono não é pré-carregada).
4. `PortalThemeLabel` e algumas regras antigas de CSS ficaram sem uso; não removi para não ampliar o diff.
5. Telas fora do bloco herdam a paleta pelos tokens, mas não foram redesenhadas nem comparadas.
6. D-DS1 não foi aplicado: o botão principal escuro mantém `#ef3f4f` (3,82:1). O anel de foco foi implementado.

## 5. Integração e recuperação (para o Codex)

**Integrar**
1. Conferir se `codex/f7-015-runtime-hosted-ava` ainda está em `8c34a2a`. Se avançou, trazer a base para a branch (merge, sem rebase de história publicada) ou gerar e aplicar o patch a partir do repositório:
   `git format-patch -1 b4791cc` e `git am 0001-*.patch`
2. Conflitos prováveis só em `app-sidebar.tsx` (o link AVA da F7-015 está preservado) e `layout.tsx`.
3. Rodar `npm run typecheck`, `npm run lint`, os testes e o build.
4. Conferir com sessão de teste no ambiente isolado: menu por perfil, Funil (arrastar, Mover, perda, conversão, Pedido), tabela, troca de tema, celular.
5. Só então pedir o aceite humano e decidir a publicação.

**Recuperar**
- Antes do merge: fechar o PR; a base não muda.
- Depois do merge: `git revert b4791cc` (um commit só, sem migration, sem dado novo). O cookie `portal_theme` continua compatível nos dois sentidos.

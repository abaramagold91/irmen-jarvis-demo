# DESIGN_SYSTEM_SPEC · Portal IRMEN (Jarvis)

**ID:** DS-01 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Fonte:** protótipo homologado `abaramagold91/irmen-jarvis-demo` @ `fb6416c` (ver `MANIFESTO_DE_VERSAO.md`)
**Tokens:** `tokens/tokens.css` e `tokens/tokens.json` (gerados por script a partir de `index.html`)
**Catálogo navegável:** https://abaramagold91.github.io/irmen-jarvis-demo/catalogo/

## Como ler este documento

Cada afirmação traz uma marca:

| Marca | Significado |
|---|---|
| **[FATO]** | Extraído dos arquivos publicados do protótipo, com seletor ou arquivo citado |
| **[PROPOSTA]** | Estado ou regra que faltava, desenhado no mesmo padrão visual; não homologado |
| **[AJUSTE]** | Correção de acessibilidade medida no protótipo; muda pouco o visual e pede aceite do Owner |
| **[INSPEÇÃO PENDENTE]** | Depende de ler o código real do Portal (`portal-irmen-v2`), que não foi acessado nesta etapa |
| **[DECISÃO PENDENTE]** | Escolha de negócio ou de custo, listada em `DECISIONS_REQUIRED.md` |

Este documento descreve o visual. Não comprova funcionamento, segurança nem prontidão de nenhum módulo do Portal real.

---

## 1. Princípios

1. **[FATO]** Dois temas: escuro (Jarvis, padrão) e Slate claro, trocados pelo atributo `data-theme` na raiz. Todos os componentes leem só variáveis CSS; nenhuma cor fixa em componente, exceto os quatro casos listados em 2.4.
2. **[FATO]** Superfícies de vidro sobre uma rede neural global: um único canvas fixo no fundo, nunca um por cartão.
3. **[FATO]** Vermelho da marca (`--brand`) para ação principal, item ativo e destaque. Ciano (`--arc`) para tecnologia: foco, seleção, Ava, rede neural.
4. **[FATO]** Chanfros como assinatura: botão principal, logo e cantoneiras HUD.
5. **[PROPOSTA]** Tokens e componentes ficam versionados no código do Portal. Só a configuração empresarial editável (nome, logo, cor de marca, textos legais) vem de fonte canônica já existente quando houver **[INSPEÇÃO PENDENTE]**. O design system inteiro não vai para o banco.

---

## 2. Tokens

### 2.1 Cores semânticas **[FATO]**

| Token | Escuro | Slate claro | Uso |
|---|---|---|---|
| `--bg` | `#06080c` | `#e6eaf0` | Fundo da página |
| `--bg-2` | `#0a0e14` | `#dde3ea` | Fundo de controles (input, botão padrão, segmentado) |
| `--panel` | `rgba(13,18,26,.78)` | `rgba(255,255,255,.86)` | Vidro de painéis e barras |
| `--panel-solid` | `#0d121a` | `#ffffff` | Diálogos, tooltips, cartões do Kanban |
| `--panel-2` | `rgba(20,27,38,.85)` | `rgba(244,247,250,.95)` | Gradiente da barra lateral, avatar |
| `--line` | `rgba(140,190,220,.13)` | `rgba(30,50,70,.12)` | Bordas e divisórias |
| `--line-2` | `rgba(140,190,220,.24)` | `rgba(30,50,70,.22)` | Bordas de controles |
| `--fg` | `#e8eef4` | `#0f1722` | Texto principal |
| `--fg-2` | `#a3b0bd` | `#3f4b58` | Texto secundário |
| `--fg-3` | `#8592a0` | `#5a6673` | Rótulos, apoio, eixos |
| `--brand` | `#ef3f4f` | `#d42a3a` | Ação principal, ativo, destaque |
| `--brand-ink` | `#ffffff` | (herda) | Texto sobre `--brand` |
| `--brand-soft` | `rgba(239,63,79,.14)` | `rgba(212,42,58,.10)` | Fundo de item ativo, ícone de KPI |
| `--arc` | `#3fd0ff` | `#0a7aa8` | Foco, seleção, Ava, links do sistema |
| `--arc-soft` / `--arc-glow` | `.12` / `.35` | `.10` / `.25` | Hover, brilho do orbe |
| `--good` | `#34c38f` | `#137a50` | Sucesso, aprovado |
| `--warn` | `#f2b84b` | `#94600a` | Pendente, atenção |
| `--crit` | `#ff6b7a` | `#c01f33` | Erro, atrasado |
| `--violet` | `#a594ff` | `#5b4bd6` | Barra de XP (gradiente com `--arc`) |
| `--c1`…`--c5` | `#ef3f4f #1aa3cf #c0821a #8a78f0 #22a06b` | `#d42a3a #0b84b8 #b7791f #6c5ce7 #16935f` | Séries de gráficos, nesta ordem |
| `--net` / `--net-2` | `63,208,255` / `239,63,79` | `10,122,168` / `212,42,58` | RGB da rede neural (normal / quente) |
| `--shadow` | `0 10px 40px rgba(0,0,0,.45)` | `0 8px 30px rgba(20,40,60,.10)` | Elevação |

Cada cor tem um `-soft` correspondente (`--good-soft`, `--warn-soft`, `--crit-soft`) para fundos de badge e alerta. A lista completa está em `tokens/tokens.css`.

### 2.2 Tipografia **[FATO]**

| Token | Família | Pesos carregados | Uso |
|---|---|---|---|
| `--f-display` | Chakra Petch | 500, 600, 700 | Títulos, eyebrows, cabeçalhos de tabela, valores de KPI, rótulos do radar |
| `--f-body` | IBM Plex Sans | 400, 500, 600 | Texto corrido, formulários |
| `--f-mono` | JetBrains Mono | 400, 500 | Códigos (OPP/OP/PED), valores em cartões, atalhos, horários |

| Papel | Especificação | Seletor |
|---|---|---|
| Título de tela | 700 · `clamp(22px, 2.4vw, 30px)` / 1.1 · `text-wrap: balance` | `.head h1` |
| Título do login | 700 · 26px / 1.15 | `.card h1` (login) |
| Título de painel | 600 · 13px · `letter-spacing .1em` · caixa alta | `.ph h3` |
| Eyebrow | 600 · 10.5px · `.18em` · caixa alta · `--arc` (login: `--brand`) | `.eyebrow` |
| Valor de KPI | 700 · `clamp(20px, 1.9vw, 26px)` · números tabulares | `.kpi .k-val` |
| Corpo | 400 · 14px / 1.45 | `body` |
| Apoio | 12px · `--fg-3` | `.li .s`, `.k-lbl` |
| Cabeçalho de tabela | 600 · 10.5px · `.14em` · caixa alta · `--fg-3` | `.tbl th` |

As fontes são servidas localmente (`vendor/fonts`, Fontsource 5.1.0, OFL 1.1), sem CDN.

### 2.3 Medidas, raios e chanfros **[FATO]**

| Item | Valor |
|---|---|
| Raio de painel | `--r: 10px` |
| Raio de controle | 8px (`.btn`, `.ibtn`, inputs, `.seg`) |
| Raio de diálogo, paleta e tour | 14px |
| Pílula | 999px |
| Chanfro do botão principal | 10px em dois cantos opostos (`clip-path`); 12px no login |
| Chanfro do logo | 22% em dois cantos opostos |
| Cantoneira HUD | 14px, borda 2px, opacidade .7, cor `--arc`; no login 16px, .75, cor `--brand` |
| Largura da barra lateral | `--side: 252px` |
| Espaçamentos | 16px entre blocos (`.grid`, `.view`); 10px em linhas e colunas (`.row`, `.col`); 8px entre fases; padding de painel 16px |
| Alturas de toque | 38px (`.btn`, `.nav a`, `.ibtn`), 30px (`.btn.sm`, `.seg button`), 42px (botões do login), 46px (inputs do login) |
| Largura máxima do conteúdo | 1680px (`.view`) |

### 2.4 Cores fixas fora dos tokens **[FATO]**

`#04121a` (texto do selo de nível), `#03131b` (texto do segmentado `arc` ativo), `rgba(3,6,10,.55)` (scrim) e `rgba(255,255,255,.45)` (feixe do laser). **[PROPOSTA]** Virar `--arc-ink`, `--scrim` e `--laser` na implementação.

---

## 3. Superfícies, camadas e ícones

**[FATO]**
- `.panel`: `--panel`, borda `--line`, `backdrop-filter: blur(10px)`, raio `--r`, padding 16px.
- `.panel.hud`: duas cantoneiras (superior esquerda e inferior direita) por `::before` e `::after`.
- `.brief` (faixa da Ava): gradiente `--arc-soft` → `--panel` e orbe de 42px.
- Barras (lateral e superior): desfoque de 14px.
- Brilho de fundo: dois gradientes radiais fixos (`--arc-soft` no topo direito, `--brand-soft` no rodapé esquerdo).

**Camadas (z-index) [FATO]:** rede neural e brilho 0 → shell 1 → barra superior 20 → faixa de safe-area 30 → tour 50 → menu móvel 55 → scrim e diálogos 60 → toasts 70.

**Ícones [FATO]:** desenhados em SVG em linha, 24×24, traço 1,7, pontas e junções arredondadas, `currentColor`, 18px por padrão. São 42 desenhos próprios em `data.js` (objeto `P`), sem biblioteca. **[PROPOSTA]** Na implementação, virar um componente `Icon` com a mesma geometria; se o Portal já tiver biblioteca de ícones, mapear um a um **[INSPEÇÃO PENDENTE]**.

---

## 4. Componentes

Para cada componente: o que existe **[FATO]**, o que falta **[PROPOSTA]** e o que corrigir **[AJUSTE]**. Os nomes de seletor são os do protótipo; os nomes de componente são sugestão para o Portal.

### 4.1 Botão (`Button`)
- **[FATO] Variantes:**
  - `.btn` (padrão: `--bg-2`, borda `--line-2`, hover com borda `--arc`);
  - `.btn.pri` (preenchido `--brand`, chanfro, laser);
  - `.btn.arc` (contorno ciano);
  - `.btn.ghost` (sem fundo);
  - `.btn.sm` (30px).
- **[FATO] Laser:** `::after` com gradiente de 100° (transparente → branco .45 → transparente) que atravessa o botão em 0,7 s no hover. No login, o laser também passa no foco por teclado.
- **[FATO] Carregando (login):** classe `.busy` + `disabled`, spinner de 16px no lugar da seta e rótulo trocado ("Entrando…").
- **[PROPOSTA] Desabilitado:** opacidade .5, `cursor: not-allowed`, sem laser.
- **[PROPOSTA] Carregando no sistema:** reutilizar o padrão do login em todos os botões que disparam escrita.
- **[AJUSTE] Foco:** o `clip-path` do botão chanfrado corta o contorno de foco; hoje o foco por teclado **não aparece** (verificado no catálogo). Proposta: anel de 3px em `--arc` desenhado por fora, com o mesmo chanfro (demonstração no catálogo, seção Botões).
- **[AJUSTE] Contraste:** texto branco sobre `--brand` escuro (`#ef3f4f`) dá **3,82:1**, abaixo de 4,5:1 para 13–14px. Proposta: token `--brand-fill: #de2f3f` só para fundos preenchidos no tema escuro (4,58:1), mantendo `--brand` para texto e ícones (5,24:1 sobre `--bg`) **[DECISÃO PENDENTE D-DS1]**.

### 4.2 Botão de ícone e segmentado
- **[FATO]** `.ibtn`: 38px; o ponto de notificação `.pip` usa `--brand`.
- **[FATO]** `.seg`: grupo com o botão ativo em `--brand` (ou em `--arc` na variante `.seg.arc`).
- **[PROPOSTA]** `aria-pressed` no item ativo do segmentado e `aria-label` obrigatório em todo `.ibtn`.

### 4.3 Badges, chips e contadores
- **[FATO]** `.pill` com ponto, nas variantes good, warn, crit, arc, brand, neutral e `.nodot`.
- **[FATO]** `.chip` alternável, ativo em `--arc`.
- **[FATO]** Contador `.cnt` (vermelho, ou ciano com `.arc`) e selo `.tagnew` ("NOVO") no menu.
- **[FATO]** `.sample` ("dado de exemplo") e `.delta` com as variantes `.up` e `.down`.
- **[PROPOSTA]** Status nunca só por cor: a pílula sempre leva texto (já é assim no protótipo) e `.delta` leva seta ▲/▼.
- **[PROPOSTA]** No Portal real, o selo "dado de exemplo" **não pode aparecer em produção**; sem dado, usar o estado "métrica indisponível" (4.14).

### 4.4 KPI (`KpiTile`)
- **[FATO]** Anatomia: ícone 30px (`--brand-soft` ou `--arc-soft`), rótulo, valor, minigráfico de 30px opcional, rodapé com variação. Altura mínima 132px.
- **[PROPOSTA]** Estados:
  - carregando: esqueleto;
  - sem fonte: "métrica indisponível", nunca zero fabricado;
  - erro: tentar de novo.
  Cada KPI aponta para o seu contrato de métrica (ver BI-01 em `IMPLEMENTATION_BLOCKS.md`).

### 4.5 Tabela (`DataTable`)
- **[FATO]**
  - Cabeçalho em display de 10,5px, caixa alta.
  - Linhas com divisória `--line` e hover em `--arc-soft`.
  - Números alinhados à direita e tabulares.
  - Largura mínima de 560px com rolagem no próprio contêiner.
- **[FATO] Mobile (≤ 640px):** cada linha vira cartão; `mobile.js` copia o texto do cabeçalho para `data-label` e o CSS mostra o rótulo à esquerda.
- **[PROPOSTA]**
  - Ordenação com `aria-sort`.
  - Paginação ou carregamento incremental, com o tamanho de página definido em BI-01/B.
  - Linha selecionável por teclado.
  - Estados vazio, carregando e erro dentro da área da tabela.

### 4.6 Lista com severidade
- **[FATO]** `.li` com barra lateral `.sev` (crit, warn, good, arc), título, apoio e coluna final.

### 4.7 Formulário
- **[FATO] Sistema:** `.field` (rótulo 12px, input/select de 38px, `--bg-2`, borda `--line-2`) e `range` com `accent-color: --brand`.
- **[FATO] Login (padrão mais completo, recomendado como base):**
  - ícone à esquerda dentro do campo (`.ctl`), altura de 46px;
  - foco com borda `--arc` + anel de 3px `--arc-soft`;
  - **erro** com `aria-invalid="true"`, borda e anel `--crit` e mensagem `.err` ligada por `aria-describedby`;
  - aviso de Caps Lock;
  - mostrar/ocultar senha com `aria-pressed`;
  - medidor de força com regras;
  - código de 6 dígitos com avanço automático e colar.
- **[FATO] Alertas:** `.alert` nas variantes crit, warn e good, com `role="alert"`.
- **[PROPOSTA]**
  - Validar ao sair do campo e no envio.
  - Levar o foco ao primeiro campo inválido (o login já faz isso).
  - Não limpar o que foi digitado em caso de erro de servidor.
  - Campos obrigatórios indicados no rótulo.

### 4.8 Navegação (shell)
- **[FATO]**
  - Barra lateral com grupos (`h6`), itens de 38px e item ativo com gradiente `--brand-soft` + barra de 3px `--brand` com brilho.
  - Barra superior com trilha (grupo em `--brand` + título), barra da Ava (pílula com orbe e `Ctrl K`), seletor de papel, tema e notificações.
  - Cartão do usuário com nível e XP no rodapé da barra lateral.
- **[FATO] Mobile:** a barra lateral vira gaveta (≤ 860px) e a barra superior fica em duas linhas.
- **[INSPEÇÃO PENDENTE]** O seletor "Ver o portal como" é recurso de demonstração. No Portal real, o menu deve refletir as capabilities do usuário vindas do servidor. Não pode existir troca de papel pelo cliente.
- **[AJUSTE]** No protótipo, abrir uma rota pelo endereço (`#mesa`) ignora o filtro de papel. No Portal, a rota precisa checar a autorização no servidor e mostrar "acesso negado" (4.14).

### 4.9 Fases e Kanban
- **[FATO]**
  - Faixa de 8 fases (`.phase`, com as variantes `.hot` e `.win`).
  - Colunas `.kcol` e cartões `.kcard`; destino de soltura `.drop`.
  - Arrastar entre as fases 1 a 6 funciona; soltar em Formalização ou Faturada é bloqueado com aviso.
- **[FATO] Toque:** tocar no cartão abre "Mover para…", que usa a mesma regra do arrastar.
- **[PROPOSTA]**
  - Mover por teclado (o mesmo diálogo "Mover para…" também no desktop).
  - Anúncio em `aria-live` da mudança.
  - Desfazer por 5 s quando a regra permitir.
  - A transição é sempre validada no servidor.

### 4.10 Conversas
- **[FATO]**
  - Lista de conversas, mensagens (`.msg`, `.msg.me`, `.msg.note` para nota interna), compositor e sugestões da Ava (`.suggest`, pílulas tracejadas em `--arc`).
  - Contexto do negócio na coluna da direita (só acima de 1280px).
- **[PROPOSTA]**
  - Estado de envio (enviando, enviado, falhou com reenviar).
  - Distinguir visualmente o canal (oficial, interno).
  - Nota interna sempre identificada como não enviada ao cliente.

### 4.11 Gráficos (`Chart`)
- **[FATO]** ECharts 5.5.0 com tema montado pela função `base()` de `app.js`:
  - paleta `--c1`…`--c5` em ordem;
  - texto em IBM Plex Sans `--fg-2`;
  - tooltip em `--panel-solid` com borda `--line-2`;
  - ponteiro de eixo em sombra `--arc-soft`;
  - legenda no topo à direita, ícone retangular arredondado de 10px;
  - eixos e grade em `--line` e rótulos em `--fg-3` 11px;
  - barras com raio de 4px no topo;
  - animação de 700ms.
- **[FATO]**
  - Ao trocar o tema, os gráficos são refeitos.
  - Clicar numa série abre o detalhamento.
  - Cada gráfico do BI tem um bloco "Contrato da métrica" (`<details class="contract">`).
- **[FATO] Mobile:** a legenda da rosca vai para baixo e os rótulos do funil diminuem quando a largura do gráfico fica abaixo de 420px.
- **[PROPOSTA]**
  - Tabela alternativa acessível para cada gráfico (botão "ver como tabela").
  - Animação 0 com redução de movimento.
  - Formatação pt-BR (R$, milhar com ponto).
  - Totais do gráfico conferidos com a lista detalhada.
- **[INSPEÇÃO PENDENTE]** Reutilizar a biblioteca de gráficos já usada no Portal; o requisito é o tema por tokens, não o ECharts em si.

### 4.12 Diálogo, paleta, toast e tour
- **[FATO]**
  - `.dlg`: `--panel-solid`, raio 14px, padding 20px, sobre `.scrim` com desfoque de 4px.
  - `.pal`: paleta `Ctrl+K` com borda `--arc-glow`.
  - `.toast`: fixo no topo à direita, borda esquerda `--good` (ou `--arc` para XP).
  - `.tour`: faixa inferior com borda e brilho `--arc`.
  - `Esc` fecha.
- **[AJUSTE]** Prender o foco dentro do diálogo, devolver o foco ao elemento de origem ao fechar e marcar o fundo como inerte.
- **[PROPOSTA]**
  - Toast de erro (borda `--crit`) com ação.
  - Toasts anunciados por `aria-live="polite"` (erro em `assertive`).

### 4.13 Metas e XP
- **[FATO]** `.challenge`, `.badge` (com a variante `.locked`), `.league`, barra de XP em gradiente `--arc` → `--violet` e selo de nível `.lvl`.
- **[DECISÃO PENDENTE]** As regras de XP, metas e desafios precisam de contrato aprovado; os componentes são só visuais.

### 4.14 Estados de tela

| Estado | Situação | Desenho |
|---|---|---|
| Vazio | **[FATO]** `.empty` | Borda tracejada, texto `--fg-3`, sugestão de próxima ação |
| Carregando | **[PROPOSTA]** | Esqueleto no formato final, só após 100ms sem resposta; com redução de movimento, sem brilho animado |
| Erro | **[PROPOSTA]** | Ícone em `--crit-soft`, título claro, "nada foi alterado" quando for verdade, referência curta para o suporte, "Tentar de novo" e "Abrir chamado" |
| Acesso negado | **[PROPOSTA]** | Ícone de cadeado em `--warn-soft`; diz que o perfil não inclui a área, sem revelar dados; "Voltar ao painel" e "Solicitar acesso" |
| Validação | **[FATO]** (login) | Ver 4.7 |
| Métrica indisponível | **[PROPOSTA]** | Diz qual fonte falta; não mostra número |
| Sucesso | **[FATO]** (login) | Selo `--good-soft` com ✓ e texto da consequência |

Todos estão no catálogo, seção Estados.

### 4.15 Login
- **[FATO]**
  - Composição em duas colunas: apresentação com radar, quatro cartões e rodapé de confiança à esquerda; cartão de acesso à direita.
  - Destaques em `--brand`; rede neural, orbe, radar e foco de campo em `--arc`.
  - Os textos aprovados estão em `HOMOLOGACAO.md` (incluído nesta pasta), seção 3.2.
  - **Não transportar** o texto de rodapé "Conexão criptografada de ponta a ponta" para o Portal: é afirmação de segurança sem prova. Usar algo verificável (por exemplo, "Conexão protegida por HTTPS") ou retirar.
  - Radar: feixe de 6s; cada nó acende em `--brand` enquanto o feixe passa.

---

## 5. Rede neural e movimento **[FATO]**

| Item | Regra |
|---|---|
| Canvas | Um só, `position: fixed`, `pointer-events: none`, z 0 |
| Densidade | `min(110, área/16000)` pontos; DPR máximo 2 |
| Pontos quentes | 8% dos pontos em `--net-2` (vermelho); os demais em `--net` |
| Ligações | Até 130px, opacidade até .22, traço .7 |
| Ponteiro | Repulsão em raio de ~148px; linhas ao ponteiro até 170px |
| Desempenho | Pausa com a aba oculta (`visibilitychange`); recria pontos ao redimensionar |
| Redução de movimento | Um quadro estático; sem animação de pontos |
| Tema | `recolor()` relê `--net` e `--net-2` ao trocar o tema |

**[PROPOSTA] Para o Portal:**
- Pausar também quando a janela perde o foco por muito tempo.
- Limitar a 30 fps em dispositivos fracos.
- Medir o custo (meta INP ≤ 200ms no percentil 75, conforme o plano do projeto) antes de aceitar.

**Outras animações [FATO]:**
- laser 0,7s;
- orbe 3,2s;
- toast 0,25s;
- entrada de vista no login 0,35s;
- radar do login (anéis de 14s e 9s, feixe de 6s).

Com `prefers-reduced-motion: reduce`, tudo é desligado.

---

## 6. Responsivo **[FATO]**

| Faixa | Comportamento |
|---|---|
| ≤ 1280px | KPIs de 6 colunas viram 3; o Inbox esconde o contexto; em telas de toque, a página fica travada na horizontal |
| ≤ 1024px | Grades de 3 e 4 colunas viram 2 |
| ≤ 860px | Gaveta de menu; barra superior em duas linhas; grades empilham (KPIs em 2); fases, Kanban, organizações e conversas viram carrosséis com encaixe e indicadores; Kanban por toque com "Mover para…" |
| ≤ 640px | Tabelas viram cartões; coluna do Kanban com 86% da largura |
| ≤ 420px | KPIs em 1 coluna |
| Login | ≤ 1380px reduz o radar e os títulos dos cartões; ≤ 1100px o radar some; ≤ 900px fica em uma coluna; entre 641 e 900px os cartões ficam em 4 colunas |

**Regra de rolagem [FATO]:** `html { overflow-x: hidden }` + `body { overflow-x: clip }`. Esconder nas duas tags transforma o `body` em contêiner de rolagem e quebra a página. A rolagem lateral só existe dentro dos carrosséis (`scroll-snap`).

Verificação já feita no protótipo:
- 16 telas × 4 larguras de desktop × 2 temas idênticas antes e depois da camada mobile;
- sem rolagem lateral no celular;
- login em 5 tamanhos × 2 temas.

O relatório está em `documentacao/RELATORIO-DE-VERIFICACAO.md` e `AJUSTE-MOBILE.md`.

---

## 7. Acessibilidade: medições e ajustes

Contraste medido sobre `--bg` (WCAG 2.x; texto pequeno precisa de 4,5:1 e elemento de interface, de 3:1):

| Par | Escuro | Claro | Situação |
|---|---|---|---|
| `--fg` / `--bg` | 17,15 | 14,92 | ok |
| `--fg-2` / `--bg` | 9,07 | 7,37 | ok |
| `--fg-3` / `--bg` | 6,31 | 4,85 | ok (claro sobre `--bg-2`: 4,54, no limite) |
| `--brand` / `--bg` | 5,24 | **4,15** | claro abaixo de 4,5 para texto pequeno |
| `--arc` / `--bg` | 11,15 | **3,99** | claro abaixo de 4,5 para texto pequeno (links, eyebrow) |
| branco / `--brand` (botão) | **3,82** | 5,01 | escuro abaixo de 4,5 |
| `--good`, `--warn`, `--crit` / painel | 8,4 / 10,5 / 6,8 | 5,4 / 5,3 / 6,0 | ok |

**Ajustes propostos** (preservam a identidade; pedem aceite do Owner em **D-DS1**). As cores homologada e proposta aparecem lado a lado em `DECISIONS_REQUIRED.md` (D-DS1). A decisão não bloqueia os blocos: no DS-02.A o fundo do botão é o token único `--jv-brand-fill`, e o item 1 (foco) já está implementado.

1. **Foco visível em todos os controles:** anel `--arc` de 2px com afastamento de 2px. Nos chanfrados, anel externo com o mesmo chanfro (catálogo, Botões).
2. **Botão principal no escuro:** fundo `--brand-fill: #de2f3f` (4,58:1 com branco).
3. **Texto pequeno no claro:** usar `--brand-text: #c8283a` (4,55:1) e `--arc-text: #08709a` (4,58:1) quando o texto for menor que 18px e estiver direto sobre `--bg`. Sobre painel branco, os tokens atuais já passam (5,01 e 4,81).
4. **Diálogos:** prender o foco, devolvê-lo ao fechar e marcar o fundo como inerte.
5. **Teclado:** todo arrastar tem alternativa por teclado ("Mover para…"); a paleta `Ctrl+K` é navegável por setas; `Esc` fecha sobreposições.
6. **Toque:** alvos de no mínimo 38px (o protótipo já cumpre). Na implementação, recomenda-se 44px em telas de toque para ações frequentes.
7. **Leitores de tela:** `aria-live` para toasts e movimentações; tabela alternativa nos gráficos; `aria-current="page"` no item de menu ativo; `aria-busy` nos esqueletos.
8. **Transbordamento:** corrigir a sobra de 24px no painel da Diretoria em 1440px (achado do relatório de verificação). Manter a regra de rolagem da seção 6.
9. **Redução de movimento:** manter o comportamento atual (quadro estático, sem transições).

---

## 8. O que este documento não cobre

- Comportamento, dados, permissões e contratos do Portal real: ver `FUNCTIONAL_GAP_MATRIX.md` e `IMPLEMENTATION_BLOCKS.md`.
- Mapeamento para os componentes que já existem no Portal **[INSPEÇÃO PENDENTE]**: o primeiro passo do bloco A é localizar tokens, componentes e o design-lab (porta 3002) no código real e comparar com esta especificação antes de escrever código.

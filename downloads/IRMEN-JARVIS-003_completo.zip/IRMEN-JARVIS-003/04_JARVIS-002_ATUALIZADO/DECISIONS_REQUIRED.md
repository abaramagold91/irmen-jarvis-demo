# DECISIONS_REQUIRED · Decisões novas do Owner

**Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026
**Revisão:** IRMEN-JARVIS-003 (22/10/2026). D-AVA1 e D-AVA3 passaram a decididas; D-AVA2 foi reescrita; D-DS1 deixou de bloquear. Ficam **16 decisões abertas**.

Aqui só entram regras ou custos **realmente novos**: o que o protótipo sugere e que ainda não tem contrato, decisão no CTX ou regra vigente. O que já está decidido no CTX (SLA, códigos, perda, filiais, escopo do piloto, comissões fora, etc.) não é reaberto.

Cada decisão traz uma recomendação. Sem decisão, vale o padrão indicado, que é sempre o mais conservador.

| ID | Pergunta | Recomendação | Padrão sem decisão | Bloqueia |
|---|---|---|---|---|
| D-DS1 | Aceitar os ajustes de contraste no visual homologado? (comparação lado a lado em `../evidencias/comparacoes/` e na seção D-DS1 abaixo) | Sim | Visual homologado sem ajuste; só o anel de foco (já implementado no DS-02.A) | Nada. No DS-02.A a cor de fundo do botão é um token único (`--jv-brand-fill`); aceitar muda uma linha |
| D-CRM1 | Renomear "Clientes" para "Organizações & Contatos" e ter contato como cadastro próprio? | Renomear já; contato próprio só se o modelo atual não tiver | Mantém "Clientes" | B1 (parcial) |
| D-SIM1 | O vendedor vê a comparação entre instituições no simulador? | Não; só a Mesa | Não mostrar | B2 (parcial) |
| D-BI1 | Criar taxonomia de motivos de perda, se não existir? | Sim, lista curta e fechada | Indicador "Por que perdemos" fica como lacuna | C2 (um painel) |
| D-AVA2 | Voz: qual serviço de transcrição, com qual custo, retenção e privacidade? É um **serviço novo**, fora dos limites já aprovados | Avaliar provedor, custo e onde o áudio é processado antes de qualquer código; não presumir que é local ou gratuito por rodar "no navegador" | Voz desligada | D3 (voz) |
| D-AVA4 | Quais ações de escrita (N2) a Ava pode propor no piloto? | Criar tarefa e registrar nota | Só leitura e rascunho | D3 |
| D-TAR1 | Criar módulo de Tarefas ou estender as próximas ações existentes? | Decidir depois da inspeção; preferir estender | Sem tarefas novas | E1 |
| D-NOT1 | Quais eventos geram notificação e por quais canais? | SLA perto de estourar, documento pendente, movimentação na minha carteira; só no portal | Sem notificações novas | E1 |
| D-SUP1 | Quem atende o suporte interno, com qual SLA e quais categorias? | Administração; 8 horas úteis; Acesso, Sistema, Dúvida | Módulo não implementado | E2 |
| D-CONV1 | Quem vê quais conversas? | Dono da carteira + gestor com capability; Mesa só nas suas operações | Mantém a regra atual do chat, se existir | E3 |
| D-WA1 | Provedor oficial do WhatsApp e orçamento | Avaliar com o documento F1; a implementação só começa depois do plano F1 e desta decisão | Sem integração | F1 e qualquer envio |
| D-WA2 | Consentimento e textos de template | Opt-in registrado; templates aprovados pelo Owner | Sem envio ativo | F1 |
| D-WA3 | Conexão não oficial (QR) | Manter desligada | Desligada | — |
| D-GAM1 | Fórmula de XP | Só por resultado confirmado; nada ligado à aprovação de crédito | Sem XP | F2 |
| D-GAM2 | Cadastro de metas (quem cria, vigência, granularidade) | Gerência cria por mês e por vendedor; Diretoria aprova | Indicador de meta como lacuna | C2 (meta), F2 |
| D-GAM3 | Visibilidade do ranking | Por equipe; liga só entre gerências | Sem ranking | F2 |

## Decididas (não reabrir)

| ID | Decisão | Fonte |
|---|---|---|
| D-AVA1 | Limites aprovados da Ava: US$ 0,10 por chamada; US$ 1 por janela de 24 horas; US$ 10 por mês; até 50 chamadas em 24 horas e 500 por mês; modelo existente; até 4.000 tokens de saída; zero retentativas automáticas; execução serial global; alerta em 80% e bloqueio em 100%. | Comando IRMEN-JARVIS-003. Não autoriza voz nem outro recurso pago novo. |
| D-AVA3 | Concorrência: execução serial global, zero retentativas automáticas. A proposta anterior de 2 retentativas foi retirada. | Comando IRMEN-JARVIS-003 |
| AVA hospedada | A prova hospedada da Ava passou na F7-015. A **ativação contínua** continua pendente e é do Codex. | Comando IRMEN-JARVIS-003 |

---

## Detalhes

### D-DS1 · Ajustes de acessibilidade no visual homologado
**Por que é decisão:** muda levemente cores aprovadas.
**Situação no DS-02.A:** o anel de foco (item 3) já está implementado, porque não muda cor aprovada. Os itens 1 e 2 seguem com as cores homologadas; cada um é um token único e a troca não bloqueia nenhum bloco.

| Par | Homologado | Proposta | Contraste (homologado → proposta) |
|---|---|---|---|
| Fundo do botão principal, escuro | `#ef3f4f` | `#de2f3f` | 3,82 → 4,58:1 com branco |
| Texto pequeno vermelho sobre o fundo, claro | `#d42a3a` | `#c8283a` | 4,15 → 4,55:1 |
| Texto pequeno ciano sobre o fundo, claro | `#0b84b8` | `#08709a` | 3,99 → 4,58:1 |

**O que muda:**
1. Botão principal no tema escuro: fundo `#de2f3f` em vez de `#ef3f4f`. O contraste com o texto branco sobe de 3,82 para 4,58:1, e a diferença é quase imperceptível.
2. Texto pequeno direto sobre o fundo no tema claro: vermelho `#c8283a` (4,55:1) e ciano `#08709a` (4,58:1). Sobre os painéis brancos, nada muda.
3. Anel de foco visível nos botões chanfrados. Hoje o foco por teclado não aparece; a mudança só se vê ao navegar pelo teclado.

**Demonstração:** catálogo, seções Botões e Tokens.

### D-AVA2 · Voz
Transcrever voz é um serviço novo, com custo, retenção e tratamento de áudio próprios. Transcrição "no navegador" pode enviar o áudio a um serviço do fabricante do navegador, então não é, por si só, local nem gratuita. Os limites aprovados em D-AVA1 cobrem só o modelo existente da Ava e não autorizam voz. Até a decisão, a voz fica desligada.

### D-SIM1 · Comparação entre instituições
O protótipo mostra ao vendedor uma comparação de parcelas entre instituições. Como o vendedor não decide banco, essa tela pode induzir expectativa. A recomendação é deixá-la só na Mesa. Se o Owner quiser ao vendedor, ela vira apenas informativa, com o aviso de que a Mesa decide.

### D-GAM1 · XP
Pontos ligados à aprovação de crédito criam incentivo errado. A proposta é pontuar só eventos confirmados e auditáveis (PED faturado, ficha sem retrabalho, tarefa concluída no prazo), com estorno quando o evento é cancelado.

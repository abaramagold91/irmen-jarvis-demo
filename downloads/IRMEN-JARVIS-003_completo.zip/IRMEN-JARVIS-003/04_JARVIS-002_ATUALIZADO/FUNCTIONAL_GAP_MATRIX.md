# FUNCTIONAL_GAP_MATRIX · Protótipo Jarvis × Portal IRMEN

**ID:** PLAN-01 · **Comando:** IRMEN-JARVIS-002 · **Data:** 22/10/2026

## Fontes e limites

| Fonte | O que dá | Limite |
|---|---|---|
| Protótipo homologado `irmen-jarvis-demo` @ `fb6416c` | Telas, fluxos e comportamento visual | Dados fixos, sem backend; não prova nada do Portal |
| "Portal IRMEN contexto e plano de conclusão" v1, 22/10/2026 (citado como **CTX**) | Contratos conhecidos, estado por módulo, IDs do plano (FUN, SEC, DOC, AVA, DS, BI, DASH…) | O próprio documento diz que não certifica código nem inventaria tudo |
| Código real `portal-irmen-v2` | — | **Não acessado nesta etapa.** Baseline de referência: branch `codex/f7-014-controlled-release`, commit `92c88f9d…3456`, que pode mudar com a F7-015 |

As marcas são as mesmas do DESIGN_SYSTEM_SPEC: **[FATO]** (protótipo ou CTX, com fonte), **[PROPOSTA]**, **[INSPEÇÃO PENDENTE]** e **[DECISÃO PENDENTE]**.

**Classificação:**
- **Existente:** já há função real; muda pouco ou nada.
- **Melhoria visual:** função real mantida, interface nova.
- **Extensão:** função real ganha capacidade nova.
- **Módulo novo:** não existe no Portal segundo as fontes.

**Regras gerais desta matriz:**
1. Nenhuma função real é removida por não aparecer no protótipo. Se o Portal tem algo que o protótipo não mostra, a função fica e ganha o visual novo.
2. O protótipo não comprova funcionamento, segurança nem prontidão de módulo. "Pronto" no Mapa do produto do protótipo é rótulo de desenho, não estado do Portal.
3. Nenhuma tabela nova é prescrita aqui. Onde o protótipo sugere dado novo, a matriz pede comparação com o schema existente **antes** de qualquer migração.
4. O estado inicial de cada módulo segue o CTX §4: publicado, demonstrado, pendente de prova, incompleto ou futuro.

---

## Quadro resumo

| # | Item | Classificação | Bloco | IDs do plano (CTX) | Inspeção do código real | Decisão nova |
|---|---|---|---|---|---|---|
| 01 | Shell, navegação e tema | Melhoria visual | A | DS01 | Sim | D-DS1 |
| 02 | Login, recuperação e primeiro acesso | Melhoria visual | A | SEC01, SEC03, USR01 | Sim | — |
| 03 | Painel (dashboard por perfil) | Melhoria visual + extensão | C | DASH01, BI01 | Sim | — |
| 04 | Clientes → Organizações & Contatos | Melhoria visual + extensão | B | FUN02 | Sim | D-CRM1 |
| 05 | Documentos | Existente + melhoria visual | B | DOC01 | Sim | — |
| 06 | Funil & Kanban | Melhoria visual | B | FUN03 | Sim | — |
| 07 | Operações (OPP → OP → PED) | Melhoria visual | B | FUN04 | Sim | — |
| 08 | Simulador / Nova Operação | Melhoria visual + extensão | B | FUN05 | Sim | D-SIM1 |
| 09 | Pedidos e PDF | Existente + melhoria visual | B | FUN05 | Sim | — |
| 10 | Mesa de Crédito | Melhoria visual + extensão | B | FUN04, SLA | Sim | — |
| 11 | Usuários & Permissões | Melhoria visual | B | USR01, SEC02 | Sim | — |
| 12 | Unidades e filiais (Configurações) | Melhoria visual | B | FUN06 | Sim | — |
| 13 | Relatórios & BI | Extensão | C | BI01, BI02 | Sim | D-BI1 |
| 14 | Ava | Extensão | D | AVA01, AVA02 | Sim (Codex: ativação contínua) | D-AVA2, D-AVA4 |
| 15 | Tarefas & Agenda | Módulo novo ou extensão | E | — | Sim | D-TAR1 |
| 16 | Notificações | Extensão ou módulo novo | E | — | Sim | D-NOT1 |
| 17 | Suporte interno | Módulo novo | E | — | Sim | D-SUP1 |
| 18 | Conversas (Inbox) | Extensão (a confirmar) | E | — | Sim | D-CONV1 |
| 19 | WhatsApp | Módulo novo | F | — | Sim | D-WA1…3 |
| 20 | Metas, XP e desafios | Módulo novo | F | FUT01 (metas novas dependem de contrato) | Sim | D-GAM1…3 |
| 21 | Configurações gerais e white label | Extensão | B | — | Sim | — |
| 22 | Mapa do produto (tela do protótipo) | Não implementar | — | — | — | — |
| 23 | Localização | Existente (acesso externo) | — | CTX §4 | Sim | — |
| — | Comissões, estoque, PDI | Fora do escopo | — | FUT01 | — | — |

---

## Detalhamento

### 01 · Shell, navegação e tema
- **Classificação:** melhoria visual.
- **Resultado esperado:** barra lateral por grupos, barra superior com trilha, entrada da Ava, notificações, tema e usuário; dois temas sem flash na carga; gaveta no celular; rede neural global única.
- **Fonte disponível:**
  - **[FATO]** protótipo: `index.html` (shell), `app.js` (`renderSide`, `renderTop`, `go`), `mobile.css`/`mobile.js`;
  - **[FATO]** CTX §9 pede tema global persistido sem flash e contraste acessível.
- **Inspeção pendente:**
  - onde o Portal monta o layout autenticado;
  - como o menu decide os itens hoje;
  - se já existe preferência de tema;
  - o design-lab da porta 3002 (CTX §9).
- **Dados, regras, capabilities:**
  - itens de menu filtrados pelas **capabilities do usuário vindas do servidor**;
  - o seletor "Ver como" do protótipo **não** vai para o Portal;
  - Filiais só dentro de Configurações (CTX §4);
  - o contador do menu só aparece se houver fonte canônica.
- **Critério de aceite:**
  - todas as rotas atuais acessíveis pelo menu novo, sem perda;
  - dois temas em todas as telas;
  - sem rolagem lateral em 390px;
  - foco visível;
  - rota sem autorização mostra "acesso negado" e o servidor nega os dados.
- **Decisão nova:** D-DS1 (ajustes de contraste e foco).

### 02 · Login, recuperação e primeiro acesso
- **Classificação:** melhoria visual (a autenticação é do Portal).
- **Resultado esperado:** a tela homologada (textos em `HOMOLOGACAO.md` §3.2) ligada ao fluxo real.
- **Fonte disponível:**
  - **[FATO]** `login/index.html`;
  - **[FATO]** CTX §4: usuário por solicitação ou convite, aprovação pelo frontend autorizado, recuperação; convite real entregue por SMTP Titan.
- **Inspeção pendente:**
  - rota e componente de login atuais;
  - fluxo de recuperação (link ou código; o protótipo mostra código de 6 dígitos);
  - tela de solicitação de acesso existente;
  - política de senha.
- **Regras:**
  - mensagens que não revelam se o e-mail existe;
  - limite de tentativas no servidor;
  - token de recuperação sem replay e limpo da URL (SEC01/SEC03);
  - "Solicitar primeiro acesso" abre a tela de solicitação **já existente**.
- **Critério de aceite:**
  - texto e visual iguais à homologação;
  - recuperação real funcionando com um usuário legítimo;
  - sem enumeração de contas;
  - bloqueio e revogação testados conforme SEC03.
- **Decisão nova:** nenhuma.
- **Observação:** se o fluxo real usa link em vez de código, a tela de código é substituída pela tela do link no mesmo visual, sem mudar o fluxo de segurança por causa do mock.

### 03 · Painel (dashboard por perfil)
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** "o que precisa de ação hoje" com acesso aos registros, KPIs por perfil e evolução do faturamento, tudo de fontes canônicas no escopo do usuário (CTX §8).
- **Fonte disponível:**
  - **[FATO]** protótipo `#painel` (briefing da Ava, atalhos, 6 KPIs, "Precisa de ação hoje", medidor, evolução, linha do tempo);
  - **[FATO]** CTX: DASH01 incompleto segundo o Owner.
- **Inspeção pendente:** o dashboard atual, as fontes de cada número e a fundação BI existente.
- **Dados:** cada KPI precisa de contrato de métrica (BI-01) antes de virar tela. Sem fonte: estado "métrica indisponível", nunca zero.
- **Critério de aceite:**
  - cada número confere com a lista que o compõe;
  - mesmo escopo nos agregados e no detalhe;
  - vazio honesto;
  - medidor de meta só se existir cadastro de metas.
- **Decisão nova:** nenhuma além de BI.

### 04 · Clientes → Organizações & Contatos
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** lista com busca e filtro de pendência; ficha 360º com dados, contatos, checklist documental, negócios e linha do tempo.
- **Fonte disponível:**
  - **[FATO]** protótipo `#crm`;
  - **[FATO]** CTX §4 "Clientes e vínculos" (cadastro, edição autorizada, documentos e vínculos sem duplicação).
- **Inspeção pendente:**
  - modelo atual de cliente e contato (existe contato separado?);
  - deduplicação por CNPJ;
  - origem do checklist documental.
- **Regras:**
  - preservar UUIDs e vínculos existentes;
  - "Importar planilha" e "Cobrar pelo WhatsApp" dependem de outros itens (19) e de decisão.
- **Critério de aceite (FUN02):**
  - dados persistem após recarregar;
  - relações corretas;
  - nenhum vínculo perdido na troca de tela.
- **Decisão nova:** D-CRM1 (renomear "Clientes" para "Organizações & Contatos" e ter contato como entidade própria).

### 05 · Documentos
- **Classificação:** existente + melhoria visual.
- **Resultado esperado:** checklist por organização e operação, upload, download e ZIP com o visual novo.
- **Fonte disponível:**
  - **[FATO]** CTX §4: upload direto até 20 MiB, catálogo até 10 MiB, assinatura, tamanho, hash, autorização por ator, idempotência, download e ZIP;
  - o protótipo só mostra o checklist e a área de upload **sem função**.
- **Inspeção pendente:** componentes atuais de upload e lista, e os limites configurados.
- **Critério de aceite (DOC01):**
  - limites mantidos;
  - erro de tipo e de tamanho com a mensagem do design system;
  - progresso de envio;
  - download só para quem tem acesso.
- **Decisão nova:** nenhuma.

### 06 · Funil & Kanban
- **Classificação:** melhoria visual.
- **Resultado esperado:** 8 fases, Kanban e tabela, arrastar com validação, "Mover para…" no toque e no teclado.
- **Fonte disponível:**
  - **[FATO]** protótipo `#funil`, com o bloqueio em Formalização e Faturada;
  - **[FATO]** CTX §4 "Funil comercial" e FUN03.
- **Inspeção pendente:**
  - nomes e chaves reais das fases;
  - regra de transição;
  - quem pode mover;
  - registro de histórico;
  - regra de perda.
- **Regras:**
  - perda antes da OP é feita pelo vendedor; depois da OP, por solicitação à Mesa;
  - o servidor valida toda transição;
  - o protótipo bloqueia as fases 7–8 por regra visual, e a regra real vem do contrato.
- **Critério de aceite:**
  - criação do zero;
  - transições permitidas e negadas no servidor;
  - histórico com responsável;
  - escopo own respeitado;
  - edição concorrente sem perda.
- **Decisão nova:** nenhuma.

### 07 · Operações (OPP → OP → PED)
- **Classificação:** melhoria visual.
- **Resultado esperado:** jornada de códigos com histórico e tabela de operações.
- **Fonte disponível:**
  - **[FATO]** protótipo `#operacoes`;
  - **[FATO]** CTX §4: UUID como identidade, OP no formato `OP-{CODIGO_VENDEDOR}-{YYYYMMDD}-{SEQUENCIA}` (A…Z…AA), formatos de OPP e PED **a confirmar no contrato físico**.
- **Inspeção pendente:** emissão dos códigos e os formatos de OPP e PED.
- **Regras:**
  - código do vendedor automático e permanente;
  - PED nas etapas autorizadas, sem exigir OP ou aprovação universalmente;
  - pedido emitido **não** equivale a máquina faturada.
- **Critério de aceite (FUN04):** código correto, retry sem duplicação e histórico.
- **Decisão nova:** nenhuma.
- **Atenção:** os códigos do protótipo (ex.: `OP-DS-20261022-A`, `OPP-DS-0142`) são ilustrativos e não podem ser copiados como regra.

### 08 · Simulador / Nova Operação
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** assistente em etapas; no protótipo só a etapa "Condições" está desenhada.
- **Fonte disponível:**
  - **[FATO]** protótipo `#simulador`, com cálculo Price e **taxas fictícias**;
  - **[FATO]** CTX §4 "Simulador e pedidos" (regras canônicas, equipamentos por UUID, arredondamento, snapshots, sem taxa inventada).
- **Inspeção pendente:** regras e fonte das taxas, e etapas atuais.
- **Regras:**
  - vendedor não escolhe banco nem status de crédito;
  - a comparação entre instituições do protótipo **não** pode virar escolha do vendedor;
  - taxa só de fonte canônica.
- **Critério de aceite (FUN05):** itens por UUID e quantidade, taxa, totais, snapshot e PDF iguais ao cálculo canônico.
- **Decisão nova:** D-SIM1 (mostrar ou não comparação entre instituições ao vendedor, só informativa).

### 09 · Pedidos e PDF
- **Classificação:** existente + melhoria visual.
- **Resultado esperado:** PDF da proposta e do pedido com a identidade nova, que é configurável.
- **Inspeção pendente:** o gerador de PDF atual e os campos de emissor e beneficiário (FUN06).
- **Critério de aceite:** PDF confere com o snapshot; impressão legível; sem dado de demonstração.
- **Decisão nova:** nenhuma.

### 10 · Mesa de Crédito
- **Classificação:** melhoria visual + extensão.
- **Resultado esperado:** esteira por fases com SLA, fila priorizada, desempenho por instituição e distribuição.
- **Fonte disponível:**
  - **[FATO]** protótipo `#mesa` (6 fases ilustrativas);
  - **[FATO]** CTX §4: ciclo Recebida → análise → decisões → formalização/faturamento → encerramento/cancelamento; Aprovada e Desembolsada distintas; no máximo um desembolsador; SLA de 20 horas úteis, 8h–18h, de segunda a sexta, America/Sao_Paulo, feriados nacionais.
- **Inspeção pendente:**
  - fases e status reais (as 6 do protótipo **não** são as oficiais);
  - cálculo de SLA persistido;
  - tela "decidir crédito" (o protótipo não a desenha).
- **Regras:**
  - elegibilidade, aprovação e desembolso continuam distintos;
  - decisão de crédito é humana;
  - o painel "desempenho por instituição" só com contrato de métrica.
- **Critério de aceite:**
  - SLA igual ao calendário persistido;
  - fila respeita capabilities;
  - nenhuma decisão automática.
- **Decisão nova:** nenhuma.

### 11 · Usuários & Permissões
- **Classificação:** melhoria visual.
- **Resultado esperado:** tabela de pessoas, convites, aprovação e matriz de capabilities por papel.
- **Fonte disponível:**
  - **[FATO]** protótipo `#usuarios`;
  - **[FATO]** CTX §4 "Usuários".
- **Inspeção pendente:**
  - papéis canônicos reais (o CTX cita `coordenador_credito`; os 5 papéis do protótipo são ilustrativos);
  - capabilities existentes.
- **Regras:**
  - sem acesso por equipe ou cargo inferido;
  - mudança de papel e de capability auditada;
  - não bloquear o único coordenador;
  - a matriz do protótipo é ilustrativa.
- **Critério de aceite (USR01, SEC02):**
  - cadastro e aprovação pela interface;
  - matriz positiva e negativa no backend;
  - código do vendedor gerado e imutável.
- **Decisão nova:** nenhuma.

### 12 · Unidades e filiais
- **Classificação:** melhoria visual.
- **Resultado esperado:** aba em Configurações, sem atalho lateral.
- **Inspeção pendente:** modelo de unidade e filial e campos bancários (FUN06 aguarda configuração real).
- **Critério de aceite:** administração por capability; nenhum campo sem modelo.
- **Decisão nova:** nenhuma.

### 13 · Relatórios & BI
- **Classificação:** extensão.
- **Resultado esperado:** painéis (comercial, crédito, operação e SLA, perdas) com filtros, tooltips, totais e detalhamento.
- **Fonte disponível:**
  - **[FATO]** protótipo `#bi` (clique abre detalhamento com dados sorteados);
  - **[FATO]** CTX §8 (8 perguntas de gestão e a dependência canônica de cada uma);
  - BI01 parcial; BI02 incompleto.
- **Inspeção pendente:** fundação BI existente, views e consultas disponíveis.
- **Regras:**
  - contrato de métrica antes do gráfico;
  - sem porcentagem com denominador indefinido;
  - receita faturada separada de previsão;
  - mesmo escopo no agregado e no detalhe.
- **Critério de aceite:** total de cada gráfico igual à soma das linhas do detalhamento, com o mesmo filtro e o mesmo usuário.
- **Decisão nova:** D-BI1 (taxonomia de motivos de perda, se não existir).

### 14 · Ava
- **Classificação:** extensão.
- **Resultado esperado:** ver `AVA_ASSISTANT_CONTRACT.md`.
- **Fonte disponível:**
  - **[FATO]** protótipo `#ava` e barra `Ctrl+K`;
  - **[FATO]** CTX: código publicado, operação paga em HOLD, provider hospedado não validado (AVA01, AVA02);
  - **o Codex está trabalhando no runtime e na execução hospedada.**
  - **Atualização JARVIS-003:** a prova hospedada passou na F7-015; a ativação contínua segue pendente com o Codex; os limites de custo estão aprovados (ver `AVA_ASSISTANT_CONTRACT.md`).
- **Inspeção pendente:** o resultado do trabalho do Codex.
- **Critério de aceite:** os do contrato AVA-03.
- **Decisão nova:** D-AVA2 (voz) e D-AVA4 (ações N2). D-AVA1 e D-AVA3 já foram decididas.

### 15 · Tarefas & Agenda
- **Classificação:** módulo novo ou extensão. O protótipo supõe que as próximas ações vivem hoje no cartão da oportunidade **[INSPEÇÃO PENDENTE]**.
- **Resultado esperado:** tarefas atrasadas, de hoje e próximas, com responsável e prazo; agenda semanal.
- **Regras:**
  - tarefa ligada a um registro (organização, oportunidade, operação);
  - prazo em horas úteis quando houver SLA;
  - XP só com contrato (item 20).
- **Critério de aceite:**
  - criar, concluir e reatribuir com permissão;
  - atrasada vira alerta;
  - histórico preservado.
- **Decisão nova:** D-TAR1 (criar módulo de tarefas ou estender as próximas ações existentes).

### 16 · Notificações
- **Classificação:** extensão ou módulo novo **[INSPEÇÃO PENDENTE]**. O protótipo só mostra o sino com ponto, sem lista.
- **Resultado esperado:** lista de notificações do usuário (SLA, documento, movimentação, menção), marcar como lida e ir ao registro.
- **Regras:**
  - notificação respeita o escopo do usuário;
  - nada de envio externo (e-mail, WhatsApp) sem decisão própria;
  - sem dado sensível no texto do aviso.
- **Critério de aceite:** gera com o evento real; não gera para quem não tem acesso; marcar como lida persiste.
- **Decisão nova:** D-NOT1 (quais eventos notificam e por quais canais).

### 17 · Suporte interno
- **Classificação:** módulo novo.
- **Resultado esperado:** chamados com categoria, prioridade, SLA e responsável; base de conhecimento.
- **Fonte disponível:** **[FATO]** protótipo `#suporte`.
- **Regras:** o pedido de acesso aberto como chamado é aprovado em Usuários & Permissões, nunca no chamado.
- **Critério de aceite:** criar e acompanhar; ver só os próprios chamados, salvo capability de atendimento.
- **Decisão nova:** D-SUP1 (quem atende, SLA, categorias).

### 18 · Conversas (Inbox compartilhado)
- **Classificação:** extensão (a confirmar). O protótipo diz que "chat compartilhado já existe" **[INSPEÇÃO PENDENTE]**.
- **Resultado esperado:** caixa única com o canal interno (e WhatsApp quando houver), nota interna, contexto do negócio ao lado e sugestões da Ava como rascunho.
- **Regras:**
  - mensagem recebida é dado não confiável para a Ava;
  - sugestão nunca é enviada sem ação humana;
  - nota interna nunca sai para o cliente.
- **Critério de aceite:** histórico persistido; acesso por escopo; envio com estado (enviando, enviado, falhou).
- **Decisão nova:** D-CONV1 (escopo de quem vê quais conversas).

### 19 · WhatsApp
- **Classificação:** módulo novo.
- **Resultado esperado:** planejamento da integração **oficial** (instâncias, roteamento, templates, saúde do canal).
- **Fonte disponível:** **[FATO]** protótipo `#whatsapp` (mostra API oficial e não oficial).
- **Regras:**
  - a conexão não oficial (QR) **não** é habilitada por padrão;
  - consentimento do cliente e descadastro;
  - pedir documento não autoriza cobrança financeira automática;
  - credenciais no cofre de segredos.
- **Critério de aceite:** só depois das decisões de custo e consentimento; nenhum envio real nesta etapa.
- **Decisões novas:** D-WA1 (provedor e custo), D-WA2 (consentimento e textos), D-WA3 (não oficial: manter desligado).

### 20 · Metas, XP e desafios
- **Classificação:** módulo novo.
- **Resultado esperado:** metas e realizado, desafios, conquistas, níveis e liga por gerência.
- **Fonte disponível:** **[FATO]** protótipo `#arena`; CTX §8 "Estamos atingindo a meta": cadastro de metas a confirmar.
- **Regras:**
  - XP, metas, novos escopos e regras precisam de contrato aprovado;
  - pontos não podem incentivar aprovação de crédito;
  - pontuar só resultado confirmado (ex.: faturamento validado), nunca clique;
  - comissões fora do escopo.
- **Critério de aceite:** só depois do contrato.
- **Decisões novas:** D-GAM1 (fórmula de XP), D-GAM2 (cadastro de metas), D-GAM3 (visibilidade do ranking).

### 21 · Configurações gerais e white label
- **Classificação:** extensão.
- **Resultado esperado:** abas de unidades, identidade visual, integrações e planos (estado vazio).
- **Regras:**
  - identidade configurável a partir de fonte canônica existente **[INSPEÇÃO PENDENTE]**;
  - **sem** multitenancy nem `workspace_id` generalizado por iniciativa;
  - "Planos & cobrança" é estado vazio reservado.
- **Critério de aceite:** troca de nome, logo e cor sem deploy, se a fonte existir; senão, fica registrado como lacuna.

### 22 · Mapa do produto
Tela de apresentação do protótipo. **Não implementar** no Portal.

### 23 · Localização
**[FATO]** CTX §4: acesso a serviço externo existente. Não presumir módulo novo. Só recebe o visual se houver tela.

---

## Itens que o protótipo não mostra e que devem ser preservados

**[INSPEÇÃO PENDENTE]** Qualquer rota real ausente no protótipo continua existindo e recebe o shell novo. Exemplos citados no CTX:
- cadastro e aprovação de usuários;
- solicitação de acesso;
- recuperação;
- download e ZIP de documentos;
- PDFs;
- localização;
- configurações de filial com campos bancários.

O primeiro passo do bloco A é gerar a lista de rotas reais (FUN01) e cruzá-la com este quadro.

# Ajustes documentais da JARVIS-002

**Comando:** IRMEN-JARVIS-003 · **Data:** 22/10/2026

Os documentos revisados estão em `04_JARVIS-002_ATUALIZADO/`. A referência visual `fb6416c` não mudou. Abaixo, cada ajuste pedido no comando, onde foi feito e como conferir.

| # | Ajuste pedido | Onde | Como conferir |
|---|---|---|---|
| 1 | A prova hospedada da Ava passou na F7-015; a ativação contínua segue pendente | `AVA_ASSISTANT_CONTRACT.md` (início e estado), `DECISIONS_REQUIRED.md` (Decididas), `FUNCTIONAL_GAP_MATRIX.md` item 14 | Buscar "F7-015" |
| 2 | Registrar os limites aprovados: US$ 0,10 por chamada, US$ 1 por 24 h, US$ 10 por mês, 50 chamadas por 24 h e 500 por mês, modelo existente, até 4.000 tokens de saída, zero retentativas automáticas, execução serial global, alerta em 80% e bloqueio em 100% | `AVA_ASSISTANT_CONTRACT.md` (tabela de limites), `DECISIONS_REQUIRED.md` (D-AVA1 decidida), `IMPLEMENTATION_BLOCKS.md` D2 | Buscar "US$ 0,10" |
| 3 | Não pedir esses limites de novo, nem tratá-los como autorização de voz ou de outro recurso pago | D-AVA1 e D-AVA3 saíram da lista aberta; o texto diz que não autorizam voz | `grep -c "D-AVA1"` só acha a seção "Decididas" e o histórico |
| 4 | Retirar a proposta de 2 retentativas automáticas | `AVA_ASSISTANT_CONTRACT.md` (princípio 6, seção de execução, critérios de aceite) | Buscar "Até 2" não acha nada |
| 5 | Separar a consulta à extração já feita de uma nova análise paga | `AVA_ASSISTANT_CONTRACT.md` (ferramentas): `ler_documento` lê a extração salva; `analisar_documento` é chamada paga N1 e conta nos limites. Repetido em `IMPLEMENTATION_BLOCKS.md` D2 | Buscar "analisar_documento" |
| 6 | Corrigir referências ausentes, inclusive `HOMOLOGACAO.md`, sem fabricar aceite | `HOMOLOGACAO.md` incluído como estava, só com uma nota de implementação no topo que diz não alterar o aceite. `DESIGN_SYSTEM_SPEC.md` aponta para ele. `PROPOSTA_ATUALIZACAO_QUADRO.md` foi substituído por `07_QUADRO_PROPOSTO.md` | `MANIFESTO_DE_VERSAO.md`, seção "Atualização" |
| 7 | Tornar os próximos comandos autocontidos | `IMPLEMENTATION_BLOCKS.md` manda copiar as regras comuns para dentro de cada comando; `05_PROXIMOS_BLOCOS.md` traz o próximo comando completo | Ler a seção 3 de `05_PROXIMOS_BLOCOS.md` |
| 8 | WhatsApp: implementar só depois do planejamento e das decisões de provedor e custo | `IMPLEMENTATION_BLOCKS.md` F1 e tabela de ordem; `DECISIONS_REQUIRED.md` D-WA1 | Buscar "Depois:" em F1 |
| 9 | Não prometer transcrição local ou gratuita só por rodar "no navegador" | `DECISIONS_REQUIRED.md` D-AVA2 reescrita como serviço novo; `AVA_ASSISTANT_CONTRACT.md` voz | Buscar "navegador": só aparece como alerta, nunca como promessa |
| 10 | Não transportar afirmações de segurança sem prova, como criptografia de ponta a ponta | Nota no topo de `HOMOLOGACAO.md`; `DESIGN_SYSTEM_SPEC.md` 4.15; `IMPLEMENTATION_BLOCKS.md` F1. No Portal, o DS-02.A não tocou na tela de login | Buscar "ponta a ponta" |
| 11 | Apresentar as propostas de contraste lado a lado, sem bloquear o bloco | `DECISIONS_REQUIRED.md` D-DS1 (tabela homologado × proposta com as razões de contraste); `DESIGN_SYSTEM_SPEC.md` seção 7. No código, `--jv-brand-fill` mantém `#ef3f4f` e é a única linha a trocar | Seção D-DS1 |

## O que não foi alterado

- Nenhum aceite foi criado ou mudado. DS-01 continua com **ACEITE HUMANO PENDENTE** para o pacote de especificação.
- As 16 decisões abertas não foram respondidas por mim. Só foram reagrupadas em `06_DECISOES_PENDENTES.md`.
- `tokens/tokens.css` e `tokens/tokens.json` seguem iguais aos do 002. Os tokens efetivamente implementados no Portal estão em `src/styles/jarvis-theme.css` na branch do DS-02.A.
